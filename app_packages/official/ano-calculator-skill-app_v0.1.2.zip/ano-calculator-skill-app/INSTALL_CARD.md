# ANO Calculator Skill App 安装卡

**App ID:** `ano.skill.calculator`  
**Package:** `ano-calculator-skill-app`  
**版本:** `0.1.2`  
**收费:** 免费  
**联网:** 不需要  

## 这是干嘛的？

这是 Agent Native OS 的第一个官方免费小工具 App，定位类似系统自带计算器。

它能做四件事：

1. **安全算数**：加减乘除、括号、幂、百分号、常用数学函数。
2. **单位换算**：长度、重量、时间、存储单位。
3. **上下文预算估算**：帮 ANO App 开发者估算一次运行大概要多少上下文预算。
4. **最小 App 样板**：开发者可以照着它学习 `manifest.yaml`、上下文权限申请、安装卡、运行审批卡和健康检查。

## 安装后会创建

```txt
apps/ano-calculator-skill-app/
ano/runtime/apps/ano.skill.calculator/
ano/registry/apps/ano.skill.calculator.json
```

## 它不会做什么

- 不联网
- 不读取小说、漫画、代码等项目资料
- 不修改 OS kernel
- 默认不启动任何 Subagent
- 不申请跨 App Bridge

## 默认运行申请

```txt
Coordinator: 1
Subagent: 0
Context budget: tiny
Cross-app bridge: denied
Workspace: 只读自身应用目录，只写自身 app runtime 目录
```

这是一枚“口袋里的螺丝刀”型 App：功能小，但每天能用，也能证明 ANO App 生态真能装、能跑、能审。🧮
