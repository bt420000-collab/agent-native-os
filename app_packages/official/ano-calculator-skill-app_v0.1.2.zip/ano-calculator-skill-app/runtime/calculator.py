#!/usr/bin/env python3
"""ANO Calculator Skill App runtime.

Safe arithmetic, unit conversion, and ANO context-budget estimation.
No network. No project-source reading. No subagents.
"""
from __future__ import annotations

import argparse
import ast
import math
import operator
import re
from pathlib import Path
from typing import Any

APP_ID = "ano.skill.calculator"
APP_NAME = "ANO Calculator Skill App"

BIN_OPS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
}
UNARY_OPS = {
    ast.UAdd: operator.pos,
    ast.USub: operator.neg,
}
ALLOWED_NAMES = {
    "pi": math.pi,
    "e": math.e,
    "tau": math.tau,
}
ALLOWED_FUNCS = {
    "sqrt": math.sqrt,
    "sin": math.sin,
    "cos": math.cos,
    "tan": math.tan,
    "asin": math.asin,
    "acos": math.acos,
    "atan": math.atan,
    "log": math.log,
    "log10": math.log10,
    "floor": math.floor,
    "ceil": math.ceil,
    "abs": abs,
    "round": round,
    "min": min,
    "max": max,
}

UNIT_TABLE = {
    # length: base meter
    "mm": ("length", 0.001), "cm": ("length", 0.01), "m": ("length", 1.0), "km": ("length", 1000.0),
    "in": ("length", 0.0254), "ft": ("length", 0.3048), "yd": ("length", 0.9144), "mi": ("length", 1609.344),
    # mass: base kg
    "mg": ("mass", 0.000001), "g": ("mass", 0.001), "kg": ("mass", 1.0), "t": ("mass", 1000.0),
    "oz": ("mass", 0.028349523125), "lb": ("mass", 0.45359237),
    # time: base second
    "ms": ("time", 0.001), "s": ("time", 1.0), "sec": ("time", 1.0), "min": ("time", 60.0), "h": ("time", 3600.0), "hr": ("time", 3600.0), "day": ("time", 86400.0),
    # storage decimal: base byte
    "B": ("storage", 1.0), "KB": ("storage", 1000.0), "MB": ("storage", 1000.0**2), "GB": ("storage", 1000.0**3), "TB": ("storage", 1000.0**4),
    "KiB": ("storage", 1024.0), "MiB": ("storage", 1024.0**2), "GiB": ("storage", 1024.0**3), "TiB": ("storage", 1024.0**4),
}

class SafeEvalError(ValueError):
    pass


def _eval_node(node: ast.AST) -> float:
    if isinstance(node, ast.Expression):
        return _eval_node(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in BIN_OPS:
        left = _eval_node(node.left)
        right = _eval_node(node.right)
        return BIN_OPS[type(node.op)](left, right)
    if isinstance(node, ast.UnaryOp) and type(node.op) in UNARY_OPS:
        return UNARY_OPS[type(node.op)](_eval_node(node.operand))
    if isinstance(node, ast.Name) and node.id in ALLOWED_NAMES:
        return ALLOWED_NAMES[node.id]
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Name) and node.func.id in ALLOWED_FUNCS:
        args = [_eval_node(arg) for arg in node.args]
        if len(args) > 8:
            raise SafeEvalError("Too many function arguments")
        return ALLOWED_FUNCS[node.func.id](*args)
    raise SafeEvalError(f"Unsupported expression element: {ast.dump(node, include_attributes=False)}")


def safe_calculate(expr: str) -> float:
    # Treat 50% as (50/100) only for simple numeric percent tokens.
    expr = re.sub(r"(?<![\w.])(\d+(?:\.\d+)?)%", r"(\1/100)", expr)
    try:
        tree = ast.parse(expr, mode="eval")
    except SyntaxError as exc:
        raise SafeEvalError(str(exc)) from exc
    return _eval_node(tree)


def convert_units(text: str) -> float:
    m = re.fullmatch(r"\s*([+-]?\d+(?:\.\d+)?)\s*([A-Za-z]+)\s+(?:to|in|->)\s*([A-Za-z]+)\s*", text)
    if not m:
        raise ValueError("Use format like: 10 km to mi")
    value = float(m.group(1))
    src = m.group(2)
    dst = m.group(3)
    if src not in UNIT_TABLE or dst not in UNIT_TABLE:
        raise ValueError(f"Unsupported unit. Supported units: {', '.join(sorted(UNIT_TABLE))}")
    src_dim, src_factor = UNIT_TABLE[src]
    dst_dim, dst_factor = UNIT_TABLE[dst]
    if src_dim != dst_dim:
        raise ValueError(f"Cannot convert {src_dim} to {dst_dim}")
    return value * src_factor / dst_factor


def context_budget(agents: int, tokens_per_agent: int, shared: int, safety: float) -> dict[str, Any]:
    if agents < 0 or tokens_per_agent < 0 or shared < 0:
        raise ValueError("agents, tokens_per_agent, and shared must be non-negative")
    raw = agents * tokens_per_agent + shared
    total = math.ceil(raw * safety)
    if total <= 8000:
        level = "tiny"
    elif total <= 32000:
        level = "low"
    elif total <= 128000:
        level = "medium"
    elif total <= 512000:
        level = "high"
    else:
        level = "extreme"
    return {
        "agents": agents,
        "tokens_per_agent": tokens_per_agent,
        "shared_tokens": shared,
        "safety_multiplier": safety,
        "estimated_tokens": total,
        "recommended_level": level,
    }


def approval_card() -> str:
    return f"""# ANO Agent 运行审批卡

App：{APP_NAME}  
App ID：`{APP_ID}`  
运行模式：utility

## 计划启动角色

- Calculator Coordinator：1
- Subagent：0

## 上下文预算

- requested_level：tiny
- max_tokens_hint：4000
- allow_long_context：false
- allow_full_project_scan：false

## 工作区权限

可读：

```txt
apps/ano-calculator-skill-app/
ano/runtime/apps/ano.skill.calculator/inbox/
```

可写：

```txt
ano/runtime/apps/ano.skill.calculator/desktop/
ano/runtime/apps/ano.skill.calculator/outbox/
ano/runtime/apps/ano.skill.calculator/logs/
ano/runtime/apps/ano.skill.calculator/state/
user/apps/ano.skill.calculator/
```

禁止：

```txt
ano/kernel/
ano/kernel/
ano/runtime/apps/*/private/
ano/runtime/process_table.json
.git/
```

## 审批建议

允许运行。这个 App 不联网，不读取项目资料，不启动 Subagent，不申请跨 App Bridge。
"""


def write_outbox(workspace: str | None, filename: str, content: str) -> None:
    if not workspace:
        return
    outbox = Path(workspace) / "ano" / "runtime" / "apps" / APP_ID / "outbox"
    outbox.mkdir(parents=True, exist_ok=True)
    (outbox / filename).write_text(content, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser(prog="ano-calculator", description="ANO Calculator Skill App runtime")
    parser.add_argument("--workspace", help="Optional ANO workspace path for writing outbox files")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_calc = sub.add_parser("calc", help="Safe arithmetic")
    p_calc.add_argument("expression")

    p_unit = sub.add_parser("unit", help="Convert units, e.g. '10 km to mi'")
    p_unit.add_argument("expression")

    p_ctx = sub.add_parser("context", help="Estimate ANO context budget")
    p_ctx.add_argument("--agents", type=int, required=True)
    p_ctx.add_argument("--tokens-per-agent", type=int, required=True)
    p_ctx.add_argument("--shared", type=int, default=0)
    p_ctx.add_argument("--safety", type=float, default=1.2)

    sub.add_parser("approval-card", help="Print runtime approval card")

    args = parser.parse_args()

    if args.cmd == "calc":
        result = safe_calculate(args.expression)
        content = f"# Calculation Result\n\nExpression: `{args.expression}`\n\nResult: `{result}`\n"
        print(result)
        write_outbox(args.workspace, "calculation_result.md", content)
    elif args.cmd == "unit":
        result = convert_units(args.expression)
        content = f"# Unit Conversion Result\n\nExpression: `{args.expression}`\n\nResult: `{result}`\n"
        print(result)
        write_outbox(args.workspace, "calculation_result.md", content)
    elif args.cmd == "context":
        data = context_budget(args.agents, args.tokens_per_agent, args.shared, args.safety)
        content = "# Context Budget Report\n\n" + "\n".join(f"- {k}: `{v}`" for k, v in data.items()) + "\n"
        print(content)
        write_outbox(args.workspace, "context_budget_report.md", content)
    elif args.cmd == "approval-card":
        card = approval_card()
        print(card)
        write_outbox(args.workspace, "runtime_approval_card.md", card)

if __name__ == "__main__":
    main()
