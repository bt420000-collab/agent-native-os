#!/usr/bin/env python3
"""Print install card for ANO Calculator Skill App."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
print((ROOT / "INSTALL_CARD.md").read_text(encoding="utf-8"))
