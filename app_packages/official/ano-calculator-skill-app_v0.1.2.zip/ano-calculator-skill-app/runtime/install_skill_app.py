#!/usr/bin/env python3
"""Install ANO Calculator Skill App into an Agent Native OS v0.2.2 workspace."""
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

APP_ID = "ano.skill.calculator"
PACKAGE_NAME = "ano-calculator-skill-app"
DISPLAY_NAME = "ANO Calculator Skill App"
VERSION = "0.1.2"


def now() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def append_event(workspace: Path, event: dict) -> None:
    events = workspace / "ano" / "runtime" / "events.jsonl"
    events.parent.mkdir(parents=True, exist_ok=True)
    events.open("a", encoding="utf-8").write(json.dumps(event, ensure_ascii=False) + "\n")


def ensure_min_workspace(workspace: Path) -> None:
    for rel in [
        "ano/kernel",
        "ano/registry/apps",
        "ano/runtime/apps",
        "ano/runtime/locks",
        "ano/runtime/bridges",
        "user/apps",
        "user/profile",
        "apps",
        "res",
        "out/calculator",
    ]:
        (workspace / rel).mkdir(parents=True, exist_ok=True)
    if not (workspace / "README.md").exists():
        (workspace / "README.md").write_text("# Agent-Native OS Workspace\n", encoding="utf-8")
    if not (workspace / "USER_LOG.md").exists():
        (workspace / "USER_LOG.md").write_text("# User Log\n", encoding="utf-8")
    if not (workspace / "ano/registry/installed_apps.json").exists():
        (workspace / "ano/registry/installed_apps.json").write_text('{"installed_apps": []}\n', encoding="utf-8")
    if not (workspace / "ano/runtime/process_table.json").exists():
        (workspace / "ano/runtime/process_table.json").write_text(json.dumps({
            "host": {"id": "ano.host", "type": "system_host", "status": "running", "persistent": True, "created_at": now()},
            "processes": []
        }, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    if not (workspace / "ano/runtime/context_allocations.json").exists():
        (workspace / "ano/runtime/context_allocations.json").write_text('{"allocations": []}\n', encoding="utf-8")


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage: python runtime/install_skill_app.py /path/to/ano-workspace", file=sys.stderr)
        raise SystemExit(2)
    workspace = Path(sys.argv[1]).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    ensure_min_workspace(workspace)

    if (workspace / ".agent-os").exists() or (workspace / "skills").exists():
        print("Refusing to install into a legacy workspace containing .agent-os/ or skills/. Run the v0.2.2 workspace initializer/cleanup first.", file=sys.stderr)
        raise SystemExit(1)

    app_src = Path(__file__).resolve().parents[1]
    app_dst = workspace / "apps" / PACKAGE_NAME
    app_home = workspace / "ano" / "runtime" / "apps" / APP_ID
    user_home = workspace / "user" / "apps" / APP_ID

    if app_dst.exists():
        shutil.rmtree(app_dst)
    app_dst.parent.mkdir(parents=True, exist_ok=True)
    shutil.copytree(app_src, app_dst, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))

    for rel in ["desktop", "inbox", "outbox", "logs", "state"]:
        (app_home / rel).mkdir(parents=True, exist_ok=True)
    user_home.mkdir(parents=True, exist_ok=True)
    (workspace / "out" / "calculator").mkdir(parents=True, exist_ok=True)

    intro = (app_dst / "INSTALL_CARD.md").read_text(encoding="utf-8")
    (app_home / "logs" / "INSTALL_INTRO.md").write_text(intro, encoding="utf-8")

    registry = {
        "app_id": APP_ID,
        "package_name": PACKAGE_NAME,
        "display_name": DISPLAY_NAME,
        "version": VERSION,
        "type": "skill_app",
        "pricing_model": "free",
        "license": "Apache-2.0",
        "installed_at": now(),
        "app_package_path": f"apps/{PACKAGE_NAME}/",
        "app_runtime_home": f"ano/runtime/apps/{APP_ID}/",
        "app_user_home": f"user/apps/{APP_ID}/",
        "output_home": "out/calculator/",
        "runtime_model": "single_host_runtime",
        "filesystem_standard": "clean_root_v1",
        "subagents_default": 0,
        "cross_app_bridge": "denied",
    }
    reg_path = workspace / "ano" / "registry" / "apps" / f"{APP_ID}.json"
    reg_path.parent.mkdir(parents=True, exist_ok=True)
    reg_path.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")

    installed_apps_path = workspace / "ano" / "registry" / "installed_apps.json"
    try:
        installed = json.loads(installed_apps_path.read_text(encoding="utf-8"))
    except Exception:
        installed = {"installed_apps": []}
    installed["installed_apps"] = [x for x in installed.get("installed_apps", []) if x.get("app_id") != APP_ID]
    installed["installed_apps"].append({"app_id": APP_ID, "package_name": PACKAGE_NAME, "version": VERSION})
    installed_apps_path.write_text(json.dumps(installed, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    report = f"""# Install Report

App: {DISPLAY_NAME}  
App ID: `{APP_ID}`  
Version: `{VERSION}`  
Installed at: `{registry['installed_at']}`

## Paths

- App package: `apps/{PACKAGE_NAME}/`
- Runtime home: `ano/runtime/apps/{APP_ID}/`
- User customization: `user/apps/{APP_ID}/`
- Registry: `ano/registry/apps/{APP_ID}.json`
- Final outputs: `out/calculator/`

## Result

Installed successfully.
"""
    (app_home / "logs" / "INSTALL_REPORT.md").write_text(report, encoding="utf-8")

    append_event(workspace, {
        "event": "app.installed",
        "app_id": APP_ID,
        "package_name": PACKAGE_NAME,
        "version": VERSION,
        "time": now(),
    })

    print(f"Installed {DISPLAY_NAME} into {workspace}")
    print(f"App package: {app_dst}")
    print(f"Runtime home: {app_home}")

if __name__ == "__main__":
    main()
