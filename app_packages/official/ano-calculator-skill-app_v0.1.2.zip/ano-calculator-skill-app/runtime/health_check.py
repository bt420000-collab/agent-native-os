#!/usr/bin/env python3
"""Health check for ANO Calculator Skill App on v0.2.2 filesystem."""
from __future__ import annotations

import json
import sys
from pathlib import Path

APP_ID = "ano.skill.calculator"
PACKAGE_NAME = "ano-calculator-skill-app"


def main() -> None:
    if len(sys.argv) != 2:
        print("Usage: python runtime/health_check.py /path/to/ano-workspace", file=sys.stderr)
        raise SystemExit(2)
    workspace = Path(sys.argv[1]).resolve()
    checks = []

    def check(name: str, ok: bool):
        checks.append((name, ok))
        print(("PASS" if ok else "FAIL") + f": {name}")

    check("workspace exists", workspace.exists())
    check("ano system directory exists", (workspace / "ano").exists())
    check("legacy .agent-os absent", not (workspace / ".agent-os").exists())
    check("legacy skills absent", not (workspace / "skills").exists())
    check("app package exists", (workspace / "apps" / PACKAGE_NAME).exists())
    check("manifest exists", (workspace / "apps" / PACKAGE_NAME / "manifest.yaml").exists())
    check("app runtime home exists", (workspace / "ano" / "runtime" / "apps" / APP_ID).exists())
    check("app user home exists", (workspace / "user" / "apps" / APP_ID).exists())
    check("output home exists", (workspace / "out" / "calculator").exists())
    check("registry exists", (workspace / "ano" / "registry" / "apps" / f"{APP_ID}.json").exists())
    for rel in ["desktop", "inbox", "outbox", "logs", "state"]:
        check(f"app runtime has {rel}/", (workspace / "ano" / "runtime" / "apps" / APP_ID / rel).exists())

    reg = workspace / "ano" / "registry" / "apps" / f"{APP_ID}.json"
    if reg.exists():
        data = json.loads(reg.read_text(encoding="utf-8"))
        check("registry app_id matches", data.get("app_id") == APP_ID)
        check("registry pricing is free", data.get("pricing_model") == "free")
        check("registry subagents default is zero", data.get("subagents_default") == 0)
        check("registry app package path is v0.2.2", data.get("app_package_path") == f"apps/{PACKAGE_NAME}/")

    if not all(ok for _, ok in checks):
        raise SystemExit(1)

if __name__ == "__main__":
    main()
