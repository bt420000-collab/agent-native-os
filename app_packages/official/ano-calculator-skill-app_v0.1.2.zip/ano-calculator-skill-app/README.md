# ANO Calculator Skill App

`ano-calculator-skill-app` is the first official free utility app for Agent Native OS.
It is deliberately small: useful enough to keep, simple enough to copy as a developer template.

## What it does

- Safe arithmetic: `2 + 3 * (4 - 1)`, `sqrt(16)`, `sin(pi / 2)`
- Unit conversion: `10 km to mi`, `512 MB to GB`, `2 h to min`
- ANO context-budget estimation for app runs and subagent plans
- Runtime approval card preview for the Single Host Runtime model

## Why this app exists

Agent Native OS needs a first-party demo that is not a toy. This app is the ANO equivalent of a system calculator:
small, free, offline, transparent, and useful.

It also demonstrates the required app structure:

```txt
manifest.yaml
INSTALL_CARD.md
permissions.yaml
input_contract.md
output_contract.md
app_actions/
commands/
runtime/
docs/
tests/
```

## Quick use

From the app directory:

```bash
python runtime/calculator.py calc "2 + 3 * 4"
python runtime/calculator.py unit "10 km to mi"
python runtime/calculator.py context --agents 4 --tokens-per-agent 8000 --shared 12000
python runtime/calculator.py approval-card
```

Install into an ANO workspace:

```bash
python runtime/install_skill_app.py /path/to/ano-workspace
```

Then run health check:

```bash
python runtime/health_check.py /path/to/ano-workspace
```

## Runtime model

This app is intentionally minimal:

- `calculator.coordinator`: 1
- Subagents: 0
- Context budget: tiny
- Cross-app bridge: denied
- Network: not required
- Workspace access: sandboxed to its own app home

## License

Apache-2.0
