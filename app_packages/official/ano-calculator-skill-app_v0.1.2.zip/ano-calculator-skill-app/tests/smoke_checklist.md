# Smoke Checklist

```bash
python runtime/calculator.py calc "2 + 3 * 4"
python runtime/calculator.py unit "10 km to mi"
python runtime/calculator.py context --agents 4 --tokens-per-agent 8000 --shared 12000
python runtime/calculator.py approval-card
python runtime/install_skill_app.py /tmp/ano-workspace
python runtime/health_check.py /tmp/ano-workspace
```

Expected:

- arithmetic result is `14`
- unit conversion result is approximately `6.2137119223733395 mi`
- context budget report is printed
- approval card is printed
- install creates `apps/ano-calculator-skill-app/`
- install creates `ano/runtime/apps/ano.skill.calculator/`
- health check passes
