# Output Contract

The calculator app writes optional outputs under:

```txt
ano/runtime/apps/ano.skill.calculator/outbox/
```

## Files

- `calculation_result.md`: result of arithmetic or unit conversion
- `context_budget_report.md`: estimated context budget for an app run
- `runtime_approval_card.md`: generated approval card preview

The app may also write logs under:

```txt
ano/runtime/apps/ano.skill.calculator/logs/
```
