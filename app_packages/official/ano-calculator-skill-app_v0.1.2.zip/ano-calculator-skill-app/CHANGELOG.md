# Changelog

## 0.1.2 - install card version sync

- Synchronized `INSTALL_CARD.md`, `manifest.yaml`, and runtime installer version strings.


## 0.1.1 - v0.2.2 filesystem update

- Updated install paths from legacy `skills/` and `.agent-os/` to `apps/` and `ano/`.
- Added `user/apps/<app_id>/` customization home and `out/calculator/` output home.
- Updated health check to reject legacy workspace roots.

## 0.1.0 - First free official utility app

- Added safe arithmetic calculator.
- Added basic unit conversion.
- Added ANO context-budget estimator.
- Added runtime approval card preview.
- Added v0.2 Single Host Runtime compliant manifest.
- Added install, inspect, and health-check scripts.
