# ANO Agent 运行审批卡

App：ANO Calculator Skill App  
App ID：`ano.skill.calculator`  
运行模式：utility

## 计划启动角色

- Calculator Coordinator：1
- Subagent：0

## 上下文预算

- requested_level：tiny
- max_tokens_hint：4000
- allow_long_context：false
- allow_full_project_scan：false

## 工作区权限

可读：

```txt
apps/ano-calculator-skill-app/
ano/runtime/apps/ano.skill.calculator/inbox/
```

可写：

```txt
ano/runtime/apps/ano.skill.calculator/desktop/
ano/runtime/apps/ano.skill.calculator/outbox/
ano/runtime/apps/ano.skill.calculator/logs/
ano/runtime/apps/ano.skill.calculator/state/
user/apps/ano.skill.calculator/
```

禁止：

```txt
ano/kernel/
ano/kernel/
ano/runtime/apps/*/private/
ano/runtime/process_table.json
.git/
```

## 审批建议

允许运行。
