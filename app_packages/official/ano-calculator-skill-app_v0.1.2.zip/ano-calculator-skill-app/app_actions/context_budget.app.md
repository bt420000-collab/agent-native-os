# App Action: context_budget

Use `context_budget` when an app developer wants to estimate a rough ANO context footprint.

Runtime command:

```bash
python runtime/calculator.py context --agents 4 --tokens-per-agent 8000 --shared 12000
```

This is not a hard scheduler decision. It is a planning helper before submitting a Context Permission Request.
