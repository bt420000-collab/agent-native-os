# App Action: calculate

Use `calculate` when the user asks for a numeric result.

Runtime command:

```bash
python runtime/calculator.py calc "2 + 3 * 4"
```

ANO Host policy:

- No subagent required.
- No project source reading required.
- Result may be written to `outbox/calculation_result.md`.
