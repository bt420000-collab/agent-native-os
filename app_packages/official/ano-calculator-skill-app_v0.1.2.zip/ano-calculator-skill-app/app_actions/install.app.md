# App Action: install

Install this app into an Agent Native OS workspace.

Runtime command:

```bash
python runtime/install_skill_app.py /path/to/workspace
```

The installer copies the app to `apps/ano-calculator-skill-app/`, creates `ano/runtime/apps/ano.skill.calculator/`, writes a registry record, and stores the install intro.
