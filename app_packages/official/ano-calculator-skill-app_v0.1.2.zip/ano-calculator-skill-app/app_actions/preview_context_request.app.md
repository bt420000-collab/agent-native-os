# App Action: preview_context_request

Generate a minimal Agent Runtime Approval Card for this app.

Runtime command:

```bash
python runtime/calculator.py approval-card
```

This demonstrates how a small free app reports its role roster and permissions before running.
