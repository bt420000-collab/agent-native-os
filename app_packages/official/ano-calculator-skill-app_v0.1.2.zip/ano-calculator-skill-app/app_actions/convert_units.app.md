# App Action: convert_units

Use `convert_units` when the user asks to convert common units.

Runtime command:

```bash
python runtime/calculator.py unit "10 km to mi"
```

Supported dimensions: length, mass, time, storage.
