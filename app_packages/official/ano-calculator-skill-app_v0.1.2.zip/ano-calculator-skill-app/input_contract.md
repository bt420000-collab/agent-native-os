# Input Contract

The calculator app accepts three kinds of input.

## 1. Arithmetic expression

```txt
2 + 3 * (4 - 1)
sqrt(16)
sin(pi / 2)
```

Allowed operators: `+`, `-`, `*`, `/`, `//`, `%`, `**`, parentheses.  
Allowed functions include: `sqrt`, `sin`, `cos`, `tan`, `log`, `log10`, `floor`, `ceil`, `abs`, `round`, `min`, `max`.

## 2. Unit conversion expression

```txt
10 km to mi
512 MB to GB
2 h to min
```

Supported dimensions:

- Length: `mm`, `cm`, `m`, `km`, `in`, `ft`, `yd`, `mi`
- Mass: `mg`, `g`, `kg`, `t`, `oz`, `lb`
- Time: `ms`, `s`, `min`, `h`, `day`
- Storage: `B`, `KB`, `MB`, `GB`, `TB`, `KiB`, `MiB`, `GiB`, `TiB`

## 3. Context budget estimation

```bash
python runtime/calculator.py context --agents 4 --tokens-per-agent 8000 --shared 12000
```

This estimates a simple total context footprint for ANO app planning.
