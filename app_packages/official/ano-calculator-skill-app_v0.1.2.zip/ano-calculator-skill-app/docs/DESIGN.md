# Design Notes

ANO Calculator Skill App is designed to be the first official free Skill App demo.

## Principles

1. It must be useful, not just decorative.
2. It must be safe: no network, no project-source reading, no kernel mutation.
3. It must be tiny: default subagent quota is zero.
4. It must demonstrate the ANO v0.2 app contract clearly.
5. It must be copyable by app developers.

## Why calculator?

Every OS needs a boring little tool that proves the system can install and run apps. A calculator is perfect:

- The user understands it instantly.
- The permission request is easy to audit.
- The app can run offline.
- The result is verifiable.
- The structure can be used as a template for larger apps.

## ANO-specific extension

In addition to arithmetic and unit conversion, the app includes a context-budget estimator because ANO apps must submit resource plans before running.
