# Command: convert

```bash
python runtime/calculator.py unit "10 km to mi"
```
