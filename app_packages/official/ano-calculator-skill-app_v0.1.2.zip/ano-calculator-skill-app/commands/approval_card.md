# Command: approval-card

```bash
python runtime/calculator.py approval-card
```
