# Command: calculate

```bash
python runtime/calculator.py calc "2 + 3 * 4"
```
