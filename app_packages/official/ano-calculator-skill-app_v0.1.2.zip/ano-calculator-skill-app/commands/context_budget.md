# Command: context-budget

```bash
python runtime/calculator.py context --agents 4 --tokens-per-agent 8000 --shared 12000
```
