# Output Contract v0.3.0

## open

Returns:

- `context_permission_request`
- `agent_runtime_approval_card`
- `agent_trace`
- `stop`

No sampling output.

## start / answer

Returns:

- `session_id`
- `agent_trace`
- `oracle_reading`
- `furnace_status`
- `next_questions`
- `opening_result` only when gates are passed

## ritual

Returns a blocked response explaining the correct ANO-hosted flow.
