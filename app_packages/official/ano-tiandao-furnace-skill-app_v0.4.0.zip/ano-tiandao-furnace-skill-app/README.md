# ANO Tiandao Furnace Skill App v0.4.0

一个免费的 ANO 多 Agent Skill App 示例。它来自“天道哈希炉”小前端，但在 ANO 里被改造成 **OS 托管、运行前审批、分批互动、上期号码查验、风水添柴、炉温门槛** 的多 Agent 流程。

## v0.4.0 修复重点

- 开局不再省略“上期开奖号码”。第一关必须处理：手动录入 / 请求 ANO Host 联网查询 / 明确跳过。
- App 不自行联网；选择联网时输出 `host_tool_request`，由 ANO Host 接管查询，再回填结果。
- 用户多选超限不会卡死。例如心象最多建议 2 个，用户选 3 个时，前 2 个入炉，超出的转为“炉边余炭”，流程继续。
- 每轮输出 `next_user_prompt` 和 `agent_instruction`，Agent 应直接把下一批问题读给用户，不要等用户说“继续”。
- 新增风水堪舆 Agent：方位、天气、地理场作为民俗象征 seed 权重。
- 炉温差几度时会给明确补炉动作，不再让 Agent 原地抓头。

## 安全边界

它不是彩票预测器，不提升中奖概率，不提供投注建议，也不得用于任何金钱决策。风水/五行/八卦内容只作为民俗叙事和娱乐随机 seed 解释。

## 正确流程

### 1. 必须由 ANO Host 打开 App

```bash
python ano/scripts/ano_host.py "打开天道炉子"
```

外部 Agent 不得直接进入 App 目录运行内部脚本。

### 2. 用户批准后创建 session

```bash
python runtime/tiandao_furnace.py start --yes
```

这一步不会开炉，只会返回第一批问题：上期号码来源。

### 3. 上期号码第一关

手动录入：

```bash
python runtime/tiandao_furnace.py answer --session <id> --previous-source manual --front "1 2 3 4 5" --back "1 2"
```

请求 ANO Host 联网查官方上期号码：

```bash
python runtime/tiandao_furnace.py answer --session <id> --previous-source web_lookup_requested
```

App 会返回 `host_tool_request`，Host 查完后回填：

```bash
python runtime/tiandao_furnace.py answer --session <id> --previous-source web_lookup_confirmed --front "<前区5个>" --back "<后区2个>"
```

### 4. 分批问答

按 `next_user_prompt` 继续问用户：缘起、心象、场域、风水方位、天气、地理场、炉名。

示例：

```bash
python runtime/tiandao_furnace.py answer --session <id> --mental "期待,忧郁,疲惫"
```

即使选了 3 个，程序也不会卡死，会把超出项转为“炉边余炭”。

### 5. 天时地利风水添柴

```bash
python runtime/tiandao_furnace.py answer --session <id> --direction south --weather sunny --geo-field home
```

或请求当前天气：

```bash
python runtime/tiandao_furnace.py answer --session <id> --location "Tokyo" --weather weather_lookup_requested
```

### 6. 炉温达标后仍需确认娱乐用途

```bash
python runtime/tiandao_furnace.py answer --session <id> --confirm yes_entertainment_only
```

只有这一步之后，符号采样 Agent 才能开炉。

## 风水数字说明

本 App 的“风水制造数字”是娱乐化转译，不是预测：

```txt
方位/天气/地理场/心象/缘起
  ↓
五行权重与 seed salt
  ↓
确定性随机采样
  ↓
娱乐候选样本
```

例如：东方取木、南方取火、西方取金、北方取水；晴取火、雨取水、风取木、云取土；近水偏水、近山偏土、道路偏动。

