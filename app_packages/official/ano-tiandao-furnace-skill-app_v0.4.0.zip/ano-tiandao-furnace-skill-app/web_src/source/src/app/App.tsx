import { useState } from 'react';
import { FurnacePage } from './routes/FurnacePage';
import { LogsPage } from './routes/LogsPage';
import { ResultPage } from './routes/ResultPage';

type Page = 'furnace' | 'logs' | 'result';

function App() {
  const [currentPage, setCurrentPage] = useState<Page>('furnace');

  const handleNavigate = (page: string) => {
    setCurrentPage(page as Page);
  };

  return (
    <>
      {currentPage === 'furnace' && <FurnacePage onNavigate={handleNavigate} />}
      {currentPage === 'logs' && <LogsPage onNavigate={handleNavigate} />}
      {currentPage === 'result' && <ResultPage onNavigate={handleNavigate} />}
    </>
  );
}

export default App;