import { useState, useEffect } from 'react';
import { NumberOrb } from '../../components/NumberOrb';
import { LottoPick } from '../../types/furnace';
import { getExperiments, initDb } from '../../db';

interface LogsPageProps {
  onNavigate: (page: string) => void;
}

interface LogEntry {
  id: string;
  drawNo: string;
  date: string;
  mode: string;
  seed: string;
  outputJson: string;
  collisionLevel?: string;
  reward: number;
  createdAt: string;
}

const modeLabels: Record<string, string> = {
  mirror: '逆时空反像',
  aura_lora: '气运LoRA',
  activity_field: '活动场',
  cold_furnace: '冷炉慢炼',
  wild_furnace: '疯炉模式',
  multi_element: '多要素入炉',
};

export function LogsPage({ onNavigate }: LogsPageProps) {
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    setLoading(true);
    await initDb();
    const experiments = await getExperiments();
    const formattedLogs: LogEntry[] = experiments.map(exp => ({
      id: exp.id,
      drawNo: exp.drawNo,
      date: exp.date,
      mode: exp.mode,
      seed: exp.seed,
      outputJson: exp.outputJson,
      collisionLevel: exp.collisionLevel,
      reward: exp.reward,
      createdAt: exp.createdAt,
    }));
    setLogs(formattedLogs);
    setLoading(false);
  };

  const getLevelStyle = (level?: string) => {
    switch (level) {
      case 'high_collision':
        return 'bg-red-900/50 text-red-400';
      case 'mid_collision':
        return 'bg-yellow-900/50 text-yellow-400';
      case 'low_collision':
        return 'bg-green-900/50 text-green-400';
      case 'micro_echo':
        return 'bg-blue-900/50 text-blue-400';
      default:
        return 'bg-gray-800 text-gray-400';
    }
  };

  const getLevelLabel = (level?: string) => {
    switch (level) {
      case 'high_collision':
        return '高阶碰撞';
      case 'mid_collision':
        return '中阶碰撞';
      case 'low_collision':
        return '低阶碰撞';
      case 'micro_echo':
        return '微响';
      default:
        return '待复盘';
    }
  };

  return (
    <div className="min-h-screen bg-furnace-darker text-gray-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-furnace-gold mb-2">实验日志</h1>
              <p className="text-gray-400">记录每次开炉实验的符号碰撞</p>
            </div>
            <button
              onClick={() => onNavigate('furnace')}
              className="px-4 py-2 bg-furnace-gold text-black rounded-lg font-bold hover:bg-furnace-copper transition-colors"
            >
              🏭 开炉
            </button>
          </div>
        </header>

        {loading ? (
          <div className="text-center py-12">
            <div className="inline-block w-8 h-8 border-2 border-furnace-gold border-t-transparent rounded-full animate-spin" />
            <p className="mt-4 text-gray-400">加载实验日志...</p>
          </div>
        ) : logs.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-6xl mb-4">📝</div>
            <p className="text-gray-400">暂无实验记录</p>
            <button
              onClick={() => onNavigate('furnace')}
              className="mt-4 px-6 py-2 bg-furnace-gold text-black rounded-lg font-bold"
            >
              开始第一次开炉
            </button>
          </div>
        ) : (
          <div className="space-y-4">
            {logs.map((log) => {
              let picks: LottoPick[] = [];
              try {
                picks = JSON.parse(log.outputJson);
              } catch {
                picks = [];
              }

              return (
                <div
                  key={log.id}
                  className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4"
                >
                  <div className="flex items-start justify-between mb-4">
                    <div>
                      <div className="flex items-center gap-3">
                        <span className="text-furnace-gold font-bold">实验 {log.id}</span>
                        <span className="px-2 py-1 bg-furnace-darker rounded text-sm text-gray-400">
                          {modeLabels[log.mode] || log.mode}
                        </span>
                        <span className={`px-2 py-1 rounded text-sm ${getLevelStyle(log.collisionLevel)}`}>
                          {getLevelLabel(log.collisionLevel)}
                        </span>
                      </div>
                      <div className="mt-1 text-sm text-gray-500">
                        {log.date} · 期号: {log.drawNo}
                      </div>
                    </div>
                    <div className="text-right">
                      <div className="text-sm text-gray-500">seed</div>
                      <div className="text-mono text-furnace-gold text-sm">{log.seed.slice(0, 12)}...</div>
                    </div>
                  </div>

                  {picks.length > 0 && (
                    <div className="bg-furnace-darker rounded-lg p-4">
                      <div className="flex items-center gap-4 flex-wrap">
                        {picks[0]?.front.map((num) => (
                          <NumberOrb key={num} number={num} />
                        ))}
                        <span className="text-gray-500">+</span>
                        {picks[0]?.back.map((num) => (
                          <NumberOrb key={num} number={num} />
                        ))}
                      </div>
                      {picks[0]?.explanation && (
                        <p className="mt-2 text-sm text-gray-400">
                          {picks[0].explanation}
                        </p>
                      )}
                      <p className="mt-2 text-xs text-gray-600">
                        共 {picks.length} 注候选
                      </p>
                    </div>
                  )}

                  <div className="mt-4 flex items-center justify-between">
                    <span className="text-sm text-gray-500">{log.createdAt}</span>
                    {log.reward > 0 && (
                      <span className="text-furnace-gold font-bold">
                        奖励: ¥{log.reward.toLocaleString()}
                      </span>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}

        <footer className="mt-12 text-center text-gray-600 text-sm">
          <p>小钱观测，宇宙回声 · 中奖不是神谕，只是碰撞奖励</p>
        </footer>
      </div>
    </div>
  );
}