import { useState, useEffect, useMemo } from 'react';
import { FurnaceButton } from '../../components/FurnaceButton';
import { AuraPanel } from '../../components/AuraPanel';
import { MirrorMap } from '../../components/MirrorMap';
import { NumberOrb } from '../../components/NumberOrb';
import { SafetyBanner } from '../../components/SafetyBanner';
import { NumberGridInput } from '../../components/NumberGridInput';
import { runFurnace } from '../../engine';
import { saveExperiment } from '../../db';
import { FurnaceProfile, LottoPick, AuraVector } from '../../types/furnace';
import { MOTIVES, MENTAL_STATES, ACTIVITY_FIELDS } from '../../types/motive';
import { generateAuraVector } from '../../engine/aura';

interface MirrorPair {
  from: number;
  to: number;
}

interface ValidationError {
  front?: string;
  back?: string;
}

function formatLocalDate(date = new Date()): string {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, '0');
  const d = String(date.getDate()).padStart(2, '0');
  return `${y}${m}${d}`;
}

function getLocalDateString(): string {
  const y = new Date().getFullYear();
  const m = String(new Date().getMonth() + 1).padStart(2, '0');
  const d = String(new Date().getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

function stringArrayToNumbers(strArray: string[]): number[] {
  return strArray.map(s => parseInt(s, 10)).filter(n => !isNaN(n) && n >= 1);
}

function validateFront(strArray: string[]): string | undefined {
  const numbers = stringArrayToNumbers(strArray);
  if (numbers.length !== 5) return '前区必须恰好5个数字';
  for (const n of numbers) {
    if (n < 1 || n > 35) return '前区数字必须在1-35之间';
  }
  const unique = new Set(numbers);
  if (unique.size !== numbers.length) return '前区数字不能重复';
  return undefined;
}

function validateBack(strArray: string[]): string | undefined {
  const numbers = stringArrayToNumbers(strArray);
  if (numbers.length !== 2) return '后区必须恰好2个数字';
  for (const n of numbers) {
    if (n < 1 || n > 12) return '后区数字必须在1-12之间';
  }
  const unique = new Set(numbers);
  if (unique.size !== numbers.length) return '后区数字不能重复';
  return undefined;
}

interface FurnacePageProps {
  onNavigate: (page: string) => void;
}

export function FurnacePage({ onNavigate }: FurnacePageProps) {
  const [previousFront, setPreviousFront] = useState<string[]>(['', '', '', '', '']);
  const [previousBack, setPreviousBack] = useState<string[]>(['', '']);
  const [drawNo, setDrawNo] = useState<string>('');
  const [furnaceName, setFurnaceName] = useState<string>('');
  const [selectedMotives, setSelectedMotives] = useState<string[]>([]);
  const [mentalStates, setMentalStates] = useState<string[]>([]);
  const [activityFields, setActivityFields] = useState<string[]>([]);
  const [chaosTemp, setChaosTemp] = useState<number>(0.5);
  const [isRunning, setIsRunning] = useState(false);
  const [picks, setPicks] = useState<LottoPick[]>([]);
  const [aura, setAura] = useState<AuraVector | null>(null);
  const [fingerprint, setFingerprint] = useState('');
  const [showProfilePanel, setShowProfilePanel] = useState(true);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [validationError, setValidationError] = useState<ValidationError>({});
  const [experimentId, setExperimentId] = useState<string>('');
  const [safetyMessages, setSafetyMessages] = useState<string[]>([]);

  const previousFrontNums = stringArrayToNumbers(previousFront);
  const previousBackNums = stringArrayToNumbers(previousBack);
  
  const frontMirrorPairs: MirrorPair[] = previousFrontNums.map(n => ({
    from: n,
    to: 36 - n,
  }));
  
  const backMirrorPairs: MirrorPair[] = previousBackNums.map(n => ({
    from: n,
    to: 13 - n,
  }));

  const selectedMotiveObjects = useMemo(() => 
    MOTIVES.filter(m => selectedMotives.includes(m.id)),
    [selectedMotives]
  );

  const selectedMentalStateObjects = useMemo(() =>
    MENTAL_STATES.filter(s => mentalStates.includes(s.id)),
    [mentalStates]
  );

  const selectedActivityObjects = useMemo(() =>
    ACTIVITY_FIELDS.filter(a => activityFields.includes(a.id)),
    [activityFields]
  );

  const motiveHeatDelta = useMemo(() => 
    selectedMotiveObjects.reduce((sum, m) => sum + m.furnaceHeatDelta, 0),
    [selectedMotiveObjects]
  );

  const mentalStateHeatDelta = useMemo(() =>
    selectedMentalStateObjects.length * 3,
    [selectedMentalStateObjects]
  );

  const activityHeatDelta = useMemo(() =>
    selectedActivityObjects.length * 2,
    [selectedActivityObjects]
  );

  const nameHeatDelta = furnaceName ? 5 : 0;
  const mirrorHeatDelta = previousFrontNums.length === 5 && previousBackNums.length === 2 ? 10 : 0;

  const totalElementsCount = 
    (selectedMotives.length > 0 ? 1 : 0) +
    (mentalStates.length > 0 ? 1 : 0) +
    (activityFields.length > 0 ? 1 : 0) +
    (furnaceName ? 1 : 0) +
    (previousFrontNums.length === 5 ? 1 : 0);

  const baseFurnaceTemp = 20;
  const calculatedFurnaceTemp = Math.min(100, Math.max(5, 
    baseFurnaceTemp + 
    motiveHeatDelta + 
    mentalStateHeatDelta + 
    activityHeatDelta + 
    nameHeatDelta + 
    mirrorHeatDelta +
    totalElementsCount * 5
  ));

  const attentionDelta = useMemo(() => 
    selectedMotiveObjects.reduce((sum, m) => sum + m.attentionDelta, 0),
    [selectedMotiveObjects]
  );

  const calculatedChaosDelta = useMemo(() => 
    selectedMotiveObjects.reduce((sum, m) => sum + m.chaosDelta, 0),
    [selectedMotiveObjects]
  );

  const hasRiskyMotive = selectedMotiveObjects.some(m => m.safetyLevel === 'warn');
  const hasWatchMotive = selectedMotiveObjects.some(m => m.safetyLevel === 'watch');
  const hasRiskyActivity = selectedActivityObjects.some(a => a.safetyLevel === 'warn');
  const hasWatchActivity = selectedActivityObjects.some(a => a.safetyLevel === 'watch');

  const mainMentalState = mentalStates[0];
  const secondaryMentalState = mentalStates[1];

  const calculateUniverseAttention = () => {
    let attention = 50 + attentionDelta;
    if (mainMentalState) attention += 10;
    if (secondaryMentalState) attention += 5;
    if (activityFields.length > 0) attention += activityFields.length * 5;
    if (furnaceName) attention += 5;
    if (totalElementsCount > 0) attention += totalElementsCount * 5;
    if (attention >= 80) return '极高';
    if (attention >= 60) return '高';
    if (attention >= 40) return '中';
    if (attention >= 20) return '低';
    return '极低';
  };

  const previewAura = useMemo(() => {
    if (totalElementsCount === 0) return null;
    
    const previewProfile: FurnaceProfile = {
      nickname: furnaceName || undefined,
      motiveIds: selectedMotives,
      mentalStates: mentalStates,
      activityFields: activityFields,
    };
    
    return generateAuraVector(previewProfile, previousFrontNums, previousBackNums);
  }, [furnaceName, selectedMotives, mentalStates, activityFields, previousFrontNums, previousBackNums, totalElementsCount]);

  const getMainPhase = (auraVec: AuraVector | null) => {
    if (!auraVec) return '待';
    const phases = [
      { name: '木', val: auraVec.wood },
      { name: '火', val: auraVec.fire },
      { name: '土', val: auraVec.earth },
      { name: '金', val: auraVec.metal },
      { name: '水', val: auraVec.water },
    ];
    return phases.sort((a, b) => b.val - a.val)[0].name;
  };

  const getSecondaryPhase = (auraVec: AuraVector | null) => {
    if (!auraVec) return '成';
    const phases = [
      { name: '木', val: auraVec.wood },
      { name: '火', val: auraVec.fire },
      { name: '土', val: auraVec.earth },
      { name: '金', val: auraVec.metal },
      { name: '水', val: auraVec.water },
    ];
    return phases.sort((a, b) => b.val - a.val)[1].name;
  };

  useEffect(() => {
    setDrawNo(formatLocalDate());
  }, []);

  useEffect(() => {
    const messages: string[] = [];
    selectedMotiveObjects.forEach(m => {
      if (m.safetyMessage) {
        messages.push(m.safetyMessage);
      }
    });
    selectedActivityObjects.forEach(a => {
      if (a.safetyMessage) {
        messages.push(a.safetyMessage);
      }
    });
    setSafetyMessages(messages);
  }, [selectedMotiveObjects, selectedActivityObjects]);

  const handleMotiveToggle = (motiveId: string) => {
    setSelectedMotives(prev => {
      if (prev.includes(motiveId)) {
        return prev.filter(id => id !== motiveId);
      }
      if (prev.length >= 3) {
        return prev;
      }
      return [...prev, motiveId];
    });
  };

  const handleMentalStateToggle = (stateId: string) => {
    setMentalStates(prev => {
      if (prev.includes(stateId)) {
        return prev.filter(id => id !== stateId);
      }
      if (prev.length >= 2) {
        return prev;
      }
      return [...prev, stateId];
    });
  };

  const handleActivityToggle = (activityId: string) => {
    setActivityFields(prev => {
      if (prev.includes(activityId)) {
        return prev.filter(id => id !== activityId);
      }
      if (prev.length >= 3) {
        return prev;
      }
      return [...prev, activityId];
    });
  };

  const canOpenFurnace = selectedMotives.length >= 1;
  const furnaceReadyMessage = canOpenFurnace 
    ? '已具备开炉条件，可提交本次符号算力' 
    : '请至少注入 1 个缘起，方可开炉';

  const handleRunFurnace = async () => {
    const frontNums = stringArrayToNumbers(previousFront);
    const backNums = stringArrayToNumbers(previousBack);
    
    const frontError = validateFront(previousFront);
    const backError = validateBack(previousBack);
    
    setValidationError({ front: frontError, back: backError });
    
    if (frontError || backError) {
      return;
    }

    if (!canOpenFurnace) {
      return;
    }
    
    setIsRunning(true);
    
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const profile: FurnaceProfile = {
      nickname: furnaceName || undefined,
      motiveIds: selectedMotives,
      mentalStates: mentalStates,
      activityFields: activityFields,
    };
    
    const finalChaosTemp = Math.max(0.1, Math.min(0.9, chaosTemp + calculatedChaosDelta));
    
    const input = {
      date: getLocalDateString(),
      drawNo: drawNo || formatLocalDate(),
      previousFront: frontNums,
      previousBack: backNums,
      profile,
      chaosTemperature: finalChaosTemp,
      salt: Math.random().toString(36).substr(2, 9),
    };
    
    const output = runFurnace(input);
    
    setPicks(output.picks);
    setAura(output.auraVector);
    setFingerprint(output.fingerprint);
    setIsRunning(false);
    setValidationError({});
    
    const id = await saveExperiment({
      drawNo: input.drawNo,
      date: input.date,
      mode: 'multi_element',
      profileId: 'default',
      seed: output.seed,
      inputJson: JSON.stringify(input),
      auraJson: JSON.stringify(output.auraVector),
      outputJson: JSON.stringify(output.picks),
    });
    
    setExperimentId(id);
  };

  return (
    <div className="min-h-screen bg-furnace-darker text-gray-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        <header className="text-center mb-8">
          <h1 className="text-4xl md:text-5xl font-bold text-furnace-gold mb-2">
            天道哈希炉
          </h1>
          <p className="text-gray-400">
            本次开炉 · 凑齐要素再起火
          </p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <div className="lg:col-span-2 space-y-6">
            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-xl font-bold text-furnace-gold">炉体状态</h2>
                <span className={`px-3 py-1 rounded-full text-sm ${
                  totalElementsCount > 0 ? 'bg-green-900/50 text-green-400' : 'bg-yellow-900/50 text-yellow-400'
                }`}>
                  {totalElementsCount > 0 ? `${totalElementsCount} 个要素已入炉` : '等待入炉'}
                </span>
              </div>
              
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
                <div className="bg-furnace-darker rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-furnace-gold">{calculatedFurnaceTemp}%</div>
                  <div className="text-xs text-gray-500">炉温</div>
                </div>
                <div className="bg-furnace-darker rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-blue-400">{Math.round((1 - chaosTemp) * 100)}%</div>
                  <div className="text-xs text-gray-500">虚象稳定度</div>
                </div>
                <div className="bg-furnace-darker rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-purple-400">{calculateUniverseAttention()}</div>
                  <div className="text-xs text-gray-500">宇宙注意力</div>
                </div>
                <div className="bg-furnace-darker rounded-lg p-3 text-center">
                  <div className="text-2xl font-bold text-orange-400">{chaosTemp.toFixed(2)}</div>
                  <div className="text-xs text-gray-500">混沌温度</div>
                </div>
              </div>

              <div className="mb-6 space-y-4">
                <NumberGridInput
                  label="前区"
                  count={5}
                  min={1}
                  max={35}
                  values={previousFront}
                  onChange={(vals) => {
                    setPreviousFront(vals);
                    setValidationError(prev => ({ ...prev, front: undefined }));
                  }}
                  error={validationError.front}
                />
                <NumberGridInput
                  label="后区"
                  count={2}
                  min={1}
                  max={12}
                  values={previousBack}
                  onChange={(vals) => {
                    setPreviousBack(vals);
                    setValidationError(prev => ({ ...prev, back: undefined }));
                  }}
                  error={validationError.back}
                />
                <p className="text-xs text-gray-600">支持粘贴：1 2 3 4 5 / 01 02 03 04 05 / 0102030405</p>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-gray-400 mb-2">混沌温度（冷炉 ←→ 疯炉）</label>
                <div className="flex items-center gap-4">
                  <span className="text-sm text-blue-400">冷炉</span>
                  <input
                    type="range"
                    min="0"
                    max="1"
                    step="0.05"
                    value={chaosTemp}
                    onChange={(e) => setChaosTemp(parseFloat(e.target.value))}
                    className="flex-1 h-2 bg-furnace-darker rounded-full appearance-none cursor-pointer accent-furnace-gold"
                  />
                  <span className="text-sm text-red-400">疯炉</span>
                  <span className="text-furnace-gold font-mono w-12 text-right">{chaosTemp.toFixed(2)}</span>
                </div>
                <div className="mt-2 text-xs text-gray-500">
                  {chaosTemp < 0.3 ? '低混沌：号码更均衡稳定' : chaosTemp > 0.7 ? '高混沌：号码更跳更怪更随机' : '中混沌：平衡之选'}
                </div>
              </div>

              <div className="mb-6">
                <label className="block text-sm text-gray-400 mb-2">现实区块期号</label>
                <input
                  type="text"
                  value={drawNo}
                  onChange={(e) => setDrawNo(e.target.value)}
                  className="w-full bg-furnace-darker border border-furnace-gold/30 rounded-lg px-4 py-2 text-furnace-gold"
                />
              </div>

              <button
                onClick={() => setShowProfilePanel(!showProfilePanel)}
                className="w-full bg-furnace-darker border border-furnace-gold/30 rounded-lg px-4 py-3 text-furnace-gold hover:bg-furnace-gold/10 transition-all flex items-center justify-between"
              >
                <span>开炉缘起配置</span>
                <span>{showProfilePanel ? '▼' : '▲'}</span>
              </button>

              {showProfilePanel && (
                <div className="mt-4 space-y-6">
                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm text-gray-400">今日为何开炉？</label>
                      <span className="text-xs px-2 py-1 bg-furnace-gold/20 text-furnace-gold rounded">
                        已选 {selectedMotives.length}/3
                      </span>
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                      {MOTIVES.map((motive) => {
                        const isSelected = selectedMotives.includes(motive.id);
                        return (
                          <button
                            key={motive.id}
                            onClick={() => handleMotiveToggle(motive.id)}
                            disabled={!isSelected && selectedMotives.length >= 3}
                            className={`relative px-3 py-2 rounded-lg text-sm transition-all ${
                              isSelected
                                ? motive.safetyLevel === 'warn'
                                  ? 'bg-red-900/50 border-red-600/50 text-red-300 border'
                                  : motive.safetyLevel === 'watch'
                                  ? 'bg-yellow-900/30 border-yellow-700/50 text-yellow-300 border'
                                  : 'bg-furnace-gold/20 border-furnace-gold/50 text-furnace-gold border'
                                : motive.safetyLevel === 'warn'
                                ? 'bg-red-900/20 border-red-800/30 text-red-400/70 border'
                                : motive.safetyLevel === 'watch'
                                ? 'bg-yellow-900/20 border-yellow-800/30 text-yellow-400/70 border'
                                : 'bg-furnace-darker text-gray-400 hover:bg-furnace-gold/10'
                            } ${!isSelected && selectedMotives.length >= 3 ? 'opacity-50 cursor-not-allowed' : ''}`}
                          >
                            <div className="flex items-center gap-1">
                              {motive.label}
                              {isSelected && motive.tag && (
                                <span className="text-xs opacity-70">({motive.tag})</span>
                              )}
                            </div>
                            {isSelected && motive.safetyLevel === 'warn' && (
                              <div className="absolute bottom-1 right-1 text-xs text-red-400">
                                小额
                              </div>
                            )}
                            {isSelected && motive.isAuspicious && (
                              <div className="absolute top-1 right-1 text-xs text-cyan-400">
                                吉
                              </div>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm text-gray-400">今日心象（主/副）</label>
                      <span className="text-xs px-2 py-1 bg-purple-900/50 text-purple-400 rounded">
                        已选 {mentalStates.length}/2
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {MENTAL_STATES.map((state) => {
                        const isSelected = mentalStates.includes(state.id);
                        const isPrimary = mentalStates[0] === state.id;
                        return (
                          <button
                            key={state.id}
                            onClick={() => handleMentalStateToggle(state.id)}
                            disabled={!isSelected && mentalStates.length >= 2}
                            className={`relative px-3 py-2 rounded-lg text-sm transition-all ${
                              isSelected
                                ? isPrimary
                                  ? 'bg-purple-600 text-white'
                                  : 'bg-purple-900/50 border-purple-600/50 text-purple-300 border'
                                : 'bg-furnace-darker text-gray-400 hover:bg-purple-600/30'
                            } ${!isSelected && mentalStates.length >= 2 ? 'opacity-50 cursor-not-allowed' : ''}`}
                          >
                            {state.icon} {state.label}
                            {isPrimary && isSelected && (
                              <span className="text-xs ml-1">主</span>
                            )}
                            {!isPrimary && isSelected && (
                              <span className="text-xs ml-1 opacity-70">辅</span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <div>
                    <div className="flex items-center justify-between mb-2">
                      <label className="block text-sm text-gray-400">今日场域（正在做什么）</label>
                      <span className="text-xs px-2 py-1 bg-blue-900/50 text-blue-400 rounded">
                        已选 {activityFields.length}/3
                      </span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {ACTIVITY_FIELDS.map((field) => {
                        const isSelected = activityFields.includes(field.id);
                        return (
                          <button
                            key={field.id}
                            onClick={() => handleActivityToggle(field.id)}
                            disabled={!isSelected && activityFields.length >= 3}
                            className={`relative px-3 py-2 rounded-lg text-sm transition-all ${
                              isSelected
                                ? field.isHighContext
                                  ? 'bg-cyan-600/80 text-white'
                                  : 'bg-blue-600 text-white'
                                : 'bg-furnace-darker text-gray-400 hover:bg-blue-600/30'
                            } ${!isSelected && activityFields.length >= 3 ? 'opacity-50 cursor-not-allowed' : ''}`}
                          >
                            {field.icon} {field.label}
                            {isSelected && field.safetyLevel && (
                              <span className="text-xs ml-1">
                                {field.safetyLevel === 'warn' ? '⚠️' : field.safetyLevel === 'watch' ? '⚡' : ''}
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  {(hasRiskyMotive || hasWatchMotive || hasRiskyActivity || hasWatchActivity) && (
                    <div className={`p-3 rounded-lg border ${
                      hasRiskyMotive || hasRiskyActivity 
                        ? 'bg-red-900/30 border-red-700/50' 
                        : 'bg-yellow-900/30 border-yellow-700/50'
                    }`}>
                      {safetyMessages.map((msg, idx) => (
                        <p key={idx} className={hasRiskyMotive || hasRiskyActivity ? 'text-red-300' : 'text-yellow-300'}>
                          ⚠️ {msg}
                        </p>
                      ))}
                    </div>
                  )}

                  <div>
                    <button
                      onClick={() => setShowAdvanced(!showAdvanced)}
                      className="w-full bg-furnace-darker border border-furnace-gold/20 rounded-lg px-4 py-2 text-gray-400 hover:bg-furnace-gold/5 transition-all flex items-center justify-between"
                    >
                      <span>高级投料（可选）</span>
                      <span>{showAdvanced ? '▼' : '▲'}</span>
                    </button>
                    {showAdvanced && (
                      <div className="mt-3 space-y-3">
                        <input
                          type="text"
                          value={furnaceName}
                          onChange={(e) => setFurnaceName(e.target.value)}
                          placeholder="给这炉留个名字（例如：深夜路过派）"
                          className="w-full bg-furnace-darker border border-furnace-gold/20 rounded-lg px-4 py-2 text-gray-300 placeholder-gray-600"
                        />
                        <div className="text-xs text-gray-500">
                          <p>喜好数字、出生信息、图片取象等高级功能正在开发中...</p>
                        </div>
                      </div>
                    )}
                  </div>

                  <div className="p-4 bg-gradient-to-r from-furnace-gold/10 to-transparent rounded-lg border border-furnace-gold/20">
                    <div className="text-sm text-furnace-gold font-medium mb-3">本次入炉概况</div>
                    <div className="grid grid-cols-2 gap-4 text-xs">
                      <div>
                        <div className="text-gray-500 mb-1">缘起</div>
                        <div className="text-gray-300">
                          {selectedMotives.length > 0 
                            ? selectedMotiveObjects.map(m => m.label).join('、') 
                            : '未选择'}
                        </div>
                      </div>
                      <div>
                        <div className="text-gray-500 mb-1">心象</div>
                        <div className="text-gray-300">
                          {mainMentalState 
                            ? `${MENTAL_STATES.find(s => s.id === mainMentalState)?.label}${secondaryMentalState ? `、${MENTAL_STATES.find(s => s.id === secondaryMentalState)?.label}` : ''}`
                            : '未选择'}
                        </div>
                      </div>
                      <div>
                        <div className="text-gray-500 mb-1">场域</div>
                        <div className="text-gray-300">
                          {activityFields.length > 0 
                            ? selectedActivityObjects.map(a => a.label).join('、')
                            : '未选择'}
                        </div>
                      </div>
                      <div>
                        <div className="text-gray-500 mb-1">风险等级</div>
                        <div className={hasRiskyMotive || hasRiskyActivity ? 'text-red-400' : hasWatchMotive || hasWatchActivity ? 'text-yellow-400' : 'text-green-400'}>
                          {hasRiskyMotive || hasRiskyActivity ? '高提醒' : hasWatchMotive || hasWatchActivity ? '轻提醒' : '正常'}
                        </div>
                      </div>
                    </div>
                    <div className="mt-3 pt-3 border-t border-furnace-gold/20 grid grid-cols-3 gap-4 text-xs">
                      <div className="text-center">
                        <div className="text-furnace-gold font-bold">{calculatedFurnaceTemp}%</div>
                        <div className="text-gray-500">炉温</div>
                      </div>
                      <div className="text-center">
                        <div className="text-purple-400 font-bold">{calculateUniverseAttention()}</div>
                        <div className="text-gray-500">宇宙注意力</div>
                      </div>
                      <div className="text-center">
                        <div className="text-orange-400 font-bold">{(chaosTemp + calculatedChaosDelta).toFixed(2)}</div>
                        <div className="text-gray-500">混沌温度</div>
                      </div>
                    </div>
                    <div className="mt-3 flex justify-center gap-4 text-xs">
                      <span className="px-2 py-1 bg-furnace-gold/20 text-furnace-gold rounded">
                        主象: {getMainPhase(previewAura)}
                      </span>
                      <span className="px-2 py-1 bg-furnace-gold/10 text-gray-400 rounded">
                        辅象: {getSecondaryPhase(previewAura)}
                      </span>
                    </div>
                  </div>

                  <div className="text-center">
                    <p className={`text-sm mb-3 ${canOpenFurnace ? 'text-green-400' : 'text-yellow-400'}`}>
                      {furnaceReadyMessage}
                    </p>
                    <FurnaceButton 
                      onClick={handleRunFurnace} 
                      loading={isRunning} 
                      disabled={!canOpenFurnace || isRunning}
                    >
                      {isRunning ? '正在开炉...' : '开炉'}
                    </FurnaceButton>
                    <p className="text-xs text-gray-500 mt-2">
                      向随机宇宙提交本次 seed
                    </p>
                  </div>
                  
                  {experimentId && (
                    <div className="text-center text-sm text-gray-500">
                      实验已存档 · ID: {experimentId}
                    </div>
                  )}
                </div>
              )}
            </div>

            {picks.length > 0 && (
              <>
                {frontMirrorPairs.length > 0 && (
                  <MirrorMap
                    frontMirrorPairs={frontMirrorPairs}
                    backMirrorPairs={backMirrorPairs}
                  />
                )}

                <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-6">
                  <h2 className="text-xl font-bold text-furnace-gold mb-4 flex items-center gap-2">
                    <span>🎲</span>
                    <span>候选碰撞值</span>
                  </h2>
                  
                  <div className="space-y-4">
                    {picks.map((pick, index) => (
                      <div
                        key={index}
                        className="bg-furnace-darker rounded-lg p-4 border border-furnace-gold/20"
                      >
                        <div className="flex items-center gap-4">
                          <span className="text-furnace-gold font-bold w-8">
                            {String(index + 1).padStart(2, '0')}.
                          </span>
                          <div className="flex items-center gap-2">
                            {pick.front.map((num) => (
                              <NumberOrb key={`${index}-front-${num}`} number={num} />
                            ))}
                            <span className="text-gray-500 mx-2">+</span>
                            {pick.back.map((num) => (
                              <NumberOrb key={`${index}-back-${num}`} number={num} />
                            ))}
                          </div>
                        </div>
                        <p className="mt-2 text-sm text-gray-400 ml-12">
                          {pick.explanation}
                        </p>
                      </div>
                    ))}
                  </div>

                  <SafetyBanner />
                </div>
              </>
            )}
          </div>

          <div className="space-y-6">
            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
              <h3 className="text-furnace-gold font-bold mb-4">导航</h3>
              <nav className="space-y-2">
                <button
                  onClick={() => onNavigate('furnace')}
                  className="w-full text-left px-3 py-2 bg-furnace-gold/20 text-furnace-gold rounded-lg"
                >
                  🏭 开炉台
                </button>
                <button
                  onClick={() => onNavigate('logs')}
                  className="w-full text-left px-3 py-2 hover:bg-furnace-gold/10 text-gray-400 rounded-lg transition-colors"
                >
                  📜 实验日志
                </button>
                <button
                  onClick={() => onNavigate('result')}
                  className="w-full text-left px-3 py-2 hover:bg-furnace-gold/10 text-gray-400 rounded-lg transition-colors"
                >
                  📊 开奖复盘
                </button>
              </nav>
            </div>

            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
              <h3 className="text-furnace-gold font-bold mb-3">入炉要素</h3>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <span className={furnaceName ? 'text-green-400' : 'text-gray-600'}>{furnaceName ? '✓' : '○'}</span>
                  <span className={furnaceName ? 'text-furnace-gold' : 'text-gray-500'}>炉名 {furnaceName && `(${furnaceName})`}</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={selectedMotives.length > 0 ? 'text-green-400' : 'text-gray-600'}>{selectedMotives.length > 0 ? '✓' : '○'}</span>
                  <span className={selectedMotives.length > 0 ? 'text-furnace-gold' : 'text-gray-500'}>缘起 ({selectedMotives.length}/3)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={mentalStates.length > 0 ? 'text-green-400' : 'text-gray-600'}>{mentalStates.length > 0 ? '✓' : '○'}</span>
                  <span className={mentalStates.length > 0 ? 'text-purple-400' : 'text-gray-500'}>心象 ({mentalStates.length}/2)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={activityFields.length > 0 ? 'text-green-400' : 'text-gray-600'}>{activityFields.length > 0 ? '✓' : '○'}</span>
                  <span className={activityFields.length > 0 ? 'text-blue-400' : 'text-gray-500'}>场域 ({activityFields.length}/3)</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className="text-green-400">✓</span>
                  <span className="text-furnace-gold">混沌火种</span>
                </div>
                <div className="flex items-center gap-2">
                  <span className={previousFrontNums.length === 5 ? 'text-green-400' : 'text-gray-600'}>{previousFrontNums.length === 5 ? '✓' : '○'}</span>
                  <span className={previousFrontNums.length === 5 ? 'text-furnace-gold' : 'text-gray-500'}>反像数据</span>
                </div>
              </div>
            </div>

            {selectedMotiveObjects.length > 0 && (
              <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
                <h3 className="text-furnace-gold font-bold mb-3">缘起效果</h3>
                <div className="space-y-2 text-sm">
                  {selectedMotiveObjects.map(m => (
                    <div key={m.id} className={`bg-furnace-darker rounded p-2 ${
                      m.safetyLevel === 'warn' ? 'border border-red-700/30' : 
                      m.safetyLevel === 'watch' ? 'border border-yellow-700/30' : ''
                    }`}>
                      <div className="flex items-center justify-between">
                        <span className={m.safetyLevel === 'warn' ? 'text-red-300' : m.safetyLevel === 'watch' ? 'text-yellow-300' : 'text-furnace-gold'}>
                          {m.label}
                        </span>
                        {m.isAuspicious && <span className="text-cyan-400 text-xs">吉象</span>}
                      </div>
                      <div className="text-xs text-gray-500 mt-1">
                        炉温 {m.furnaceHeatDelta >= 0 ? '+' : ''}{m.furnaceHeatDelta}% · 
                        注意力 {m.attentionDelta >= 0 ? '+' : ''}{m.attentionDelta}% · 
                        混沌 {m.chaosDelta >= 0 ? '+' : ''}{m.chaosDelta.toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {aura && fingerprint && (
              <AuraPanel aura={aura} fingerprint={fingerprint} />
            )}

            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
              <h3 className="text-furnace-gold font-bold mb-2">今日中轴</h3>
              <div className="text-2xl font-bold text-furnace-gold">
                {new Date().toLocaleDateString('zh-CN', {
                  year: 'numeric',
                  month: 'long',
                  day: 'numeric',
                })}
              </div>
              <div className="mt-4 text-xs text-gray-500 space-y-1">
                <p>你不是在选号。</p>
                <p>你是在以自己为 seed，</p>
                <p>向随机宇宙提交一次带注意力权重的哈希。</p>
              </div>
            </div>
          </div>
        </div>

        <footer className="mt-12 text-center text-gray-600 text-sm">
          <p>小钱观测，宇宙回声 · 中奖不是神谕，只是碰撞奖励</p>
        </footer>
      </div>
    </div>
  );
}