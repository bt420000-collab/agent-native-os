import { useState, useEffect } from 'react';
import { NumberOrb } from '../../components/NumberOrb';
import { CollisionReport } from '../../components/CollisionReport';
import { calculateBestCollision } from '../../engine';
import { updateExperimentResult, getExperiments, initDb } from '../../db';
import { LottoPick, CollisionReport as CollisionReportType, Experiment } from '../../types/furnace';

interface ResultPageProps {
  onNavigate: (page: string) => void;
}

function parseNumbers(input: string): number[] {
  return input.split(/[\s,，,]+/).map(s => parseInt(s, 10)).filter(n => !isNaN(n) && n >= 1);
}

function validateFront(numbers: number[]): string | undefined {
  if (numbers.length !== 5) return '前区必须恰好5个数字';
  for (const n of numbers) {
    if (n < 1 || n > 35) return '前区数字必须在1-35之间';
  }
  const unique = new Set(numbers);
  if (unique.size !== numbers.length) return '前区数字不能重复';
  return undefined;
}

function validateBack(numbers: number[]): string | undefined {
  if (numbers.length !== 2) return '后区必须恰好2个数字';
  for (const n of numbers) {
    if (n < 1 || n > 12) return '后区数字必须在1-12之间';
  }
  const unique = new Set(numbers);
  if (unique.size !== numbers.length) return '后区数字不能重复';
  return undefined;
}

export function ResultPage({ onNavigate }: ResultPageProps) {
  const [experiments, setExperiments] = useState<Experiment[]>([]);
  const [selectedExpId, setSelectedExpId] = useState<string>('');
  const [drawNo, setDrawNo] = useState<string>('');
  const [frontResult, setFrontResult] = useState<string>('');
  const [backResult, setBackResult] = useState<string>('');
  const [hasResult, setHasResult] = useState(false);
  const [report, setReport] = useState<CollisionReportType | null>(null);
  const [selectedPickIndex, setSelectedPickIndex] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [frontError, setFrontError] = useState<string>();
  const [backError, setBackError] = useState<string>();

  useEffect(() => {
    loadExperiments();
  }, []);

  const loadExperiments = async () => {
    setLoading(true);
    await initDb();
    const exps = await getExperiments();
    setExperiments(exps);
    if (exps.length > 0) {
      setSelectedExpId(exps[0].id);
      setDrawNo(exps[0].drawNo);
    }
    setLoading(false);
  };

  const selectedExperiment = experiments.find(e => e.id === selectedExpId);
  let picks: LottoPick[] = [];
  if (selectedExperiment) {
    try {
      picks = JSON.parse(selectedExperiment.outputJson);
    } catch {
      picks = [];
    }
  }

  const handleExperimentChange = (id: string) => {
    const exp = experiments.find(e => e.id === id);
    if (exp) {
      setSelectedExpId(id);
      setDrawNo(exp.drawNo);
      setHasResult(false);
      setReport(null);
    }
  };

  const handleSubmit = async () => {
    const frontNums = parseNumbers(frontResult);
    const backNums = parseNumbers(backResult);
    
    const fe = validateFront(frontNums);
    const be = validateBack(backNums);
    setFrontError(fe);
    setBackError(be);
    
    if (fe || be) return;

    if (picks.length === 0) {
      alert('该实验无候选数据');
      return;
    }

    const result = {
      drawNo,
      front: frontNums,
      back: backNums,
    };

    const { report: collisionReport, pickIndex } = calculateBestCollision(picks, result);
    setReport(collisionReport);
    setSelectedPickIndex(pickIndex);
    setHasResult(true);

    await updateExperimentResult(
      selectedExpId,
      JSON.stringify(result),
      collisionReport.collisionLevel,
      collisionReport.reward
    );
  };

  const handleReset = () => {
    setFrontResult('');
    setBackResult('');
    setHasResult(false);
    setReport(null);
    setSelectedPickIndex(0);
    setFrontError(undefined);
    setBackError(undefined);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-furnace-darker text-gray-100 p-4 md:p-8">
        <div className="max-w-4xl mx-auto text-center py-12">
          <div className="inline-block w-8 h-8 border-2 border-furnace-gold border-t-transparent rounded-full animate-spin" />
          <p className="mt-4 text-gray-400">加载实验数据...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-furnace-darker text-gray-100 p-4 md:p-8">
      <div className="max-w-4xl mx-auto">
        <header className="mb-8">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-3xl font-bold text-furnace-gold mb-2">开奖复盘</h1>
              <p className="text-gray-400">录入开奖结果，生成碰撞报告</p>
            </div>
            <button
              onClick={() => onNavigate('furnace')}
              className="px-4 py-2 bg-furnace-gold text-black rounded-lg font-bold hover:bg-furnace-copper transition-colors"
            >
              🏭 开炉
            </button>
          </div>
        </header>

        {!hasResult ? (
          <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-6">
            <h2 className="text-xl font-bold text-furnace-gold mb-6">选择实验并录入开奖结果</h2>

            <div className="space-y-4">
              <div>
                <label className="block text-sm text-gray-400 mb-2">选择实验记录</label>
                <select
                  value={selectedExpId}
                  onChange={(e) => handleExperimentChange(e.target.value)}
                  className="w-full bg-furnace-darker border border-furnace-gold/30 rounded-lg px-4 py-3 text-furnace-gold"
                >
                  {experiments.length === 0 && <option value="">暂无实验记录</option>}
                  {experiments.map(exp => (
                    <option key={exp.id} value={exp.id}>
                      实验 {exp.id} · {exp.date} · {exp.drawNo} · {exp.mode}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm text-gray-400 mb-2">期号</label>
                <input
                  type="text"
                  value={drawNo}
                  onChange={(e) => setDrawNo(e.target.value)}
                  className="w-full bg-furnace-darker border border-furnace-gold/30 rounded-lg px-4 py-3 text-furnace-gold"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm text-gray-400 mb-2">前区开奖号码</label>
                  <input
                    type="text"
                    value={frontResult}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '').slice(0, 10);
                      const formatted = val.replace(/(\d{2})(?=\d)/g, '$1 ').trim();
                      setFrontResult(formatted);
                      setFrontError(undefined);
                    }}
                    placeholder="5个数字"
                    className={`w-full bg-furnace-darker border rounded-lg px-4 py-3 text-furnace-gold placeholder-gray-600 ${
                      frontError ? 'border-red-500' : 'border-furnace-gold/30'
                    }`}
                  />
                  {frontError && <p className="text-red-400 text-xs mt-1">{frontError}</p>}
                </div>
                <div>
                  <label className="block text-sm text-gray-400 mb-2">后区开奖号码</label>
                  <input
                    type="text"
                    value={backResult}
                    onChange={(e) => {
                      const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                      const formatted = val.replace(/(\d{2})(?=\d)/g, '$1 ').trim();
                      setBackResult(formatted);
                      setBackError(undefined);
                    }}
                    placeholder="2个数字"
                    className={`w-full bg-furnace-darker border rounded-lg px-4 py-3 text-furnace-gold placeholder-gray-600 ${
                      backError ? 'border-red-500' : 'border-furnace-gold/30'
                    }`}
                  />
                  {backError && <p className="text-red-400 text-xs mt-1">{backError}</p>}
                </div>
              </div>

              {picks.length > 0 && (
                <div className="bg-furnace-darker rounded-lg p-4">
                  <div className="text-sm text-gray-400 mb-2">该实验候选号码</div>
                  <div className="space-y-2">
                    {picks.map((pick, idx) => (
                      <div key={idx} className="flex items-center gap-4 flex-wrap">
                        <span className="text-furnace-gold w-8">{idx + 1}.</span>
                        {pick.front.map(n => <NumberOrb key={`f${n}`} number={n} />)}
                        <span className="text-gray-500">+</span>
                        {pick.back.map(n => <NumberOrb key={`b${n}`} number={n} />)}
                        <span className="text-gray-500 text-sm">({pick.explanation})</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="mt-6 flex justify-center">
                <button
                  onClick={handleSubmit}
                  disabled={experiments.length === 0}
                  className="px-8 py-4 bg-gradient-to-r from-furnace-gold to-furnace-copper text-black font-bold text-lg rounded-lg hover:from-furnace-copper hover:to-furnace-gold transition-all disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  提交碰撞检测
                </button>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-6">
              <h2 className="text-xl font-bold text-furnace-gold mb-4">开奖结果</h2>
              <div className="flex items-center gap-4 flex-wrap">
                {parseNumbers(frontResult).map((num, idx) => (
                  <NumberOrb key={`rf${idx}`} number={num} highlighted />
                ))}
                <span className="text-gray-500 text-2xl">+</span>
                {parseNumbers(backResult).map((num, idx) => (
                  <NumberOrb key={`rb${idx}`} number={num} highlighted />
                ))}
              </div>
              <p className="mt-2 text-sm text-gray-500">期号: {drawNo}</p>
            </div>

            <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-6">
              <h2 className="text-xl font-bold text-furnace-gold mb-4">最佳匹配候选</h2>
              <div className="flex items-center gap-4 flex-wrap">
                {picks[selectedPickIndex]?.front.map((num, idx) => (
                  <NumberOrb key={`pf${idx}`} number={num} highlighted={parseNumbers(frontResult).includes(num)} />
                ))}
                <span className="text-gray-500 text-2xl">+</span>
                {picks[selectedPickIndex]?.back.map((num, idx) => (
                  <NumberOrb key={`pb${idx}`} number={num} highlighted={parseNumbers(backResult).includes(num)} />
                ))}
              </div>
              <p className="mt-2 text-sm text-gray-400">
                {picks[selectedPickIndex]?.explanation}
              </p>
              <p className="mt-1 text-xs text-gray-600">
                第 {selectedPickIndex + 1} 注候选
              </p>
            </div>

            {report && <CollisionReport report={report} />}

            <div className="flex justify-center">
              <button
                onClick={handleReset}
                className="px-6 py-3 bg-furnace-darker border border-furnace-gold/50 text-furnace-gold rounded-lg font-bold hover:bg-furnace-gold/10 transition-colors"
              >
                继续复盘其他实验
              </button>
            </div>
          </div>
        )}

        <footer className="mt-12 text-center text-gray-600 text-sm">
          <p>小钱观测，宇宙回声 · 中奖不是神谕，只是碰撞奖励</p>
        </footer>
      </div>
    </div>
  );
}