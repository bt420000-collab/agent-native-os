export function SafetyBanner() {
  return (
    <div className="bg-furnace-crimson/20 border border-furnace-crimson/50 rounded-lg p-4 text-sm">
      <div className="flex items-center gap-2">
        <span className="text-furnace-crimson">⚠</span>
        <p className="text-gray-300">
          本系统不提升中奖概率。本次输出仅为个人符号碰撞值。请小额娱乐观测。
        </p>
      </div>
    </div>
  );
}