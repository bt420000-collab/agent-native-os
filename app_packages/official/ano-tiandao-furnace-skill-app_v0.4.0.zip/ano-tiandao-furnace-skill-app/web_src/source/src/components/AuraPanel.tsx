import { AuraVector } from '../types/furnace';

interface AuraPanelProps {
  aura: AuraVector;
  fingerprint: string;
}

const phaseNames: Record<string, string> = {
  wood: '木',
  fire: '火',
  earth: '土',
  metal: '金',
  water: '水',
};

export function AuraPanel({ aura, fingerprint }: AuraPanelProps) {
  const phases = [
    { key: 'wood', value: aura.wood, color: 'bg-green-500' },
    { key: 'fire', value: aura.fire, color: 'bg-red-500' },
    { key: 'earth', value: aura.earth, color: 'bg-yellow-600' },
    { key: 'metal', value: aura.metal, color: 'bg-gray-400' },
    { key: 'water', value: aura.water, color: 'bg-blue-500' },
  ];

  return (
    <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
      <div className="text-furnace-gold font-bold mb-3 flex items-center gap-2">
        <span>🏷</span>
        <span>个人气运指纹</span>
      </div>
      
      <div className="text-mono text-furnace-gold text-sm bg-furnace-darker px-3 py-2 rounded mb-4">
        {fingerprint}
      </div>
      
      <div className="text-furnace-gold font-bold mb-2">五行偏向</div>
      <div className="space-y-2">
        {phases.map(({ key, value, color }) => (
          <div key={key} className="flex items-center gap-2">
            <span className="w-6 text-center text-gray-400">{phaseNames[key]}</span>
            <div className="flex-1 h-2 bg-furnace-darker rounded-full overflow-hidden">
              <div
                className={`h-full ${color} transition-all duration-500`}
                style={{ width: `${value * 100}%` }}
              />
            </div>
            <span className="w-10 text-right text-sm text-gray-400">
              {Math.round(value * 100)}%
            </span>
          </div>
        ))}
      </div>
      
      <div className="mt-4 pt-4 border-t border-furnace-gold/20 grid grid-cols-2 gap-4 text-sm">
        <div>
          <div className="text-gray-500">阴</div>
          <div className="text-furnace-gold">{Math.round(aura.yin * 100)}%</div>
        </div>
        <div>
          <div className="text-gray-500">阳</div>
          <div className="text-furnace-gold">{Math.round(aura.yang * 100)}%</div>
        </div>
        <div>
          <div className="text-gray-500">动</div>
          <div className="text-furnace-gold">{Math.round(aura.motion * 100)}%</div>
        </div>
        <div>
          <div className="text-gray-500">静</div>
          <div className="text-furnace-gold">{Math.round(aura.stability * 100)}%</div>
        </div>
      </div>
      
      <div className="mt-4 pt-4 border-t border-furnace-gold/20">
        <div className="flex justify-between items-center">
          <span className="text-gray-500">混沌</span>
          <span className="text-furnace-gold">{aura.chaos.toFixed(2)}</span>
        </div>
      </div>
    </div>
  );
}