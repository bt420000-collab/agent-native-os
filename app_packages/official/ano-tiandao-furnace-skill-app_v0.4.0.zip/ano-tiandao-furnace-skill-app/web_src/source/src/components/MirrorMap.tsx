import { NumberOrb } from './NumberOrb';

interface MirrorPair {
  from: number;
  to: number;
}

interface MirrorMapProps {
  frontMirrorPairs: MirrorPair[];
  backMirrorPairs: MirrorPair[];
}

export function MirrorMap({ frontMirrorPairs, backMirrorPairs }: MirrorMapProps) {
  const sortedFrontMirror = [...frontMirrorPairs].map(p => p.to).sort((a, b) => a - b);

  return (
    <div className="bg-furnace-dark border border-furnace-gold/30 rounded-lg p-4">
      <div className="text-furnace-gold font-bold mb-4 flex items-center gap-2">
        <span>🔮</span>
        <span>逆时空反像</span>
      </div>
      
      <div className="space-y-4">
        <div>
          <div className="text-sm text-gray-500 mb-2">前区 · 已发生实象 → 未发生虚象</div>
          <div className="grid grid-cols-5 gap-2">
            {frontMirrorPairs.map((pair, index) => (
              <div key={`front-${index}`} className="flex flex-col items-center">
                <NumberOrb number={pair.from} size="sm" />
                <span className="text-xs text-gray-600 mt-1">→</span>
                <NumberOrb number={pair.to} size="sm" />
              </div>
            ))}
          </div>
          <div className="mt-2 text-sm text-gray-500">
            排序后: {sortedFrontMirror.join(' ')}
          </div>
        </div>
        
        <div>
          <div className="text-sm text-gray-500 mb-2">后区 · 已发生实象 → 未发生虚象</div>
          <div className="grid grid-cols-2 gap-4">
            {backMirrorPairs.map((pair, index) => (
              <div key={`back-${index}`} className="flex flex-col items-center">
                <NumberOrb number={pair.from} size="sm" />
                <span className="text-xs text-gray-600 mt-1">→</span>
                <NumberOrb number={pair.to} size="sm" />
              </div>
            ))}
          </div>
        </div>
        
        <div className="mt-4 pt-4 border-t border-furnace-gold/20 text-xs text-gray-500">
          <div>前区公式: x' = 36 - x</div>
          <div>后区公式: y' = 13 - y</div>
        </div>
      </div>
    </div>
  );
}