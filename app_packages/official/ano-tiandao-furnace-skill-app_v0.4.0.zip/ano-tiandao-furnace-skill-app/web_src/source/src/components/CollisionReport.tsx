import { CollisionReport as CollisionReportType } from '../types/furnace';

interface CollisionReportProps {
  report: CollisionReportType;
}

const levelStyles: Record<string, { bg: string; text: string; label: string }> = {
  silent: { bg: 'bg-gray-800', text: 'text-gray-400', label: '无声' },
  micro_echo: { bg: 'bg-blue-900/50', text: 'text-blue-400', label: '微响' },
  low_collision: { bg: 'bg-green-900/50', text: 'text-green-400', label: '低阶碰撞' },
  mid_collision: { bg: 'bg-yellow-900/50', text: 'text-yellow-400', label: '中阶碰撞' },
  high_collision: { bg: 'bg-red-900/50', text: 'text-red-400', label: '高阶碰撞' },
};

export function CollisionReport({ report }: CollisionReportProps) {
  const style = levelStyles[report.collisionLevel];
  
  return (
    <div className={`${style.bg} border ${style.text}/30 rounded-lg p-4`}>
      <div className="flex items-center justify-between mb-3">
        <span className={`font-bold ${style.text}`}>{style.label}</span>
        <span className="text-sm text-gray-400">
          前区重合: {report.frontHits} | 后区重合: {report.backHits}
        </span>
      </div>
      
      <p className="text-gray-300 text-sm">{report.summary}</p>
      
      {report.reward > 0 && (
        <div className="mt-3 pt-3 border-t border-gray-700">
          <div className="flex items-center justify-between">
            <span className="text-gray-500">现实奖励</span>
            <span className="text-furnace-gold font-bold">
              ¥{report.reward.toLocaleString()}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}