interface FurnaceButtonProps {
  onClick: () => void;
  disabled?: boolean;
  loading?: boolean;
  variant?: 'primary' | 'secondary';
  children: React.ReactNode;
}

export function FurnaceButton({ onClick, disabled, loading, variant = 'primary', children }: FurnaceButtonProps) {
  const baseClasses = `
    relative
    px-8 py-4
    font-bold text-lg
    rounded-lg
    transition-all duration-300
    transform
    disabled:opacity-50
    disabled:cursor-not-allowed
    disabled:transform-none
  `;
  
  const primaryClasses = `
    bg-gradient-to-r from-furnace-gold to-furnace-copper
    text-black
    hover:from-furnace-copper hover:to-furnace-gold
    hover:scale-105
    shadow-lg
    shadow-furnace-gold/30
    hover:shadow-furnace-gold/50
  `;
  
  const secondaryClasses = `
    bg-furnace-dark
    border-2 border-furnace-gold/50
    text-furnace-gold
    hover:bg-furnace-gold/10
    hover:border-furnace-gold
  `;
  
  return (
    <button
      onClick={onClick}
      disabled={disabled || loading}
      className={`${baseClasses} ${variant === 'primary' ? primaryClasses : secondaryClasses}`}
    >
      {loading ? (
        <span className="flex items-center gap-2">
          <span className="inline-block w-5 h-5 border-2 border-black/30 border-t-black rounded-full animate-spin" />
          {children}
        </span>
      ) : (
        children
      )}
    </button>
  );
}