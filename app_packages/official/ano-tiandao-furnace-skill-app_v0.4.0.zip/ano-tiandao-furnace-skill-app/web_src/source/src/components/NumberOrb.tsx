interface NumberOrbProps {
  number: number;
  size?: 'sm' | 'md' | 'lg';
  highlighted?: boolean;
  phase?: string;
}

const phaseColors: Record<string, string> = {
  wood: 'bg-green-500/20 border-green-500 text-green-400',
  fire: 'bg-red-500/20 border-red-500 text-red-400',
  earth: 'bg-yellow-600/20 border-yellow-600 text-yellow-500',
  metal: 'bg-gray-400/20 border-gray-400 text-gray-300',
  water: 'bg-blue-500/20 border-blue-500 text-blue-400',
};

export function NumberOrb({ number, size = 'md', highlighted = false, phase }: NumberOrbProps) {
  const sizeClasses = {
    sm: 'w-8 h-8 text-xs',
    md: 'w-10 h-10 text-sm',
    lg: 'w-14 h-14 text-lg',
  };
  
  return (
    <div
      className={`
        ${sizeClasses[size]}
        rounded-full
        flex items-center justify-center
        border-2
        font-bold
        ${phase ? phaseColors[phase] : 'bg-furnace-obsidian border-furnace-gold text-furnace-gold'}
        ${highlighted ? 'ring-2 ring-furnace-gold animate-pulse' : ''}
        transition-all duration-300
        hover:scale-110
      `}
    >
      {number.toString().padStart(2, '0')}
    </div>
  );
}