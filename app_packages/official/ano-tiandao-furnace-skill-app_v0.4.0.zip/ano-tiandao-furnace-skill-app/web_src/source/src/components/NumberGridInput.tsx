import { useRef, useState, useEffect } from 'react';

interface NumberGridInputProps {
  label: string;
  count: number;
  min: number;
  max: number;
  values: string[];
  onChange: (values: string[]) => void;
  error?: string;
}

export function NumberGridInput({ label, count, min, max, values, onChange, error }: NumberGridInputProps) {
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const [focusIndex, setFocusIndex] = useState<number | null>(null);

  useEffect(() => {
    if (values.length !== count) {
      onChange(Array(count).fill(''));
    }
  }, [count, values.length, onChange]);

  const parseNumbers = (text: string): number[] => {
    const cleaned = text.replace(/[^\d\s,，,、]/g, ' ');
    let numbers: number[] = [];
    
    if (cleaned.includes(' ') || cleaned.includes(',') || cleaned.includes('，') || cleaned.includes('、')) {
      numbers = cleaned
        .split(/[\s,，,、]+/)
        .filter(s => s.length > 0)
        .map(s => parseInt(s, 10))
        .filter(n => !isNaN(n) && n >= 1);
    } else if (cleaned.length >= count * 1) {
      const digits = cleaned.replace(/\D/g, '');
      for (let i = 0; i < Math.min(count * 2, digits.length); i += 2) {
        const num = parseInt(digits.slice(i, i + 2), 10);
        if (!isNaN(num) && num >= 1) {
          numbers.push(num);
        }
      }
    } else {
      numbers = cleaned
        .split('')
        .filter(s => s.length > 0)
        .map(s => parseInt(s, 10))
        .filter(n => !isNaN(n) && n >= 1);
    }
    
    return numbers;
  };

  const formatNumber = (num: number | string): string => {
    const n = typeof num === 'string' ? parseInt(num, 10) : num;
    if (isNaN(n) || n < 1) return '';
    return String(n).padStart(2, '0');
  };

  const handleChange = (index: number, value: string) => {
    const cleaned = value.replace(/\D/g, '').slice(0, 2);
    
    const newValues = [...values];
    newValues[index] = cleaned;
    onChange(newValues);
    
    // 输入2位后不自动跳格，避免提前触发补零
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === 'Backspace') {
      if (values[index] === '' && index > 0) {
        inputRefs.current[index - 1]?.focus();
        setFocusIndex(index - 1);
      }
    } else if (e.key === 'ArrowLeft' && index > 0) {
      inputRefs.current[index - 1]?.focus();
      setFocusIndex(index - 1);
    } else if (e.key === 'ArrowRight' && index < count - 1) {
      inputRefs.current[index + 1]?.focus();
      setFocusIndex(index + 1);
    }
  };

  const handleBlur = (index: number) => {
    // 离开输入框时补零
    if (values[index].length === 1) {
      const num = parseInt(values[index], 10);
      if (!isNaN(num) && num >= 1) {
        const newValues = [...values];
        newValues[index] = formatNumber(num);
        onChange(newValues);
      }
    }
    setFocusIndex(null);
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');
    const numbers = parseNumbers(pastedText);
    
    if (numbers.length > 0) {
      const newValues = Array(count).fill('');
      for (let i = 0; i < Math.min(count, numbers.length); i++) {
        newValues[i] = formatNumber(numbers[i]);
      }
      onChange(newValues);
      
      const nextIndex = Math.min(numbers.length, count - 1);
      setTimeout(() => {
        inputRefs.current[nextIndex]?.focus();
        setFocusIndex(nextIndex);
      }, 0);
    }
  };

  const isOutOfRange = (value: string): boolean => {
    if (!value) return false;
    const num = parseInt(value, 10);
    return isNaN(num) || num < min || num > max;
  };

  const getDuplicateIndices = (): number[] => {
    const map = new Map<string, number[]>();
    values.forEach((v, i) => {
      if (v) {
        const key = v;
        if (!map.has(key)) map.set(key, []);
        map.get(key)!.push(i);
      }
    });
    const duplicates: number[] = [];
    map.forEach((indices, _) => {
      if (indices.length > 1) {
        duplicates.push(...indices);
      }
    });
    return duplicates;
  };

  const duplicateIndices = getDuplicateIndices();

  return (
    <div className="space-y-2">
      <label className="block text-sm text-gray-400">{label}</label>
      <div className="flex items-center gap-2 flex-wrap">
        {Array.from({ length: count }).map((_, index) => {
          const isDuplicate = duplicateIndices.includes(index);
          const outOfRange = isOutOfRange(values[index]);
          const hasError = isDuplicate || outOfRange;
          
          return (
            <div key={index} className="relative">
              <input
                ref={(el) => (inputRefs.current[index] = el)}
                type="text"
                inputMode="numeric"
                value={values[index]}
                onChange={(e) => handleChange(index, e.target.value)}
                onKeyDown={(e) => handleKeyDown(index, e)}
                onBlur={() => handleBlur(index)}
                onPaste={handlePaste}
                onFocus={() => setFocusIndex(index)}
                className={`w-12 h-12 text-center text-xl font-bold rounded-lg border-2 bg-furnace-darker transition-all
                  ${hasError
                    ? 'border-red-500 text-red-400'
                    : focusIndex === index
                      ? 'border-furnace-gold text-furnace-gold shadow-[0_0_10px_rgba(212,175,55,0.5)]'
                      : 'border-furnace-gold/30 text-furnace-gold'
                  }
                `}
                maxLength={2}
              />
              {isDuplicate && (
                <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs px-1 rounded-full">
                  重
                </div>
              )}
              {outOfRange && !isDuplicate && (
                <div className="absolute -top-2 -right-2 bg-orange-500 text-white text-xs px-1 rounded-full">
                  ×
                </div>
              )}
            </div>
          );
        })}
      </div>
      {error && <p className="text-red-400 text-xs">{error}</p>}
    </div>
  );
}
