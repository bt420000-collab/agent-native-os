CREATE TABLE IF NOT EXISTS profiles (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT,
  profile_hash TEXT,
  profile_json TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS experiments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  draw_no TEXT,
  date TEXT,
  mode TEXT,
  profile_id INTEGER,
  seed TEXT,
  input_json TEXT,
  aura_json TEXT,
  output_json TEXT,
  result_json TEXT,
  collision_level TEXT,
  cost INTEGER DEFAULT 0,
  reward INTEGER DEFAULT 0,
  note TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS draws (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  draw_no TEXT UNIQUE,
  draw_date TEXT,
  front_json TEXT,
  back_json TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS settings (
  key TEXT PRIMARY KEY,
  value TEXT
);