import { Experiment, FurnaceMode } from '../types/furnace';

const STORAGE_KEYS = {
  experiments: 'tdhf_experiments',
  draws: 'tdhf_draws',
  settings: 'tdhf_settings',
};

function getStored<T>(key: string, defaultValue: T): T {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : defaultValue;
  } catch {
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  localStorage.setItem(key, JSON.stringify(value));
}

export function initDb(): Promise<void> {
  getStored<Experiment[]>(STORAGE_KEYS.experiments, []);
  getStored<unknown[]>(STORAGE_KEYS.draws, []);
  getStored<Record<string, string>>(STORAGE_KEYS.settings, {});
  return Promise.resolve();
}

export function saveExperiment(data: {
  drawNo: string;
  date: string;
  mode: string;
  profileId: string;
  seed: string;
  inputJson: string;
  auraJson: string;
  outputJson: string;
}): Promise<string> {
  const experiments = getStored<Experiment[]>(STORAGE_KEYS.experiments, []);
  
  const newExperiment: Experiment = {
    id: Date.now().toString(),
    drawNo: data.drawNo,
    date: data.date,
    mode: data.mode as FurnaceMode,
    profileId: data.profileId,
    seed: data.seed,
    inputJson: data.inputJson,
    auraJson: data.auraJson,
    outputJson: data.outputJson,
    cost: 0,
    reward: 0,
    createdAt: new Date().toLocaleString('zh-CN'),
  };
  
  experiments.unshift(newExperiment);
  setStored(STORAGE_KEYS.experiments, experiments);
  
  return Promise.resolve(newExperiment.id);
}

export function getExperiments(): Promise<Experiment[]> {
  const experiments = getStored<Experiment[]>(STORAGE_KEYS.experiments, []);
  return Promise.resolve(experiments);
}

export function updateExperimentResult(
  experimentId: string,
  resultJson: string,
  collisionLevel: string,
  reward: number
): Promise<void> {
  const experiments = getStored<Experiment[]>(STORAGE_KEYS.experiments, []);
  const index = experiments.findIndex(e => e.id === experimentId);
  
  if (index !== -1) {
    experiments[index] = {
      ...experiments[index],
      resultJson,
      collisionLevel: collisionLevel as Experiment['collisionLevel'],
      reward,
    };
    setStored(STORAGE_KEYS.experiments, experiments);
  }
  
  return Promise.resolve();
}

export function saveDraw(drawNo: string, drawDate: string, front: number[], back: number[]): Promise<void> {
  const draws = getStored<unknown[]>(STORAGE_KEYS.draws, []);
  const existingIndex = draws.findIndex((d: unknown) => (d as { drawNo: string }).drawNo === drawNo);
  
  const drawData = { drawNo, drawDate, front, back, createdAt: new Date().toLocaleString('zh-CN') };
  
  if (existingIndex !== -1) {
    draws[existingIndex] = drawData;
  } else {
    draws.push(drawData);
  }
  
  setStored(STORAGE_KEYS.draws, draws);
  return Promise.resolve();
}

export function getDraw(drawNo: string): Promise<unknown | null> {
  const draws = getStored<unknown[]>(STORAGE_KEYS.draws, []);
  const draw = draws.find((d: unknown) => (d as { drawNo: string }).drawNo === drawNo);
  return Promise.resolve(draw || null);
}