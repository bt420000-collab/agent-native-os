export function rgbToHsl(r: number, g: number, b: number): { h: number; s: number; l: number } {
  r /= 255;
  g /= 255;
  b /= 255;
  
  const max = Math.max(r, g, b);
  const min = Math.min(r, g, b);
  let h = 0;
  let s = 0;
  const l = (max + min) / 2;
  
  if (max !== min) {
    const d = max - min;
    s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
    
    switch (max) {
      case r:
        h = ((g - b) / d + (g < b ? 6 : 0)) / 6;
        break;
      case g:
        h = ((b - r) / d + 2) / 6;
        break;
      case b:
        h = ((r - g) / d + 4) / 6;
        break;
    }
  }
  
  return { h: h * 360, s: s * 100, l: l * 100 };
}

export function getPhaseFromRgb(r: number, g: number, b: number): { phase: string; weight: number } {
  const { h, s, l } = rgbToHsl(r, g, b);
  
  if (l < 10) return { phase: 'water', weight: 0.8 };
  if (l > 90) return { phase: 'metal', weight: 0.8 };
  if (s < 20) return { phase: 'metal', weight: 0.7 };
  
  if (h >= 120 && h < 180) {
    return { phase: 'wood', weight: Math.min(1, s / 50) };
  }
  if (h >= 0 && h < 45) {
    return { phase: 'fire', weight: Math.min(1, s / 50) };
  }
  if (h >= 45 && h < 60) {
    return { phase: 'earth', weight: Math.min(1, s / 50) };
  }
  if (h >= 180 && h < 250) {
    return { phase: 'water', weight: Math.min(1, s / 50) };
  }
  if (h >= 250 && h < 360) {
    return { phase: 'metal', weight: Math.min(1, s / 50) };
  }
  
  return { phase: 'earth', weight: 0.5 };
}

export function getWarmth(r: number, g: number, b: number): number {
  const warmth = (r + g - b) / (255 * 2);
  return Math.max(0, Math.min(1, warmth));
}