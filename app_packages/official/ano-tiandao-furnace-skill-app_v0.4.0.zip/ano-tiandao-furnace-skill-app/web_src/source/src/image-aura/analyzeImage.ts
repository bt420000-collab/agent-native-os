import { ImageAuraSummary } from '../types/furnace';
import { getPhaseFromRgb, getWarmth, rgbToHsl } from './colorToPhase';

export async function analyzeImageData(imageData: ImageData): Promise<ImageAuraSummary> {
  const { data, width, height } = imageData;
  
  let totalR = 0, totalG = 0, totalB = 0;
  let totalBrightness = 0;
  let totalWarmth = 0;
  let totalSaturation = 0;
  
  const phaseCounts: Record<string, number> = {
    wood: 0,
    fire: 0,
    earth: 0,
    metal: 0,
    water: 0,
  };
  
  const step = Math.max(1, Math.floor((width * height) / 1000));
  let pixelCount = 0;
  
  for (let i = 0; i < data.length; i += 4 * step) {
    const r = data[i];
    const g = data[i + 1];
    const b = data[i + 2];
    const alpha = data[i + 3];
    
    if (alpha < 128) continue;
    
    totalR += r;
    totalG += g;
    totalB += b;
    
    const { s, l } = rgbToHsl(r, g, b);
    totalBrightness += l;
    totalSaturation += s;
    totalWarmth += getWarmth(r, g, b);
    
    const { phase, weight } = getPhaseFromRgb(r, g, b);
    phaseCounts[phase] += weight;
    
    pixelCount++;
  }
  
  if (pixelCount === 0) {
    return {
      dominantColors: [],
      brightness: 0.5,
      warmth: 0.5,
      saturation: 0.5,
      phaseBias: {
        wood: 0.2,
        fire: 0.2,
        earth: 0.2,
        metal: 0.2,
        water: 0.2,
      },
      symbolicTags: [],
    };
  }
  
  const avgR = Math.round(totalR / pixelCount);
  const avgG = Math.round(totalG / pixelCount);
  const avgB = Math.round(totalB / pixelCount);
  
  const brightness = Math.min(1, (totalBrightness / pixelCount) / 100);
  const warmth = totalWarmth / pixelCount;
  const saturation = Math.min(1, (totalSaturation / pixelCount) / 100);
  
  const totalPhase = Object.values(phaseCounts).reduce((a, b) => a + b, 0);
  const phaseBias = {
    wood: totalPhase > 0 ? phaseCounts.wood / totalPhase : 0.2,
    fire: totalPhase > 0 ? phaseCounts.fire / totalPhase : 0.2,
    earth: totalPhase > 0 ? phaseCounts.earth / totalPhase : 0.2,
    metal: totalPhase > 0 ? phaseCounts.metal / totalPhase : 0.2,
    water: totalPhase > 0 ? phaseCounts.water / totalPhase : 0.2,
  };
  
  const dominantColors = [
    `rgb(${avgR},${avgG},${avgB})`,
  ];
  
  const symbolicTags: string[] = [];
  if (warmth > 0.6) symbolicTags.push('warm');
  if (warmth < 0.4) symbolicTags.push('cool');
  if (saturation > 0.6) symbolicTags.push('vivid');
  if (saturation < 0.3) symbolicTags.push('muted');
  if (brightness > 0.7) symbolicTags.push('bright');
  if (brightness < 0.3) symbolicTags.push('dark');
  
  const sortedPhases = Object.entries(phaseBias)
    .sort((a, b) => b[1] - a[1])
    .slice(0, 2);
  
  const phaseSymbols: Record<string, string> = {
    wood: '木',
    fire: '火',
    earth: '土',
    metal: '金',
    water: '水',
  };
  
  sortedPhases.forEach(([phase]) => {
    symbolicTags.push(phaseSymbols[phase]);
  });
  
  return {
    dominantColors,
    brightness,
    warmth,
    saturation,
    phaseBias,
    symbolicTags,
  };
}

export async function analyzeImageFile(file: File): Promise<ImageAuraSummary> {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.crossOrigin = 'anonymous';
    
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      
      if (!ctx) {
        reject(new Error('无法创建 Canvas 上下文'));
        return;
      }
      
      const maxSize = 200;
      let width = img.width;
      let height = img.height;
      
      if (width > maxSize || height > maxSize) {
        if (width > height) {
          height = (height / width) * maxSize;
          width = maxSize;
        } else {
          width = (width / height) * maxSize;
          height = maxSize;
        }
      }
      
      canvas.width = width;
      canvas.height = height;
      ctx.drawImage(img, 0, 0, width, height);
      
      const imageData = ctx.getImageData(0, 0, width, height);
      analyzeImageData(imageData).then(resolve).catch(reject);
    };
    
    img.onerror = () => {
      reject(new Error('无法加载图片'));
    };
    
    const reader = new FileReader();
    reader.onload = (e) => {
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}