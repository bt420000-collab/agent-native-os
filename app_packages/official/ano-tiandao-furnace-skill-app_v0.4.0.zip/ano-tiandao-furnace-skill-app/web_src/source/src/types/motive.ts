import { AuraVector } from './furnace';

export type MotiveCategory =
  | 'coincidence'
  | 'pressure'
  | 'omen'
  | 'crowd'
  | 'dream'
  | 'ritual'
  | 'number_echo'
  | 'research'
  | 'risk';

export type SafetyLevel = 'normal' | 'watch' | 'warn';

export interface FurnaceMotive {
  id: string;
  label: string;
  category: MotiveCategory;
  auraBias: Partial<AuraVector>;
  furnaceHeatDelta: number;
  attentionDelta: number;
  chaosDelta: number;
  safetyLevel: SafetyLevel;
  safetyMessage?: string;
  isAuspicious?: boolean;
  tag?: string;
}

export interface MentalState {
  id: string;
  label: string;
  icon: string;
  auraBias: Partial<AuraVector>;
}

export interface ActivityField {
  id: string;
  label: string;
  icon: string;
  auraBias: Partial<AuraVector>;
  isHighContext?: boolean;
  safetyLevel?: SafetyLevel;
  safetyMessage?: string;
}

export const MOTIVES: FurnaceMotive[] = [
  {
    id: 'passing_by',
    label: '路过顺手',
    category: 'coincidence',
    auraBias: { chaos: 0.05 },
    furnaceHeatDelta: 5,
    attentionDelta: 3,
    chaosDelta: 0.08,
    safetyLevel: 'normal',
    tag: '临时',
  },
  {
    id: 'impulsive',
    label: '临时起意',
    category: 'coincidence',
    auraBias: { chaos: 0.08 },
    furnaceHeatDelta: 3,
    attentionDelta: 2,
    chaosDelta: 0.12,
    safetyLevel: 'normal',
    tag: '随机',
  },
  {
    id: 'omen_good',
    label: '今天有兆头',
    category: 'omen',
    auraBias: { stability: 0.1 },
    furnaceHeatDelta: 12,
    attentionDelta: 15,
    chaosDelta: 0.02,
    safetyLevel: 'normal',
    isAuspicious: true,
    tag: '吉象',
  },
  {
    id: 'number_appealing',
    label: '看见喜欢的数字',
    category: 'number_echo',
    auraBias: { stability: 0.05 },
    furnaceHeatDelta: 8,
    attentionDelta: 10,
    chaosDelta: 0.03,
    safetyLevel: 'normal',
    isAuspicious: true,
    tag: '数缘',
  },
  {
    id: 'dream_number',
    label: '梦见数字',
    category: 'dream',
    auraBias: { yin: 0.15, water: 0.1 },
    furnaceHeatDelta: 15,
    attentionDelta: 20,
    chaosDelta: 0.05,
    safetyLevel: 'normal',
    safetyMessage: '梦象已入炉。本次采样加入潜意识扰动。',
    tag: '梦象',
  },
  {
    id: 'unlucky_rebound',
    label: '今天太倒霉',
    category: 'pressure',
    auraBias: { water: 0.1, earth: 0.1 },
    furnaceHeatDelta: 5,
    attentionDelta: 8,
    chaosDelta: -0.05,
    safetyLevel: 'watch',
    safetyMessage: '检测到倒霉反弹场。本次开炉走低频小额，不追，不补，不硬刚。',
    tag: '反弹',
  },
  {
    id: 'life_hitting',
    label: '被生活锤了',
    category: 'pressure',
    auraBias: { earth: 0.15, metal: 0.1 },
    furnaceHeatDelta: 8,
    attentionDelta: 5,
    chaosDelta: -0.03,
    safetyLevel: 'watch',
    safetyMessage: '检测到现实挤压场。本次开炉仅建议小额观测。不要让钱包替情绪挨打。',
    tag: '抗压',
  },
  {
    id: 'payday',
    label: '发工资日',
    category: 'ritual',
    auraBias: { metal: 0.2, earth: 0.1 },
    furnaceHeatDelta: 18,
    attentionDelta: 15,
    chaosDelta: 0.05,
    safetyLevel: 'normal',
    isAuspicious: true,
    safetyMessage: '时间中轴已激活。个人 seed 权重提高。',
    tag: '吉时',
  },
  {
    id: 'anniversary',
    label: '生日/纪念日',
    category: 'ritual',
    auraBias: { earth: 0.15, yang: 0.1 },
    furnaceHeatDelta: 20,
    attentionDelta: 20,
    chaosDelta: 0.02,
    safetyLevel: 'normal',
    isAuspicious: true,
    safetyMessage: '今日具备纪念性中轴。开炉人个人 seed 权重提高。',
    tag: '吉日',
  },
  {
    id: 'social_event',
    label: '参加活动',
    category: 'crowd',
    auraBias: { fire: 0.2, yang: 0.15 },
    furnaceHeatDelta: 15,
    attentionDelta: 18,
    chaosDelta: 0.08,
    safetyLevel: 'normal',
    tag: '人气',
  },
  {
    id: 'friend_encourage',
    label: '朋友怂恿',
    category: 'crowd',
    auraBias: { fire: 0.15, motion: 0.1 },
    furnaceHeatDelta: 10,
    attentionDelta: 12,
    chaosDelta: 0.1,
    safetyLevel: 'watch',
    safetyMessage: '检测到人言扰动场。请保持独立判断。',
    tag: '从众',
  },
  {
    id: 'post_party',
    label: '聚会后上头',
    category: 'crowd',
    auraBias: { fire: 0.25, yang: 0.2 },
    furnaceHeatDelta: 12,
    attentionDelta: 10,
    chaosDelta: 0.15,
    safetyLevel: 'watch',
    safetyMessage: '检测到人气扰动场。本次适合小额观测，不宜重仓。',
    tag: '上头',
  },
  {
    id: 'pure_research',
    label: '纯粹研究',
    category: 'research',
    auraBias: { stability: 0.1, earth: 0.05 },
    furnaceHeatDelta: 8,
    attentionDelta: 15,
    chaosDelta: 0.0,
    safetyLevel: 'normal',
    isAuspicious: true,
    safetyMessage: '观测者状态良好。本次实验适合归档复盘。',
    tag: '研究',
  },
  {
    id: 'verify_xuanxue',
    label: '验证玄学',
    category: 'research',
    auraBias: { water: 0.1, stability: 0.08 },
    furnaceHeatDelta: 10,
    attentionDelta: 18,
    chaosDelta: 0.02,
    safetyLevel: 'normal',
    isAuspicious: true,
    safetyMessage: '研究者模式已激活。本次实验适合归档复盘。',
    tag: '玄学',
  },
  {
    id: 'touch_universe',
    label: '想碰碰宇宙',
    category: 'coincidence',
    auraBias: { chaos: 0.1 },
    furnaceHeatDelta: 6,
    attentionDelta: 8,
    chaosDelta: 0.15,
    safetyLevel: 'normal',
    tag: '随缘',
  },
  {
    id: 'short_money',
    label: '最近缺钱',
    category: 'risk',
    auraBias: { stability: 0.15 },
    furnaceHeatDelta: -8,
    attentionDelta: -5,
    chaosDelta: -0.1,
    safetyLevel: 'warn',
    safetyMessage: '检测到高风险动机。天道哈希炉不支持回血、翻本、倍投。建议象征性观测，或暂停开炉。',
    tag: '风险',
  },
];

export const MENTAL_STATES: MentalState[] = [
  { id: '期待', label: '期待', icon: '✨', auraBias: { yang: 0.2, motion: 0.15 } },
  { id: '平静', label: '平静', icon: '🧘', auraBias: { yin: 0.2, stability: 0.15 } },
  { id: '兴奋', label: '兴奋', icon: '🔥', auraBias: { yang: 0.25, fire: 0.15, motion: 0.2 } },
  { id: '烦躁', label: '烦躁', icon: '💨', auraBias: { motion: 0.2, chaos: 0.1 } },
  { id: '忧郁', label: '忧郁', icon: '🌧', auraBias: { yin: 0.25, water: 0.1 } },
  { id: '疲惫', label: '疲惫', icon: '😴', auraBias: { yin: 0.15, stability: 0.1 } },
  { id: '清醒', label: '清醒', icon: '🧠', auraBias: { yang: 0.1, stability: 0.15 } },
  { id: '迷茫', label: '迷茫', icon: '🌫', auraBias: { chaos: 0.1, water: 0.1 } },
];

export const ACTIVITY_FIELDS: ActivityField[] = [
  { id: '工作', label: '工作', icon: '💼', auraBias: { metal: 0.15, fire: 0.1 } },
  { id: '学习', label: '学习', icon: '📚', auraBias: { water: 0.15, wood: 0.1 } },
  { id: '休息', label: '休息', icon: '🛋', auraBias: { earth: 0.15, water: 0.1 } },
  { id: '运动', label: '运动', icon: '🏃', auraBias: { fire: 0.2, wood: 0.1, motion: 0.15 } },
  { id: '聚会', label: '聚会', icon: '🎉', auraBias: { fire: 0.2, earth: 0.1, yang: 0.15 } },
  { id: '旅行', label: '旅行', icon: '✈️', auraBias: { water: 0.2, wood: 0.1 } },
  { id: '购物', label: '购物', icon: '🛍', auraBias: { earth: 0.15, metal: 0.15 } },
  { id: '创作', label: '创作', icon: '🎨', auraBias: { fire: 0.2, water: 0.1, motion: 0.1 } },
  { id: 'commute', label: '通勤', icon: '🚇', auraBias: { motion: 0.15, metal: 0.1 } },
  { id: 'coffee', label: '喝咖啡', icon: '☕', auraBias: { fire: 0.1, water: 0.1 } },
  { id: 'eating', label: '吃饭', icon: '🍜', auraBias: { earth: 0.15, fire: 0.1 } },
  { id: 'walking', label: '散步', icon: '🚶', auraBias: { wood: 0.15, motion: 0.1 } },
  { id: 'live', label: '看直播', icon: '📡', auraBias: { fire: 0.15, yang: 0.15 } },
  { id: 'shooting', label: '拍摄', icon: '🎬', auraBias: { fire: 0.2, metal: 0.1 } },
  { id: 'bills', label: '看账单', icon: '🧾', auraBias: { metal: 0.15, earth: 0.1 }, safetyLevel: 'watch', safetyMessage: '检测到财务挤压场。建议保持理性，小额观测。' },
  { id: 'salary', label: '发工资', icon: '💸', auraBias: { metal: 0.25, yang: 0.15 }, isHighContext: true, safetyLevel: 'normal' },
  { id: 'lottery_shop', label: '路过彩票站', icon: '🚪', auraBias: { chaos: 0.15, fire: 0.1 }, isHighContext: true, safetyLevel: 'watch', safetyMessage: '检测到冲动场域。请保持理性，不要上头。' },
  { id: 'repeat_number', label: '看见重复数字', icon: '🔢', auraBias: { stability: 0.15 }, isHighContext: true },
  { id: 'impulse', label: '临时起意', icon: '🎲', auraBias: { chaos: 0.2 }, safetyLevel: 'watch', safetyMessage: '检测到随机扰动场。请保持独立判断。' },
  { id: 'phone', label: '刷手机', icon: '📱', auraBias: { chaos: 0.1 } },
  { id: 'alone', label: '独处', icon: '🌙', auraBias: { yin: 0.2, water: 0.1 } },
  { id: 'waiting', label: '等人', icon: '⏳', auraBias: { earth: 0.1, water: 0.15 } },
  { id: 'pickup_kid', label: '校门口接娃', icon: '🏫', auraBias: { wood: 0.15, earth: 0.1, water: 0.1 } },
  { id: 'just_showered', label: '刚洗完澡', icon: '🛁', auraBias: { water: 0.2, yin: 0.15 } },
];