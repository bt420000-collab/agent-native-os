export type FurnaceMode =
  | 'mirror'
  | 'aura_lora'
  | 'activity_field'
  | 'cold_furnace'
  | 'wild_furnace'
  | 'multi_element';

export interface FurnaceProfile {
  nickname?: string;
  motiveIds: string[];
  mentalStates: string[];
  activityFields: string[];
  preferences?: {
    colors?: string[];
    luckyNumbers?: number[];
    avoidedNumbers?: number[];
    music?: string[];
  };
  birthInfo?: {
    year: number;
    month: number;
    day: number;
    hour?: number;
  };
  imageAura?: ImageAuraSummary;
}

export interface ImageAuraSummary {
  dominantColors: string[];
  brightness: number;
  warmth: number;
  saturation: number;
  phaseBias: {
    wood: number;
    fire: number;
    earth: number;
    metal: number;
    water: number;
  };
  symbolicTags: string[];
}

export interface FurnaceInput {
  date: string;
  drawNo: string;
  previousFront: number[];
  previousBack: number[];
  profile: FurnaceProfile;
  chaosTemperature: number;
  salt: string;
}

export interface AuraVector {
  wood: number;
  fire: number;
  earth: number;
  metal: number;
  water: number;

  yin: number;
  yang: number;

  motion: number;
  stability: number;
  chaos: number;

  lowRangeBias: number;
  midRangeBias: number;
  highRangeBias: number;

  oddBias: number;
  evenBias: number;

  tailBias: Record<number, number>;
}

export interface LottoPick {
  front: number[];
  back: number[];
  source: string;
  explanation: string;
}

export interface DrawResult {
  drawNo: string;
  front: number[];
  back: number[];
}

export type CollisionLevel =
  | 'silent'
  | 'micro_echo'
  | 'low_collision'
  | 'mid_collision'
  | 'high_collision';

export interface CollisionReport {
  frontHits: number;
  backHits: number;
  collisionLevel: CollisionLevel;
  reward: number;
  summary: string;
}

export interface FurnaceContext {
  frontMirror: number[];
  backMirror: number[];
  auraVector: AuraVector;
  prng: () => number;
  chaosTemperature: number;
  date: string;
}

export interface Experiment {
  id: string;
  drawNo: string;
  date: string;
  mode: FurnaceMode;
  profileId: string;
  seed: string;
  inputJson: string;
  auraJson: string;
  outputJson: string;
  resultJson?: string;
  collisionLevel?: CollisionLevel;
  cost: number;
  reward: number;
  note?: string;
  createdAt: string;
}

export interface Profile {
  id: string;
  name: string;
  profileHash: string;
  profileJson: string;
  createdAt: string;
  updatedAt: string;
}