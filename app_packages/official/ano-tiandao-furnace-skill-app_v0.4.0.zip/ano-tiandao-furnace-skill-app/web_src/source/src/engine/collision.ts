import { LottoPick, DrawResult, CollisionReport, CollisionLevel } from '../types/furnace';

export function calculateCollision(pick: LottoPick, result: DrawResult): CollisionReport {
  const frontHits = pick.front.filter(n => result.front.includes(n)).length;
  const backHits = pick.back.filter(n => result.back.includes(n)).length;
  
  let collisionLevel: CollisionLevel;
  let summary = '';
  
  if (frontHits === 5 && backHits === 2) {
    collisionLevel = 'high_collision';
    summary = '检测到高阶碰撞。前区5码+后区2码完全吻合。请以官方开奖信息为准，理性对待。';
  } else if (frontHits === 5 && backHits === 1) {
    collisionLevel = 'mid_collision';
    summary = '检测到中阶碰撞。前区5码全中，后区1码吻合。请以官方开奖信息为准。';
  } else if (frontHits === 5 || (frontHits === 4 && backHits === 2)) {
    collisionLevel = 'mid_collision';
    summary = '检测到中阶碰撞。请以官方开奖信息为准。';
  } else if (frontHits === 4 || (frontHits === 3 && backHits === 2)) {
    collisionLevel = 'low_collision';
    summary = '检测到低阶碰撞。请以官方开奖信息为准。';
  } else if (frontHits === 3 || (frontHits === 2 && backHits === 2) || (frontHits === 1 && backHits === 2)) {
    collisionLevel = 'micro_echo';
    summary = '检测到微响。前区或后区有少量重合。请保持观测者心态。';
  } else if (frontHits >= 1 || backHits >= 1) {
    collisionLevel = 'micro_echo';
    summary = '检测到微响。随机宇宙发出微弱信号。';
  } else {
    collisionLevel = 'silent';
    summary = '本次未发生碰撞。随机宇宙保持沉默。';
  }
  
  return {
    frontHits,
    backHits,
    collisionLevel,
    reward: 0,
    summary,
  };
}

export function calculateBestCollision(picks: LottoPick[], result: DrawResult): { report: CollisionReport; pickIndex: number } {
  const levelOrder: Record<CollisionLevel, number> = {
    'silent': 0,
    'micro_echo': 1,
    'low_collision': 2,
    'mid_collision': 3,
    'high_collision': 4,
  };

  let bestReport: CollisionReport = {
    frontHits: 0,
    backHits: 0,
    collisionLevel: 'silent',
    reward: 0,
    summary: '',
  };
  let bestIndex = 0;

  picks.forEach((pick, index) => {
    const report = calculateCollision(pick, result);
    const currentLevel = levelOrder[report.collisionLevel];
    const bestLevel = levelOrder[bestReport.collisionLevel];

    if (currentLevel > bestLevel) {
      bestReport = report;
      bestIndex = index;
    } else if (currentLevel === bestLevel) {
      const currentScore = report.frontHits * 10 + report.backHits;
      const bestScore = bestReport.frontHits * 10 + bestReport.backHits;
      if (currentScore > bestScore) {
        bestReport = report;
        bestIndex = index;
      }
    }
  });

  return { report: bestReport, pickIndex: bestIndex };
}