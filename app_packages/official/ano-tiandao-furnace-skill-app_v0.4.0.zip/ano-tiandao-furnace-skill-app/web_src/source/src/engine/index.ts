import { FurnaceInput, FurnaceContext, LottoPick, AuraVector } from '../types/furnace';
import { generateFrontMirror, generateBackMirror } from './mirror';
import { generateAuraVector } from './aura';
import { generateSeed, seedToNumber, mulberry32 } from './seed';
import { generateLottoPicks, generateAuraFingerprint } from './sampler';
import { calculateBestCollision } from './collision';

export interface FurnaceOutput {
  seed: string;
  auraVector: AuraVector;
  fingerprint: string;
  picks: LottoPick[];
  furnaceTemp: number;
  universeAttention: string;
  chaosTemp: number;
}

export function runFurnace(input: FurnaceInput): FurnaceOutput {
  const seed = generateSeed(input);
  const prng = mulberry32(seedToNumber(seed));
  
  const frontMirror = generateFrontMirror(input.previousFront);
  const backMirror = generateBackMirror(input.previousBack);
  
  const auraVector = generateAuraVector(input.profile, input.previousFront, input.previousBack);
  
  const ctx: FurnaceContext = {
    frontMirror,
    backMirror,
    auraVector,
    prng,
    chaosTemperature: input.chaosTemperature,
    date: input.date,
  };
  
  const picks = generateLottoPicks(ctx, 5);
  
  const fingerprint = generateAuraFingerprint(auraVector, input.date);
  
  const furnaceTemp = Math.floor((auraVector.fire + auraVector.motion) * 50 + prng() * 30 + 20 + (input.chaosTemperature * 20));
  const universeAttention = calculateUniverseAttention(auraVector, input.profile);
  
  return {
    seed,
    auraVector,
    fingerprint,
    picks,
    furnaceTemp,
    universeAttention,
    chaosTemp: input.chaosTemperature,
  };
}

function calculateUniverseAttention(aura: AuraVector, profile: FurnaceInput['profile']): string {
  let attention = (aura.yang + aura.motion + (1 - aura.chaos)) / 3;

  const hasNickname = !!profile.nickname;
  const hasMotive = (profile.motiveIds?.length || 0) > 0;
  const hasMentalState = (profile.mentalStates?.length || 0) > 0;
  const hasActivity = (profile.activityFields?.length || 0) > 0;
  const hasColors = (profile.preferences?.colors?.length || 0) > 0;
  const hasBirth = !!profile.birthInfo;

  const elementCount = [hasNickname, hasMotive, hasMentalState, hasActivity, hasColors, hasBirth].filter(Boolean).length;

  attention += elementCount * 0.05;

  if (attention > 0.8) return '极高';
  if (attention > 0.6) return '高';
  if (attention > 0.4) return '中';
  if (attention > 0.2) return '低';
  return '极低';
}

export {
  generateFrontMirror,
  generateBackMirror,
  generateAuraVector,
  generateSeed,
  calculateBestCollision,
  generateAuraFingerprint,
};