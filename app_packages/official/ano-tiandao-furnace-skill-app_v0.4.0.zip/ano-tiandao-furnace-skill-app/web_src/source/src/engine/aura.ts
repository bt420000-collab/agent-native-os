import { FurnaceProfile, AuraVector } from '../types/furnace';
import { MOTIVES, MENTAL_STATES, ACTIVITY_FIELDS } from '../types/motive';

const COLOR_TO_PHASE: Record<string, string> = {
  'green': 'wood',
  'cyan': 'wood',
  'red': 'fire',
  'orange': 'fire',
  'yellow': 'earth',
  'brown': 'earth',
  'white': 'metal',
  'gray': 'metal',
  'blue': 'water',
  'black': 'water',
};

function analyzeNickname(nickname: string): Partial<AuraVector> {
  const result: Partial<AuraVector> = {};

  const woodChars = ['木', '林', '森', '竹', '草', '花', '叶', '枝', '松', '梅'];
  const fireChars = ['火', '炎', '焱', '烈', '热', '灯', '烧', '烤', '炉', '灶'];
  const earthChars = ['土', '地', '山', '石', '田', '坤', '城', '墙', '基', '岩'];
  const metalChars = ['金', '银', '铜', '铁', '钢', '锡', '钱', '针', '镜', '铃'];
  const waterChars = ['水', '海', '河', '湖', '江', '波', '浪', '流', '泉', '雨'];

  let wood = 0, fire = 0, earth = 0, metal = 0, water = 0;

  for (const char of nickname) {
    if (woodChars.includes(char)) wood++;
    if (fireChars.includes(char)) fire++;
    if (earthChars.includes(char)) earth++;
    if (metalChars.includes(char)) metal++;
    if (waterChars.includes(char)) water++;
  }

  const maxCount = Math.max(wood, fire, earth, metal, water, 1);
  result.wood = wood / maxCount * 0.3;
  result.fire = fire / maxCount * 0.3;
  result.earth = earth / maxCount * 0.3;
  result.metal = metal / maxCount * 0.3;
  result.water = water / maxCount * 0.3;

  const hash = nickname.split('').reduce((acc, char) => acc + char.charCodeAt(0), 0);
  result.chaos = (hash % 100) / 100 * 0.4 + 0.3;

  return result;
}

function analyzeMirror(frontMirror: number[], backMirror: number[]): Partial<AuraVector> {
  const result: Partial<AuraVector> = {};

  if (frontMirror.length === 0 && backMirror.length === 0) {
    return result;
  }

  const FIVE_PHASE_FRONT: Record<string, number[]> = {
    water: [1, 6, 11, 16, 21, 26, 31],
    fire: [2, 7, 12, 17, 22, 27, 32],
    wood: [3, 8, 13, 18, 23, 28, 33],
    metal: [4, 9, 14, 19, 24, 29, 34],
    earth: [5, 10, 15, 20, 25, 30, 35],
  };

  const phaseCount: Record<string, number> = { wood: 0, fire: 0, earth: 0, metal: 0, water: 0 };

  for (const n of frontMirror) {
    for (const [phase, nums] of Object.entries(FIVE_PHASE_FRONT)) {
      if (nums.includes(n)) {
        phaseCount[phase]++;
      }
    }
  }

  const total = Object.values(phaseCount).reduce((a, b) => a + b, 0);
  if (total > 0) {
    result.wood = phaseCount.wood / total * 0.2;
    result.fire = phaseCount.fire / total * 0.2;
    result.earth = phaseCount.earth / total * 0.2;
    result.metal = phaseCount.metal / total * 0.2;
    result.water = phaseCount.water / total * 0.2;
  }

  return result;
}

function analyzePreferences(preferences: { colors?: string[]; luckyNumbers?: number[]; avoidedNumbers?: number[] }): Partial<AuraVector> {
  const result: Partial<AuraVector> = {};

  if (preferences.colors) {
    for (const color of preferences.colors) {
      const phase = COLOR_TO_PHASE[color.toLowerCase()] as 'wood' | 'fire' | 'earth' | 'metal' | 'water' | undefined;
      if (phase === 'wood') result.wood = (result.wood || 0) + 0.15;
      else if (phase === 'fire') result.fire = (result.fire || 0) + 0.15;
      else if (phase === 'earth') result.earth = (result.earth || 0) + 0.15;
      else if (phase === 'metal') result.metal = (result.metal || 0) + 0.15;
      else if (phase === 'water') result.water = (result.water || 0) + 0.15;
    }
  }

  if (preferences.luckyNumbers && preferences.luckyNumbers.length > 0) {
    const avgNum = preferences.luckyNumbers.reduce((a, b) => a + b, 0) / preferences.luckyNumbers.length;
    if (avgNum <= 12) result.lowRangeBias = (result.lowRangeBias || 0) + 0.2;
    else if (avgNum <= 24) result.midRangeBias = (result.midRangeBias || 0) + 0.2;
    else result.highRangeBias = (result.highRangeBias || 0) + 0.2;

    const oddCount = preferences.luckyNumbers.filter(n => n % 2 === 1).length;
    const evenCount = preferences.luckyNumbers.length - oddCount;
    if (oddCount > evenCount) result.oddBias = (result.oddBias || 0) + 0.2;
    else if (evenCount > oddCount) result.evenBias = (result.evenBias || 0) + 0.2;
  }

  return result;
}

function addBias(base: AuraVector, bias: Partial<AuraVector>, weight: number = 1): void {
  const numericKeys: (keyof AuraVector)[] = [
    'wood', 'fire', 'earth', 'metal', 'water',
    'yin', 'yang', 'motion', 'stability', 'chaos',
    'lowRangeBias', 'midRangeBias', 'highRangeBias',
    'oddBias', 'evenBias'
  ];

  for (const key of numericKeys) {
    if (bias[key] !== undefined && typeof bias[key] === 'number') {
      (base[key] as number) += (bias[key] as number) * weight;
    }
  }
}

export function generateAuraVector(
  profile: FurnaceProfile,
  previousFront: number[] = [],
  previousBack: number[] = []
): AuraVector {
  const base: AuraVector = {
    wood: 0.2,
    fire: 0.2,
    earth: 0.2,
    metal: 0.2,
    water: 0.2,
    yin: 0.5,
    yang: 0.5,
    motion: 0.5,
    stability: 0.5,
    chaos: 0.5,
    lowRangeBias: 0.33,
    midRangeBias: 0.34,
    highRangeBias: 0.33,
    oddBias: 0.5,
    evenBias: 0.5,
    tailBias: {},
  };

  if (previousFront.length > 0) {
    const mirrorBias = analyzeMirror(previousFront, previousBack);
    addBias(base, mirrorBias, 1);
  }

  if (profile.nickname) {
    const nicknameBias = analyzeNickname(profile.nickname);
    addBias(base, nicknameBias, 1);
  }

  if (profile.motiveIds && profile.motiveIds.length > 0) {
    const selectedMotives = MOTIVES.filter(m => profile.motiveIds.includes(m.id));
    for (const motive of selectedMotives) {
      addBias(base, motive.auraBias, 1);
    }
  }

  if (profile.mentalStates && profile.mentalStates.length > 0) {
    for (const stateId of profile.mentalStates) {
      const mentalState = MENTAL_STATES.find(s => s.id === stateId);
      if (mentalState) {
        addBias(base, mentalState.auraBias, 1);
      }
    }
  }

  if (profile.activityFields && profile.activityFields.length > 0) {
    for (const activityId of profile.activityFields) {
      const activity = ACTIVITY_FIELDS.find(a => a.id === activityId);
      if (activity) {
        addBias(base, activity.auraBias, 1);
      }
    }
  }

  if (profile.preferences) {
    const prefBias = analyzePreferences(profile.preferences);
    addBias(base, prefBias, 1);
  }

  if (profile.imageAura) {
    const img = profile.imageAura;
    base.wood += img.phaseBias.wood * 0.15;
    base.fire += img.phaseBias.fire * 0.15;
    base.earth += img.phaseBias.earth * 0.15;
    base.metal += img.phaseBias.metal * 0.15;
    base.water += img.phaseBias.water * 0.15;
    base.chaos += (1 - img.saturation) * 0.1;
  }

  const totalPhase = base.wood + base.fire + base.earth + base.metal + base.water;
  if (totalPhase > 0) {
    base.wood /= totalPhase;
    base.fire /= totalPhase;
    base.earth /= totalPhase;
    base.metal /= totalPhase;
    base.water /= totalPhase;
  }

  base.yin = Math.min(1, Math.max(0, base.yin));
  base.yang = 1 - base.yin;
  base.stability = 1 - base.motion;

  return base;
}