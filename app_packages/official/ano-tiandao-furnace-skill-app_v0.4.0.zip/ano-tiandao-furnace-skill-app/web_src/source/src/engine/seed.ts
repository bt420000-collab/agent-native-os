import SHA256 from 'crypto-js/sha256';
import { FurnaceInput } from '../types/furnace';

export function generateSeed(input: FurnaceInput): string {
  const canonicalInput = JSON.stringify({
    date: input.date,
    drawNo: input.drawNo,
    previousFront: input.previousFront,
    previousBack: input.previousBack,
    profile: input.profile,
    chaosTemperature: input.chaosTemperature,
    salt: input.salt,
  });
  return SHA256(canonicalInput).toString();
}

export function mulberry32(a: number): () => number {
  return function () {
    let t = (a += 0x6d2b79f5);
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

export function seedToNumber(seed: string): number {
  const hex = seed.slice(0, 8);
  return parseInt(hex, 16);
}

export function generateProfileHash(profile: unknown): string {
  return SHA256(JSON.stringify(profile)).toString();
}