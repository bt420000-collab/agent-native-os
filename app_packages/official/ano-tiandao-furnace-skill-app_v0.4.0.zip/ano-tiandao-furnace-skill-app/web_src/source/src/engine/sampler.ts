import { FurnaceContext, LottoPick } from '../types/furnace';
import { getPhaseScore } from './fivePhase';

function getRangeBias(n: number, low: number, mid: number, high: number): number {
  if (n <= 12) return low;
  if (n <= 24) return mid;
  return high;
}

function getOddEvenBias(n: number, oddBias: number, evenBias: number): number {
  return n % 2 === 1 ? oddBias : evenBias;
}

function calculateJumpScore(n: number, previousFront: number[]): number {
  let jumpCount = 0;
  for (const prev of previousFront) {
    if (Math.abs(n - prev) <= 3) {
      jumpCount++;
    }
  }
  return jumpCount * 0.5;
}

function scoreFrontNumber(n: number, ctx: FurnaceContext): number {
  let score = 0;
  
  if (ctx.frontMirror.includes(n)) {
    score += 3.0;
  }
  
  const phaseScore = getPhaseScore(n, {
    wood: ctx.auraVector.wood,
    fire: ctx.auraVector.fire,
    earth: ctx.auraVector.earth,
    metal: ctx.auraVector.metal,
    water: ctx.auraVector.water,
  }, true);
  score += phaseScore * 2;
  
  score += getRangeBias(
    n,
    ctx.auraVector.lowRangeBias,
    ctx.auraVector.midRangeBias,
    ctx.auraVector.highRangeBias
  ) * 1.5;
  
  score += getOddEvenBias(n, ctx.auraVector.oddBias, ctx.auraVector.evenBias);
  
  score += calculateJumpScore(n, ctx.frontMirror) * 0.3;
  
  const dateNum = parseInt(ctx.date.replace(/-/g, ''));
  score += ((n * 7 + dateNum) % 100) / 100;
  
  score += ctx.prng() * ctx.chaosTemperature;
  
  return score;
}

function scoreBackNumber(n: number, ctx: FurnaceContext): number {
  let score = 0;
  
  if (ctx.backMirror.includes(n)) {
    score += 3.0;
  }
  
  score += getPhaseScore(n, {
    wood: ctx.auraVector.wood,
    fire: ctx.auraVector.fire,
    earth: ctx.auraVector.earth,
    metal: ctx.auraVector.metal,
    water: ctx.auraVector.water,
  }, false) * 2;
  
  const dateNum = parseInt(ctx.date.replace(/-/g, ''));
  score += ((n * 11 + dateNum) % 100) / 100;
  
  score += ctx.prng() * ctx.chaosTemperature;
  
  return score;
}

function weightedRandomSelection(pool: { value: number; score: number }[], count: number, prng: () => number): number[] {
  const result: number[] = [];
  const available = [...pool];
  
  for (let i = 0; i < count && available.length > 0; i++) {
    const totalWeight = available.reduce((sum, item) => sum + Math.exp(item.score), 0);
    let random = prng() * totalWeight;
    
    for (let j = 0; j < available.length; j++) {
      const weight = Math.exp(available[j].score);
      random -= weight;
      if (random <= 0) {
        result.push(available[j].value);
        available.splice(j, 1);
        break;
      }
    }
  }
  
  return result.sort((a, b) => a - b);
}

function generateExplanation(front: number[], _back: number[], aura: { wood: number; fire: number; earth: number; metal: number; water: number }, chaos: number): string {
  const explanations: string[] = [];
  
  const phaseOrder = [
    { name: '木', key: 'wood', char: '木', desc: '起势' },
    { name: '火', key: 'fire', char: '火', desc: '升腾' },
    { name: '土', key: 'earth', char: '土', desc: '中轴' },
    { name: '金', key: 'metal', char: '金', desc: '收敛' },
    { name: '水', key: 'water', char: '水', desc: '流动' },
  ];
  
  const sortedPhases = phaseOrder
    .map(p => ({ ...p, value: aura[p.key as keyof typeof aura] as number }))
    .sort((a, b) => b.value - a.value);
  
  const topPhase = sortedPhases[0];
  if (topPhase && topPhase.value > 0.25) {
    explanations.push(`${topPhase.char}${topPhase.desc}`);
  }
  
  if (chaos > 0.6) {
    explanations.push('高混沌');
  } else if (chaos < 0.4) {
    explanations.push('低混沌');
  }
  
  const frontSum = front.reduce((a, b) => a + b, 0);
  const avgFront = frontSum / front.length;
  
  if (avgFront < 12) {
    explanations.push('低位');
  } else if (avgFront > 24) {
    explanations.push('高位');
  } else {
    explanations.push('中段');
  }
  
  return explanations.join(' · ') || '气运调和';
}

export function generateLottoPicks(ctx: FurnaceContext, count: number = 5): LottoPick[] {
  const picks: LottoPick[] = [];
  
  const phaseInfo = {
    wood: ctx.auraVector.wood,
    fire: ctx.auraVector.fire,
    earth: ctx.auraVector.earth,
    metal: ctx.auraVector.metal,
    water: ctx.auraVector.water,
  };
  
  for (let i = 0; i < count; i++) {
    const frontScores = Array.from({ length: 35 }, (_, idx) => ({
      value: idx + 1,
      score: scoreFrontNumber(idx + 1, ctx),
    }));
    
    const backScores = Array.from({ length: 12 }, (_, idx) => ({
      value: idx + 1,
      score: scoreBackNumber(idx + 1, ctx),
    }));
    
    const front: number[] = [];
    const frontAvailable = [...frontScores];
    
    for (let j = 0; j < 5 && frontAvailable.length > 0; j++) {
      const totalWeight = frontAvailable.reduce((sum, item) => sum + Math.exp(item.score), 0);
      let random = ctx.prng() * totalWeight;
      
      for (let k = 0; k < frontAvailable.length; k++) {
        const weight = Math.exp(frontAvailable[k].score);
        random -= weight;
        if (random <= 0) {
          front.push(frontAvailable[k].value);
          frontAvailable.splice(k, 1);
          
          for (let l = 0; l < frontAvailable.length; l++) {
            frontAvailable[l].score = scoreFrontNumber(frontAvailable[l].value, ctx);
          }
          break;
        }
      }
    }
    
    front.sort((a, b) => a - b);
    
    const back = weightedRandomSelection(backScores, 2, ctx.prng);
    
    picks.push({
      front,
      back,
      source: 'TDHF Engine',
      explanation: generateExplanation(front, back, phaseInfo, ctx.chaosTemperature),
    });
  }
  
  return picks;
}

export function generateAuraFingerprint(aura: { wood: number; fire: number; earth: number; metal: number; water: number }, date: string): string {
  const sorted = [
    { p: '木', v: aura.wood },
    { p: '火', v: aura.fire },
    { p: '土', v: aura.earth },
    { p: '金', v: aura.metal },
    { p: '水', v: aura.water },
  ].sort((a, b) => b.v - a.v);
  
  const topTwo = sorted.slice(0, 2).map(s => s.p).join('');
  const hash = Math.floor((aura.wood + aura.fire + aura.earth + aura.metal + aura.water) * 1000);
  const datePart = date.replace(/-/g, '').slice(2);
  
  return `TDHF-${datePart}-${hash.toString(16).toUpperCase().slice(-4)}-${topTwo}`;
}