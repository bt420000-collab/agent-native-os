export const FIVE_PHASE_FRONT: Record<string, number[]> = {
  water: [1, 6, 11, 16, 21, 26, 31],
  fire: [2, 7, 12, 17, 22, 27, 32],
  wood: [3, 8, 13, 18, 23, 28, 33],
  metal: [4, 9, 14, 19, 24, 29, 34],
  earth: [5, 10, 15, 20, 25, 30, 35],
};

export const FIVE_PHASE_BACK: Record<string, number[]> = {
  water: [1, 6, 11],
  fire: [2, 7, 12],
  wood: [3, 8],
  metal: [4, 9],
  earth: [5, 10],
};

export function getPhaseOfNumber(n: number, isFront: boolean): string | null {
  const phases = isFront ? FIVE_PHASE_FRONT : FIVE_PHASE_BACK;
  for (const [phase, numbers] of Object.entries(phases)) {
    if (numbers.includes(n)) {
      return phase;
    }
  }
  return null;
}

export function getPhaseScore(n: number, phaseBias: Record<string, number>, isFront: boolean): number {
  const phase = getPhaseOfNumber(n, isFront);
  return phase ? (phaseBias[phase] || 0) : 0;
}