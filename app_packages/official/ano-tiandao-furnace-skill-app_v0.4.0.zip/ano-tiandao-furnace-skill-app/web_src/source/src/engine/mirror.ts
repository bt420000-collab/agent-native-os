export function mirrorFront(n: number): number {
  return 36 - n;
}

export function mirrorBack(n: number): number {
  return 13 - n;
}

export function generateFrontMirror(numbers: number[]): number[] {
  return numbers.map(mirrorFront).sort((a, b) => a - b);
}

export function generateBackMirror(numbers: number[]): number[] {
  return numbers.map(mirrorBack).sort((a, b) => a - b);
}