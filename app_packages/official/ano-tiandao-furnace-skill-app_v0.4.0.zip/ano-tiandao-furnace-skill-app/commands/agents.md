# Command: agents

```bash
python runtime/tiandao_furnace.py agents
```

输出多 Agent 阵容。
