# Command: open

Correct first command when the user says “打开 ANO Tiandao Furnace Skill App”.

```bash
python runtime/tiandao_furnace.py open
```

This command prints the Context Permission Request and Agent Runtime Approval Card, then stops. Do not start or install anything else unless the user explicitly approves.
