# start

创建经过用户批准的 staged session。

```bash
python runtime/tiandao_furnace.py start --yes
```

v0.4.0 起 `start --yes` 不需要一开始提供上期号码。它会先返回“上期号码入炉”问题，让用户选择：

- 手动输入上期号码
- 请求 ANO Host 联网查询官方上期号码
- 明确跳过，镜像火降温

禁止在没有用户确认的情况下自动开炉。
