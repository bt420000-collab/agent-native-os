# Command: review

```bash
python runtime/tiandao_furnace.py review --pick-front "1 2 3 4 5" --pick-back "1 2" --result-front "1 2 3 9 10" --result-back "2 8"
```
