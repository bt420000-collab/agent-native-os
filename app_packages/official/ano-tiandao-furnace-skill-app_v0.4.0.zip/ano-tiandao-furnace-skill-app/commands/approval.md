# Command: approval

```bash
python runtime/tiandao_furnace.py approval
```

输出运行审批卡。
