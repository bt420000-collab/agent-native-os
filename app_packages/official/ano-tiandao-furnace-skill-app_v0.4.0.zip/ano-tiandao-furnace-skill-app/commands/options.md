# Command: options

```bash
python runtime/tiandao_furnace.py options
```

输出原版风格选项池，包括缘起、心象、场域。
