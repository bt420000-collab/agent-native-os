# Command: ritual

Compatibility guard only.

In v0.3.0, direct one-shot ritual execution is blocked because it bypasses ANO runtime approval and staged user interaction.

Correct flow:

```bash
python runtime/tiandao_furnace.py open
python runtime/tiandao_furnace.py start --yes --front "1 2 3 4 5" --back "1 2"
python runtime/tiandao_furnace.py answer --session <session_id> --motive "..."
```
