# Command: safety

```bash
python runtime/tiandao_furnace.py safety "这次必中，建议倍投"
```
