# answer

提交一批用户回答。

示例：

```bash
python runtime/tiandao_furnace.py answer --session <id> --previous-source manual --front "1 2 3 4 5" --back "1 2"
python runtime/tiandao_furnace.py answer --session <id> --previous-source web_lookup_requested
python runtime/tiandao_furnace.py answer --session <id> --motive "今天有兆头,梦见数字,纯粹研究"
python runtime/tiandao_furnace.py answer --session <id> --mental "期待,忧郁,疲惫"
python runtime/tiandao_furnace.py answer --session <id> --direction south --weather sunny --geo-field home
python runtime/tiandao_furnace.py answer --session <id> --location "Tokyo" --weather weather_lookup_requested
python runtime/tiandao_furnace.py answer --session <id> --confirm yes_entertainment_only
```

每次输出都会包含：

- `next_user_prompt`：下一句应该直接问用户的话
- `agent_instruction`：外部 Agent 应如何继续
- `host_tool_request`：需要 ANO Host 查询上期号码或当前天气时才出现

用户多选超限不会卡死。超出的选项会转为“炉边余炭”。
