# Command: sample

Compatibility alias for `ritual`.

In v0.2.0, `sample` no longer bypasses the furnace heat gate.
