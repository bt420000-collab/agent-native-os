# Smoke Checklist v0.4.0

- `open` prints CPR, approval card, agent roster, STOP.
- `start --yes` creates session and asks previous-draw intake first.
- `answer --previous-source web_lookup_requested` returns host_tool_request and does not open.
- `answer --previous-source web_lookup_confirmed --front ... --back ...` continues to motive question.
- Selecting 3 mental states does not block; overflow becomes 炉边余炭.
- Feng-shui top-up asks direction/weather/geo-field.
- `--weather weather_lookup_requested` returns a weather host_tool_request.
- Missing heat returns concrete top-up choices.
- Heat >= 75 still requires `--confirm yes_entertainment_only`.
- Direct `ritual` remains blocked.
