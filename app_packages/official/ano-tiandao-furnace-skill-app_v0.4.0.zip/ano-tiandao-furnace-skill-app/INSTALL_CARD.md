# Install Card: ANO Tiandao Furnace Skill App v0.4.0

## 这是什么？

一个免费的 ANO 多 Agent 小应用，把“天道哈希炉”改造成标准 Skill App。它用于娱乐型符号随机实验、开炉问答、炉温门槛、多 Agent 可视化和安全审计。

## v0.4.0 重要规则

- 打开 App 时只打印 Context Permission Request + Agent Runtime Approval Card。
- 打印后必须 STOP，把控制权交还用户。
- 用户明确批准后才可 `start --yes`。
- 开局第一关必须处理上期开奖号码：手动录入 / 请求 ANO Host 联网查询 / 明确跳过。
- App 自己不联网；联网查询必须输出 `host_tool_request` 给 ANO Host。
- 用户多选超限不会卡死，超出项会转为“炉边余炭”。
- 新增风水堪舆：方位、天气、地理场作为民俗象征 seed 权重。
- `next_user_prompt` 会告诉 Agent 下一句该问用户什么，不需要用户喊“继续”。
- 炉温达到 75% 后仍需确认“只做娱乐实验，不当预测”。

## 它会启动哪些 Agent？

- 开炉协调 Agent：提交上下文权限申请，统筹流程
- 理性护栏 Agent：防止预测、投注、上头话术
- 上期号码查验 Agent：先处理上期号码来源，必要时请求 Host 联网查询
- 风水堪舆 Agent：处理方位、天气、地理场的民俗象征权重
- 炉相取象 Agent：像算命一样解释炉相，但只做娱乐叙事
- 添柴问答 Agent：分批提问，动态给选项
- 炉门守卫 Agent：炉温不到 75% 或未确认娱乐用途不开炉
- 符号采样 Agent：达标且确认后才生成娱乐样本
- 碰撞复盘 Agent：事后复盘
- 实验归档 Agent：保存记录

## 它不会做什么？

- 不预测彩票
- 不提高中奖概率
- 不提供投注建议
- 不替用户做金钱决策
- 不读取其他 App 私有目录
- 不修改 `ano/kernel/`
- 不绕过 ANO Host 直接运行子 Agent

## 推荐用途

作为 ANO 官方免费多 Agent demo，展示 App 运行前角色审批、Context Permission Request、多 Agent 分工可视化、OS Host 工具请求、用户参与式分批问答、炉温门槛式流程控制、风水民俗叙事和安全审计。
