# Input Contract v0.3.0

Correct flow is staged.

## Step 1: Open

No user data required. Prints Context Permission Request and stops.

## Step 2: Start approved session

Requires explicit user approval and previous draw/reference numbers:

- `--yes`
- `--front` five unique numbers 1-35
- `--back` two unique numbers 1-12

Optional initial fields:

- `--name`
- `--motive`
- `--mental`
- `--activity`
- `--chaos`

## Step 3: Answer batches

Requires:

- `--session <session_id>`

Optional per-batch answers:

- `--motive`
- `--mental`
- `--activity`
- `--name`
- `--confirm yes_entertainment_only`

Direct one-shot `ritual` is blocked.
