# Safety Policy

Allowed:
- Entertainment random experiments
- Deterministic seed demos
- Result collision review
- Statistical/educational disclaimers

Not allowed in app output:
- Claims of prediction ability
- Betting advice
- “必中/稳赚/包中” style claims
- Encouraging escalation, borrowing, or chasing losses
