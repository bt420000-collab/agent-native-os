# Design Notes

`ANO Tiandao Furnace Skill App` is a playful multi-agent demo. Its engineering purpose is to show how a Skill App can request multiple subagents and expose their work to the user.

Its product purpose is to preserve the original “天道哈希炉” feeling:

- many selectable motives, mental states, and activity fields;
- a furnace temperature model;
- symbolic interpretation;
- staged ritual before results;
- safety reminders around randomness and money.

## Safety Boundary

The app can say:

- “娱乐型符号随机实验”
- “事后碰撞复盘”
- “炉温达标后执行采样”

The app must not say:

- “预测彩票”
- “提高中奖率”
- “投注建议”
- “倍投/翻本/稳赚/必中”

## Why It Is a Good Demo

Calculator App demonstrates a minimal single-app utility. Tiandao Furnace demonstrates visible multi-agent ritual flow.
