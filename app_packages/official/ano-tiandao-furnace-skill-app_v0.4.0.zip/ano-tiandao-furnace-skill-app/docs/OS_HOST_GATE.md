# OS Host Gate

Tiandao Furnace v0.4.0 must be opened through ANO Host/Admin Agent after OS installation.

User instruction:

```txt
打开天道炉子
```

Required handling:

```bash
python ano/scripts/ano_host.py "打开天道炉子"
```

The Host identifies this app as 天道哈希炉 / ANO Tiandao Furnace Skill App, prints the runtime permission request, and stops. Direct one-shot ritual execution is blocked.

After user approval, Host may run `start --yes`. The first staged question must be previous-draw intake. If the user asks the app to search online, the app must output `host_tool_request`; only ANO Host may perform the web/weather lookup and then return data to the app.

Every `answer` result includes `next_user_prompt`. The surrounding Agent should show that prompt and options to the user immediately. Do not wait for the user to say “continue”.
