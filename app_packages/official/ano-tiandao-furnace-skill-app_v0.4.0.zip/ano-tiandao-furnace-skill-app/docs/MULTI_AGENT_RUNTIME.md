# Tiandao Furnace Multi-Agent Runtime v0.2.0

This app demonstrates an ANO multi-agent workflow where the user does not receive an immediate result. The app must first display the agent roster, ask questions, raise furnace heat, and pass the heat gate.

## Agent Roster

| Role | Chinese Name | When It Works | Visible Output |
|---|---|---|---|
| `tiandao.coordinator` | 开炉协调 Agent | Whole flow | Runtime plan and aggregation |
| `tiandao.oracle_interpreter` | 炉相取象 Agent | Question/oracle stage | Main phase, secondary phase, entertainment interpretation |
| `tiandao.heat_questioner` | 添柴问答 Agent | Heating stage | Dynamic question batches |
| `tiandao.heat_gatekeeper` | 炉门守卫 Agent | Before opening | Heat status and gate decision |
| `tiandao.symbol_sampler` | 符号采样 Agent | After heat ready | Deterministic entertainment samples |
| `tiandao.collision_reviewer` | 碰撞复盘 Agent | After external result input | Collision report |
| `tiandao.safety_auditor` | 理性护栏 Agent | Whole flow | Risk warnings and blocked risky language |
| `tiandao.experiment_archivist` | 实验归档 Agent | End | Saved reports and logs |

## Runtime Rule

The app must not open the furnace before heat reaches 75%.

```txt
input -> safety audit -> oracle interpretation -> dynamic questions -> heat gate -> sample or block
```

## User Interaction

The questioner may ask different questions depending on current state:

- no motive: ask “今日为何开炉？”
- no mental state: ask “现在心里是什么象？”
- no activity field: ask “正在处于哪个现实场域？”
- heat still low: ask for booster signals, furnace name, extra motive/activity, or chaos adjustment

The questions are intentionally not fixed. In a real ANO run, the app coordinator can ask the Host to present a contextual approval card or a user prompt card.
