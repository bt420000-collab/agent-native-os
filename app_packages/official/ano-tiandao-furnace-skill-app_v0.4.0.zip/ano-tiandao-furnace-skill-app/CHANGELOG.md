# Changelog

## 0.4.0

- Added mandatory first-stage previous-draw intake. The app no longer skips previous winning numbers.
- Added `host_tool_request` for official previous-draw web lookup; the app does not bypass ANO Host or perform direct web access.
- Added overflow-safe multi-select handling: if a user selects too many mental states or options, the flow continues and extras become “炉边余炭”.
- Added `tiandao.draw_lookup_agent` and `tiandao.geomancy_agent`.
- Added feng-shui top-up fields: direction, current weather, geographic field, optional location text.
- Added current-weather host lookup request via `--weather weather_lookup_requested`.
- Added `next_user_prompt` and `agent_instruction` so external agents should ask the next question directly instead of waiting for the user to say “continue”.
- Added folk-symbolic explanation: direction/weather/location → five-element weight → seed mixing → entertainment sampling.
- Improved heat-gap handling: when heat is short, the app returns concrete top-up options instead of leaving the agent stuck.


## 0.4.0

- Fixed the external-agent bypass issue: direct `ritual --front ... --motive ...` no longer opens the furnace.
- Added `open` command as the correct first entry point. It prints Context Permission Request, Agent Runtime Approval Card, visible subagent roster, and STOP notice.
- Added `start --yes` command. It requires explicit user approval and creates a staged session.
- Added `answer --session <id>` command for batch-by-batch user interaction.
- Added entertainment confirmation gate: heat may reach 75%, but `--confirm yes_entertainment_only` is still required before sampling.
- Added persistent session state under `ano/runtime/apps/ano.skill.tiandao/state/` when running inside an ANO workspace.
- Updated README, install card, command docs, and runtime protocol to tell agents to stop after OS-managed approval preview.

## 0.2.0

- Restored original-style furnace ritual flow.
- Added `tiandao.oracle_interpreter`, an oracle-like entertainment interpretation agent.
- Added `tiandao.heat_questioner`, a dynamic staged question agent.
- Added `tiandao.heat_gatekeeper`, a heat threshold gatekeeper.
- Added visible `agent_trace` so users can see what every subagent is doing.
- Added `ritual` command as the primary entry point.
- Changed `sample` into a backward-compatible heat-gated alias.
- Added original option pools via `options` command.
- Added furnace heat threshold: 75%.
- Results are blocked before sufficient furnace heat.

## 0.1.0

- Initial ANO multi-agent Skill App conversion.
- Added symbolic sampler, collision reviewer, safety auditor, archivist, and coordinator.
