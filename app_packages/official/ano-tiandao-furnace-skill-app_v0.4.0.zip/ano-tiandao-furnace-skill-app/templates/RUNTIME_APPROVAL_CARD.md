# ANO Agent 运行审批卡：Tiandao Furnace v0.2.0

App: `ano.skill.tiandao`

## 本次角色

- 开炉协调 Agent：统筹流程，不是 Host
- 炉相取象 Agent：像算命一样解释炉相，但不做预测
- 添柴问答 Agent：分批提问，提高炉温
- 炉门守卫 Agent：炉温不到 75% 不准开炉
- 符号采样 Agent：达标后才生成娱乐样本
- 碰撞复盘 Agent：事后复盘
- 理性护栏 Agent：安全审计
- 实验归档 Agent：记录结果

## 开炉门槛

炉温达到 75% 后才能开炉。
