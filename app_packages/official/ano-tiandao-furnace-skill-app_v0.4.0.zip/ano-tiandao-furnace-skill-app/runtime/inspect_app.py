#!/usr/bin/env python3
from pathlib import Path
print((Path(__file__).resolve().parents[1] / 'manifest.yaml').read_text(encoding='utf-8'))
