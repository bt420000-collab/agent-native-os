#!/usr/bin/env python3
from __future__ import annotations

import json
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

APP_ID = "ano.skill.tiandao"
PACKAGE = "ano-tiandao-furnace-skill-app"
VERSION = "0.2.0"


def ensure_workspace(root: Path) -> None:
    for rel in [
        "ano/kernel", "ano/runtime/apps", "ano/runtime/events", "ano/registry/apps",
        "user/apps", "apps", "res", "out/tiandao"
    ]:
        (root / rel).mkdir(parents=True, exist_ok=True)
    if not (root / "README.md").exists():
        (root / "README.md").write_text("# ANO Workspace\n", encoding="utf-8")
    if not (root / "USER_LOG.md").exists():
        (root / "USER_LOG.md").write_text("# USER LOG\n", encoding="utf-8")


def append_event(root: Path, event: dict) -> None:
    path = root / "ano/runtime/events.jsonl"
    event["time"] = datetime.now(timezone.utc).isoformat()
    with path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, ensure_ascii=False) + "\n")


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: install_skill_app.py /path/to/ANO_WORKSPACE", file=sys.stderr)
        return 2
    workspace = Path(sys.argv[1]).resolve()
    workspace.mkdir(parents=True, exist_ok=True)
    ensure_workspace(workspace)

    source_app = Path(__file__).resolve().parents[1]
    dest_app = workspace / "apps" / PACKAGE
    if dest_app.exists():
        shutil.rmtree(dest_app)
    shutil.copytree(source_app, dest_app, ignore=shutil.ignore_patterns(".git", "node_modules", "dist"))

    runtime_root = workspace / "ano/runtime/apps" / APP_ID
    for rel in ["inbox", "desktop", "outbox", "logs", "state", "reports", "private"]:
        (runtime_root / rel).mkdir(parents=True, exist_ok=True)
    user_root = workspace / "user/apps" / APP_ID
    user_root.mkdir(parents=True, exist_ok=True)
    (workspace / "out/tiandao").mkdir(parents=True, exist_ok=True)

    registry = {
        "app_id": APP_ID,
        "package_name": PACKAGE,
        "display_name": "ANO Tiandao Furnace Skill App",
        "version": VERSION,
        "install_path": f"apps/{PACKAGE}/",
        "runtime_path": f"ano/runtime/apps/{APP_ID}/",
        "user_context_path": f"user/apps/{APP_ID}/",
        "output_path": "out/tiandao/",
        "type": "skill_app",
        "multi_agent": True,
        "pricing_model": "free",
        "safety": "entertainment_only_no_betting_advice",
        "runtime_mode": "staged_multi_agent_ritual",
        "required_heat": 75,
    }
    (workspace / "ano/registry/apps" / f"{APP_ID}.json").write_text(json.dumps(registry, ensure_ascii=False, indent=2), encoding="utf-8")

    customization = user_root / "agent_customization.yaml"
    if not customization.exists():
        customization.write_text("""app_id: ano.skill.tiandao
profile_name: default_tiandao_workflow
user_agent_overrides:
  added_agents: []
  modified_agents: []
notes:
  - 用户可在运行审批卡阶段用自然语言增删角色。
  - 本 App 默认启用 Safety Auditor Agent，防止预测/投注诱导表达。
  - v0.2.0 默认启用 Oracle Interpreter / Heat Questioner / Heat Gatekeeper，炉温达到 75% 才能开炉。
""", encoding="utf-8")

    append_event(workspace, {"event": "app.installed", "app_id": APP_ID, "package": PACKAGE, "version": VERSION})
    with (workspace / "USER_LOG.md").open("a", encoding="utf-8") as f:
        f.write(f"\n- Installed {PACKAGE} ({APP_ID}) v{VERSION}\n")
    print(f"Installed {PACKAGE} into {workspace}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
