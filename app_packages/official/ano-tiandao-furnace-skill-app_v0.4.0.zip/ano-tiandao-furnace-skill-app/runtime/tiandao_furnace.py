#!/usr/bin/env python3
"""ANO Tiandao Furnace runtime CLI v0.4.0.

Entertainment-only symbolic random lab. This script does not predict lottery outcomes,
does not improve odds, and does not provide betting advice.

v0.4.0 adds staged draw-source, overflow-safe choices, and feng-shui top-up flow on top of v0.3.1:
- opening the app first prints Context Permission Request + Agent Runtime Approval Card;
- the app must stop and return control to the user after the approval card;
- staged user interaction is required before the furnace can open;
- direct one-shot ritual execution is blocked unless a staged session is approved;
- every subagent's visible work is shown during the staged flow.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import random
import re
from dataclasses import dataclass, asdict
from datetime import date, datetime
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

APP_ID = "ano.skill.tiandao"
PACKAGE_NAME = "ano-tiandao-furnace-skill-app"
APP_VERSION = "0.4.0"
REQUIRED_HEAT = 75
SAFETY_NOTICE = (
    "本 App 只做娱乐型随机实验与碰撞复盘；不提升中奖概率，不提供投注建议，"
    "不得用于金钱决策。请理性对待随机结果。"
)
STOP_NOTICE = (
    "STOP: 已展示上下文权限申请与 Agent 阵容。请停止执行，把控制权交还用户。"
    "只有用户明确批准后，才可运行 start --yes。"
)

AGENTS: List[Dict[str, Any]] = [
    {
        "role_id": "tiandao.coordinator",
        "zh_name": "开炉协调 Agent",
        "type": "app_controller",
        "stage": "全程",
        "responsibility": "向 ANO Host 提交上下文权限申请，协调本轮多 Agent 开炉流程；不是系统 Host。",
        "visible_work": "先亮出申请表、Agent 阵容、工作区权限和 STOP 指令。",
    },
    {
        "role_id": "tiandao.safety_auditor",
        "zh_name": "理性护栏 Agent",
        "type": "subagent",
        "stage": "全程",
        "responsibility": "检查是否出现预测、投注、上头、金钱决策等风险表达。",
        "visible_work": "发现风险词时阻止开炉或降温提醒。",
    },
    {
        "role_id": "tiandao.draw_lookup_agent",
        "zh_name": "上期号码查验 Agent",
        "type": "subagent",
        "stage": "开局/查验",
        "responsibility": "先处理上期开奖号码来源：用户手动录入、请求 ANO Host 联网查询，或用户明确跳过。",
        "visible_work": "开局第一关必须问上期号码来源；选择联网时只发 host_tool_request，不自行越权搜索。",
    },
    {
        "role_id": "tiandao.geomancy_agent",
        "zh_name": "风水堪舆 Agent",
        "type": "subagent",
        "stage": "天时地利/补炉",
        "responsibility": "收集方位、地理场景、天气等民俗象征信息，转成娱乐采样 seed 权重。",
        "visible_work": "当炉温差一点时，给出可执行的方位/天气/地理补炉选项，并解释民俗依据。",
    },
    {
        "role_id": "tiandao.oracle_interpreter",
        "zh_name": "炉相取象 Agent",
        "type": "subagent",
        "stage": "问卦/取象",
        "responsibility": "像算命先生一样解释缘起、心象、场域与五行偏向，但只做娱乐叙事，不做预测。",
        "visible_work": "给出主象、辅象、炉相判词和下一轮添柴方向。",
    },
    {
        "role_id": "tiandao.heat_questioner",
        "zh_name": "添柴问答 Agent",
        "type": "subagent",
        "stage": "升温",
        "responsibility": "根据当前缺口动态提问，分批收集缘起、心象、场域、炉名和确认。",
        "visible_work": "每轮只给下一批问题，不允许一次性塞满参数直接开炉。",
    },
    {
        "role_id": "tiandao.heat_gatekeeper",
        "zh_name": "炉门守卫 Agent",
        "type": "subagent",
        "stage": "验炉",
        "responsibility": f"计算炉温并执行开炉门槛；低于 {REQUIRED_HEAT}% 或未确认娱乐用途时不许开炉。",
        "visible_work": "宣布当前炉温、缺什么柴、是否需要继续问答。",
    },
    {
        "role_id": "tiandao.symbol_sampler",
        "zh_name": "符号采样 Agent",
        "type": "subagent",
        "stage": "开炉后",
        "responsibility": "只在炉门守卫批准后，基于确定性 seed 生成娱乐候选样本。",
        "visible_work": "炉温未达标或未确认时保持待命。",
    },
    {
        "role_id": "tiandao.collision_reviewer",
        "zh_name": "碰撞复盘 Agent",
        "type": "subagent",
        "stage": "事后复盘",
        "responsibility": "录入结果后计算样本与结果的碰撞程度，生成复盘报告。",
        "visible_work": "只做事后碰撞，不把碰撞当作预测能力证明。",
    },
    {
        "role_id": "tiandao.experiment_archivist",
        "zh_name": "实验归档 Agent",
        "type": "subagent",
        "stage": "收尾",
        "responsibility": "归档实验输入、样本、安全提示、炉温记录和开炉报告。",
        "visible_work": "把报告写入 ANO runtime 或 out/tiandao/。",
    },
]

MOTIVES: Dict[str, Dict[str, Any]] = {
    "passing_by": {"label": "路过顺手", "heat": 5, "attention": 3, "safety": "normal", "bias": {"chaos": .05}},
    "impulsive": {"label": "临时起意", "heat": 3, "attention": 2, "safety": "normal", "bias": {"chaos": .08}},
    "omen_good": {"label": "今天有兆头", "heat": 12, "attention": 15, "safety": "normal", "auspicious": True, "bias": {"fire": .12, "stability": .1}},
    "number_appealing": {"label": "看见喜欢的数字", "heat": 8, "attention": 10, "safety": "normal", "auspicious": True, "bias": {"metal": .12, "stability": .05}},
    "dream_number": {"label": "梦见数字", "heat": 15, "attention": 20, "safety": "normal", "message": "梦象已入炉。本次采样加入潜意识扰动。", "bias": {"yin": .15, "water": .1}},
    "unlucky_rebound": {"label": "今天太倒霉", "heat": 5, "attention": 8, "safety": "watch", "message": "检测到倒霉反弹场。本次只适合象征性观测，不追，不补，不硬刚。", "bias": {"water": .1, "earth": .1}},
    "life_hitting": {"label": "被生活锤了", "heat": 8, "attention": 5, "safety": "watch", "message": "检测到现实挤压场。不要让钱包替情绪挨打。", "bias": {"earth": .15, "metal": .1}},
    "payday": {"label": "发工资日", "heat": 18, "attention": 15, "safety": "normal", "auspicious": True, "message": "时间中轴已激活。个人 seed 权重提高。", "bias": {"metal": .2, "earth": .1}},
    "anniversary": {"label": "生日/纪念日", "heat": 20, "attention": 20, "safety": "normal", "auspicious": True, "message": "今日具备纪念性中轴。个人 seed 权重提高。", "bias": {"earth": .15, "yang": .1}},
    "social_event": {"label": "参加活动", "heat": 15, "attention": 18, "safety": "normal", "bias": {"fire": .2, "yang": .15}},
    "friend_encourage": {"label": "朋友怂恿", "heat": 10, "attention": 12, "safety": "watch", "message": "检测到人言扰动场。请保持独立判断。", "bias": {"fire": .15, "motion": .1}},
    "post_party": {"label": "聚会后上头", "heat": 12, "attention": 10, "safety": "watch", "message": "检测到人气扰动场。本次适合作为娱乐观测，不宜冲动。", "bias": {"fire": .25, "yang": .2}},
    "pure_research": {"label": "纯粹研究", "heat": 8, "attention": 15, "safety": "normal", "auspicious": True, "message": "观测者状态良好。本次实验适合归档复盘。", "bias": {"stability": .1, "earth": .05}},
    "verify_xuanxue": {"label": "验证玄学", "heat": 10, "attention": 18, "safety": "normal", "auspicious": True, "message": "研究者模式已激活。本次实验适合归档复盘。", "bias": {"water": .1, "stability": .08}},
    "touch_universe": {"label": "想碰碰宇宙", "heat": 6, "attention": 8, "safety": "normal", "bias": {"chaos": .1}},
    "short_money": {"label": "最近缺钱", "heat": -8, "attention": -5, "safety": "warn", "message": "检测到高风险动机。天道哈希炉不支持回血、翻本、倍投。建议暂停或仅做娱乐观测。", "bias": {"stability": .15}},
}

MENTAL_STATES: Dict[str, Dict[str, Any]] = {
    "期待": {"label": "期待", "icon": "✨", "bias": {"yang": .2, "motion": .15}},
    "平静": {"label": "平静", "icon": "🧘", "bias": {"yin": .2, "stability": .15}},
    "兴奋": {"label": "兴奋", "icon": "🔥", "bias": {"yang": .25, "fire": .15, "motion": .2}},
    "烦躁": {"label": "烦躁", "icon": "💨", "bias": {"motion": .2, "chaos": .1}},
    "忧郁": {"label": "忧郁", "icon": "🌧", "bias": {"yin": .25, "water": .1}},
    "疲惫": {"label": "疲惫", "icon": "😴", "bias": {"yin": .15, "stability": .1}},
    "清醒": {"label": "清醒", "icon": "🧠", "bias": {"yang": .1, "stability": .15}},
    "迷茫": {"label": "迷茫", "icon": "🌫", "bias": {"chaos": .1, "water": .1}},
}

ACTIVITY_FIELDS: Dict[str, Dict[str, Any]] = {
    "工作": {"label": "工作", "icon": "💼", "bias": {"metal": .15, "fire": .1}},
    "学习": {"label": "学习", "icon": "📚", "bias": {"water": .15, "wood": .1}},
    "休息": {"label": "休息", "icon": "🛋", "bias": {"earth": .15, "water": .1}},
    "运动": {"label": "运动", "icon": "🏃", "bias": {"fire": .2, "wood": .1, "motion": .15}},
    "聚会": {"label": "聚会", "icon": "🎉", "bias": {"fire": .2, "earth": .1, "yang": .15}},
    "旅行": {"label": "旅行", "icon": "✈️", "bias": {"water": .2, "wood": .1}},
    "购物": {"label": "购物", "icon": "🛍", "bias": {"earth": .15, "metal": .15}},
    "创作": {"label": "创作", "icon": "🎨", "bias": {"fire": .2, "water": .1, "motion": .1}},
    "commute": {"label": "通勤", "icon": "🚇", "bias": {"motion": .15, "metal": .1}},
    "coffee": {"label": "喝咖啡", "icon": "☕", "bias": {"fire": .1, "water": .1}},
    "eating": {"label": "吃饭", "icon": "🍜", "bias": {"earth": .15, "fire": .1}},
    "walking": {"label": "散步", "icon": "🚶", "bias": {"wood": .15, "motion": .1}},
    "live": {"label": "看直播", "icon": "📡", "bias": {"fire": .15, "yang": .15}},
    "shooting": {"label": "拍摄", "icon": "🎬", "bias": {"fire": .2, "metal": .1}},
    "bills": {"label": "看账单", "icon": "🧾", "safety": "watch", "message": "检测到财务挤压场。建议保持理性，只做娱乐观测。", "bias": {"metal": .15, "earth": .1}},
    "salary": {"label": "发工资", "icon": "💸", "high_context": True, "bias": {"metal": .25, "yang": .15}},
    "lottery_shop": {"label": "路过彩票站", "icon": "🚪", "high_context": True, "safety": "watch", "message": "检测到冲动场域。请保持理性，不要上头。", "bias": {"chaos": .15, "fire": .1}},
    "repeat_number": {"label": "看见重复数字", "icon": "🔢", "high_context": True, "bias": {"stability": .15}},
    "impulse": {"label": "临时起意", "icon": "🎲", "safety": "watch", "message": "检测到随机扰动场。请保持独立判断。", "bias": {"chaos": .2}},
    "phone": {"label": "刷手机", "icon": "📱", "bias": {"chaos": .1}},
    "alone": {"label": "独处", "icon": "🌙", "bias": {"yin": .2, "water": .1}},
    "waiting": {"label": "等人", "icon": "⏳", "bias": {"earth": .1, "water": .15}},
    "pickup_kid": {"label": "校门口接娃", "icon": "🏫", "bias": {"wood": .15, "earth": .1, "water": .1}},
    "just_showered": {"label": "刚洗完澡", "icon": "🛁", "bias": {"water": .2, "yin": .15}},
}

DIRECTIONS: Dict[str, Dict[str, Any]] = {
    "east": {"label": "东方/日出方向", "phase": "wood", "heat": 4, "bias": {"wood": .2, "yang": .08}, "theory": "八卦取震位，东方属木，主生发。"},
    "south": {"label": "南方/向阳方向", "phase": "fire", "heat": 4, "bias": {"fire": .22, "yang": .1}, "theory": "八卦取离位，南方属火，主明亮与显现。"},
    "west": {"label": "西方/日落方向", "phase": "metal", "heat": 4, "bias": {"metal": .22, "yin": .05}, "theory": "八卦取兑位，西方属金，主收束与成形。"},
    "north": {"label": "北方/背阴方向", "phase": "water", "heat": 4, "bias": {"water": .22, "yin": .1}, "theory": "八卦取坎位，北方属水，主流动与潜藏。"},
    "southeast": {"label": "东南/风口方向", "phase": "wood", "heat": 5, "bias": {"wood": .18, "fire": .08, "motion": .08}, "theory": "巽位东南，取风木之象，主流通。"},
    "southwest": {"label": "西南/厚土方向", "phase": "earth", "heat": 5, "bias": {"earth": .22, "yin": .04}, "theory": "坤位西南，取厚土承载之象。"},
    "northwest": {"label": "西北/高位方向", "phase": "metal", "heat": 5, "bias": {"metal": .18, "yang": .06}, "theory": "乾位西北，取天金之象。"},
    "northeast": {"label": "东北/山门方向", "phase": "earth", "heat": 5, "bias": {"earth": .18, "wood": .05}, "theory": "艮位东北，取山土止定之象。"},
    "unknown": {"label": "不确定方向", "phase": "earth", "heat": 1, "bias": {"earth": .05}, "theory": "方向未定，归中土作缓冲。"},
}

WEATHERS: Dict[str, Dict[str, Any]] = {
    "sunny": {"label": "晴/有阳光", "phase": "fire", "heat": 4, "bias": {"fire": .2, "yang": .12}, "theory": "晴明属阳火，主显现。"},
    "cloudy": {"label": "多云/阴天", "phase": "earth", "heat": 3, "bias": {"earth": .14, "yin": .06}, "theory": "云气遮光，取土湿承载之象。"},
    "rain": {"label": "下雨/潮湿", "phase": "water", "heat": 5, "bias": {"water": .24, "yin": .12}, "theory": "雨水属水，主流动与潜藏。"},
    "wind": {"label": "有风", "phase": "wood", "heat": 4, "bias": {"wood": .18, "motion": .12}, "theory": "风动属巽木，主流通。"},
    "snow": {"label": "下雪/寒冷", "phase": "water", "heat": 4, "bias": {"water": .16, "metal": .1, "yin": .12}, "theory": "寒雪取水金之象。"},
    "thunder": {"label": "雷/暴雨将至", "phase": "wood", "heat": 6, "bias": {"wood": .16, "fire": .12, "motion": .15}, "theory": "雷动震木，兼火气外发。"},
    "unknown": {"label": "不清楚天气", "phase": "earth", "heat": 1, "bias": {"earth": .05}, "theory": "天时未明，归中土缓冲。"},
    "weather_lookup_requested": {"label": "让 ANO Host 查询当前天气", "phase": "earth", "heat": 0, "bias": {}, "theory": "天气需由 ANO Host 查询后回填，App 不越权联网。"},
}

GEO_FIELDS: Dict[str, Dict[str, Any]] = {
    "home": {"label": "家中", "phase": "earth", "heat": 3, "bias": {"earth": .18, "yin": .05}, "theory": "居所取土，主承载。"},
    "office": {"label": "办公室/工作地", "phase": "metal", "heat": 3, "bias": {"metal": .16, "fire": .06}, "theory": "办公器物多金，兼事务火。"},
    "near_water": {"label": "近水/河边/海边", "phase": "water", "heat": 5, "bias": {"water": .25, "motion": .06}, "theory": "水口取财流之象，但本 App 只作民俗叙事。"},
    "mountain": {"label": "近山/高地", "phase": "earth", "heat": 5, "bias": {"earth": .22, "stability": .1}, "theory": "山为艮土，取止定。"},
    "street": {"label": "街边/路上", "phase": "wood", "heat": 4, "bias": {"wood": .12, "motion": .16}, "theory": "道路取动线，兼木气生发。"},
    "shop": {"label": "商场/店铺附近", "phase": "metal", "heat": 4, "bias": {"metal": .18, "earth": .08}, "theory": "交易之地取金土成形。"},
    "school": {"label": "学校/培训机构附近", "phase": "wood", "heat": 4, "bias": {"wood": .2, "water": .05}, "theory": "文教取木，主生长。"},
    "station": {"label": "车站/地铁/机场", "phase": "water", "heat": 4, "bias": {"water": .16, "motion": .18}, "theory": "交通流动取水象。"},
    "unknown": {"label": "不方便说/不确定", "phase": "earth", "heat": 1, "bias": {"earth": .05}, "theory": "地利未明，归中土缓冲。"},
}

PHASE_NAMES = {"wood": "木", "fire": "火", "earth": "土", "metal": "金", "water": "水"}
RISKY_WORDS = ["必中", "稳赚", "倍投", "翻本", "梭哈", "贷款", "借钱", "包中", "预测", "买多少", "推荐投注"]


def dumps(obj: Any) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=2)


def print_json(obj: Any) -> None:
    print(dumps(obj))


def workspace_root(start: Optional[Path] = None) -> Path:
    cur = (start or Path.cwd()).resolve()
    candidates = [cur] + list(cur.parents)
    for p in candidates:
        if (p / "ano").is_dir() and (p / "user").is_dir() and (p / "apps").is_dir():
            return p
    return cur


def state_dir() -> Path:
    root = workspace_root()
    if (root / "ano").is_dir():
        p = root / "ano" / "runtime" / "apps" / APP_ID / "state"
    else:
        p = Path.cwd() / ".tiandao_state"
    p.mkdir(parents=True, exist_ok=True)
    return p


def reports_dir() -> Path:
    root = workspace_root()
    if (root / "ano").is_dir():
        p = root / "ano" / "runtime" / "apps" / APP_ID / "reports"
    else:
        p = Path.cwd() / ".tiandao_reports"
    p.mkdir(parents=True, exist_ok=True)
    return p


def out_dir() -> Path:
    root = workspace_root()
    p = root / "out" / "tiandao" if (root / "out").is_dir() else Path.cwd() / "out"
    p.mkdir(parents=True, exist_ok=True)
    return p


def parse_numbers(text: str, expected: int, low: int, high: int, label: str) -> List[int]:
    nums = [int(x) for x in re.findall(r"\d+", text or "")]
    if len(nums) != expected:
        raise ValueError(f"{label} 必须恰好 {expected} 个数字")
    if any(n < low or n > high for n in nums):
        raise ValueError(f"{label} 数字必须在 {low}-{high} 之间")
    if len(set(nums)) != len(nums):
        raise ValueError(f"{label} 数字不能重复")
    return nums


def split_ids(text: Optional[str]) -> List[str]:
    if not text:
        return []
    parts = re.split(r"[,，、;；\s]+", text.strip())
    return [p for p in parts if p]


def normalize_by_label(items: List[str], table: Dict[str, Dict[str, Any]], limit: int) -> List[str]:
    labels = {v.get("label", k): k for k, v in table.items()}
    out: List[str] = []
    for x in items:
        key = x if x in table else labels.get(x, x)
        if key in table and key not in out:
            out.append(key)
    return out[:limit]


def clamp(x: float, low: float, high: float) -> float:
    return max(low, min(high, x))


def default_aura() -> Dict[str, float]:
    return {"wood": .2, "fire": .2, "earth": .2, "metal": .2, "water": .2, "yin": .5, "yang": .5, "motion": .5, "stability": .5, "chaos": .5}


def apply_bias(aura: Dict[str, float], bias: Dict[str, float]) -> None:
    for k, delta in (bias or {}).items():
        aura[k] = clamp(aura.get(k, 0.0) + float(delta), 0.0, 1.0)


@dataclass
class RitualState:
    session_id: str
    approved_runtime: bool
    previous_front: List[int]
    previous_back: List[int]
    name: str
    motives: List[str]
    mental_states: List[str]
    activities: List[str]
    chaos: float
    confirmed_entertainment_only: bool
    run_date: str
    draw_no: str
    created_at: str
    updated_at: str
    previous_source: str = ""
    direction: str = ""
    weather: str = ""
    geo_field: str = ""
    location_text: str = ""
    ambient_tokens: List[str] = None
    selection_notes: List[str] = None
    status: str = "collecting"


    def __post_init__(self) -> None:
        if self.ambient_tokens is None:
            self.ambient_tokens = []
        if self.selection_notes is None:
            self.selection_notes = []


def new_session_id() -> str:
    return "td_" + datetime.now().strftime("%Y%m%d_%H%M%S")


def session_path(session_id: str) -> Path:
    return state_dir() / f"{session_id}.json"


def save_state(st: RitualState) -> None:
    st.updated_at = datetime.now().isoformat(timespec="seconds")
    session_path(st.session_id).write_text(dumps(asdict(st)), encoding="utf-8")


def load_state(session_id: str) -> RitualState:
    p = session_path(session_id)
    if not p.exists():
        raise SystemExit(f"找不到 session：{session_id}")
    data = json.loads(p.read_text(encoding="utf-8"))
    for key, default in {
        "previous_source": "",
        "direction": "",
        "weather": "",
        "geo_field": "",
        "location_text": "",
        "ambient_tokens": [],
        "selection_notes": [],
    }.items():
        data.setdefault(key, default)
    return RitualState(**data)


def context_permission_request() -> Dict[str, Any]:
    return {
        "app_id": APP_ID,
        "package_name": PACKAGE_NAME,
        "version": APP_VERSION,
        "request_type": "context_permission_request",
        "mode": "staged_multi_agent_ritual",
        "host_rule": "App 不是 Host；本 App 只能向 ANO Host 请求角色、上下文和工作区权限。",
        "context_budget": {"requested_level": "low", "max_tokens_hint": 32000, "allow_full_project_scan": False, "allow_long_context": False},
        "agent_roster": [{"role_id": a["role_id"], "name": a["zh_name"], "type": a["type"], "stage": a["stage"], "visible_work": a["visible_work"]} for a in AGENTS],
        "subagent_quota": {"coordinator": 1, "max_concurrent_subagents": 6, "requested_roles": [a["role_id"] for a in AGENTS]},
        "workspace_permissions": {
            "read": ["apps/ano-tiandao-furnace-skill-app/", "user/apps/ano.skill.tiandao/", "ano/runtime/apps/ano.skill.tiandao/inbox/"],
            "write": ["ano/runtime/apps/ano.skill.tiandao/state/", "ano/runtime/apps/ano.skill.tiandao/reports/", "ano/runtime/apps/ano.skill.tiandao/outbox/", "out/tiandao/"],
            "denied": ["ano/kernel/", "ano/runtime/process_table.json", "ano/runtime/apps/*/private/", "apps/*/private/", ".git/"],
        },
        "runtime_gates": {
            "required_heat": REQUIRED_HEAT,
            "direct_answer_forbidden_before_heat_ready": True,
            "staged_questions_required": True,
            "user_confirmation_required_before_opening": True,
        },
    }


def approval_card() -> Dict[str, Any]:
    return {
        "title": "ANO Agent 运行审批卡：Tiandao Furnace",
        "safety_notice": SAFETY_NOTICE,
        "agent_roster": [{"agent": a["zh_name"], "role_id": a["role_id"], "will_do": a["visible_work"]} for a in AGENTS],
        "run_protocol": [
            "1. open：只展示上下文权限申请和 Agent 阵容，然后停止。",
            "2. 用户批准后，运行 start --yes 创建开炉 session。",
            "3. answer 分批回答添柴问题，炉温不足继续问。",
            "4. 炉温达到 75% 后，还必须确认只做娱乐实验。",
            "5. 确认后才允许符号采样 Agent 开炉。",
        ],
        "first_user_action_after_approval": "python runtime/tiandao_furnace.py start --yes",
        "stop_after_printing": True,
    }


def agent_trace(stage: str, st: Optional[RitualState] = None, heat: Optional[Dict[str, Any]] = None) -> List[Dict[str, str]]:
    base = []
    if stage == "open":
        for a in AGENTS:
            base.append({"agent": a["role_id"], "doing": f"待审批：{a['visible_work']}"})
        return base
    base.append({"agent": "tiandao.coordinator", "doing": "已获用户批准，创建 staged session，并向 ANO Host 声明本次多 Agent 流程。"})
    base.append({"agent": "tiandao.safety_auditor", "doing": "扫描动机、场域和用户话术风险。"})
    base.append({"agent": "tiandao.draw_lookup_agent", "doing": "查验上期号码来源；未录入或未授权查询时，不跳过这一关。"})
    base.append({"agent": "tiandao.geomancy_agent", "doing": "收集方位、天气、地理场，作为民俗象征 seed 权重。"})
    base.append({"agent": "tiandao.oracle_interpreter", "doing": "根据已收集信息取象；信息不足时只给炉相方向，不给结果。"})
    base.append({"agent": "tiandao.heat_questioner", "doing": "根据缺失要素生成下一批问题，用回答继续升温。"})
    if heat:
        gate = "准许进入确认" if heat.get("temperature", 0) >= REQUIRED_HEAT else "炉温不足，继续添柴"
        base.append({"agent": "tiandao.heat_gatekeeper", "doing": f"验炉：{heat.get('temperature')}% / {REQUIRED_HEAT}%，{gate}。"})
    else:
        base.append({"agent": "tiandao.heat_gatekeeper", "doing": "等待足够信息后验炉。"})
    if st and st.status == "opened":
        base.append({"agent": "tiandao.symbol_sampler", "doing": "炉温达标且用户已确认娱乐用途，执行娱乐采样。"})
    else:
        base.append({"agent": "tiandao.symbol_sampler", "doing": "保持待命：未达炉温或未获娱乐用途确认前不采样。"})
    base.append({"agent": "tiandao.experiment_archivist", "doing": "记录本轮状态、问题批次和后续指令。"})
    return base


def safety_audit_text(text: str) -> Dict[str, Any]:
    found = [w for w in RISKY_WORDS if w in (text or "")]
    return {
        "agent": "tiandao.safety_auditor",
        "risk_level": "warn" if found else "ok",
        "found_terms": found,
        "safe_rewrite": "请改成：本次仅作娱乐随机实验，不作为预测、投注或金钱决策依据。" if found else "当前文本未发现明显风险表达。",
        "safety_notice": SAFETY_NOTICE,
    }


def combined_safety(st: RitualState) -> Dict[str, Any]:
    text = " ".join(st.motives + st.mental_states + st.activities + [st.name, st.direction, st.weather, st.geo_field, st.location_text])
    audit = safety_audit_text(text)
    warnings: List[str] = []
    risk = audit["risk_level"]
    for m in st.motives:
        meta = MOTIVES.get(m, {})
        if meta.get("message"):
            warnings.append(meta["message"])
        if meta.get("safety") == "warn":
            risk = "warn"
        elif meta.get("safety") == "watch" and risk != "warn":
            risk = "watch"
    for a in st.activities:
        meta = ACTIVITY_FIELDS.get(a, {})
        if meta.get("message"):
            warnings.append(meta["message"])
        if meta.get("safety") == "warn":
            risk = "warn"
        elif meta.get("safety") == "watch" and risk != "warn":
            risk = "watch"
    return {"risk_level": risk, "warnings": warnings, "found_terms": audit["found_terms"]}


def apply_fengshui_fields(aura: Dict[str, float], st: RitualState) -> Tuple[int, List[str], List[str]]:
    heat = 0
    theories: List[str] = []
    labels: List[str] = []
    for table, value, name in [(DIRECTIONS, st.direction, "方位"), (WEATHERS, st.weather, "天气"), (GEO_FIELDS, st.geo_field, "地理")]:
        if value and value in table and value not in ("weather_lookup_requested",):
            meta = table[value]
            heat += int(meta.get("heat", 0))
            apply_bias(aura, meta.get("bias", {}))
            labels.append(f"{name}:{meta.get('label')}")
            theories.append(meta.get("theory", ""))
    return min(heat, 14), [t for t in theories if t], labels


def fengshui_explanation(st: RitualState, heat: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "agent": "tiandao.geomancy_agent",
        "disclaimer": "这里的风水只作为民俗象征与娱乐叙事，不是科学预测，也不会制造概率优势。",
        "selected": {
            "direction": DIRECTIONS.get(st.direction, {}).get("label", st.direction or "未选择"),
            "weather": WEATHERS.get(st.weather, {}).get("label", st.weather or "未选择"),
            "geo_field": GEO_FIELDS.get(st.geo_field, {}).get("label", st.geo_field or "未选择"),
            "location_text": st.location_text or "未提供",
        },
        "folk_theory_basis": heat.get("fengshui_theory", []),
        "how_it_affects_numbers": [
            "方位按八卦方位映射到五行权重，例如东木、南火、西金、北水。",
            "天气按天时映射到五行权重，例如晴火、雨水、风木、云土。",
            "地理场按藏风聚气/动静之象映射到五行权重，例如近水偏水、近山偏土、道路偏动。",
            "这些权重不会预测结果，只会作为 seed salt 与采样偏置进入娱乐随机过程。",
        ],
        "symbolic_formula": "民俗象征 → 五行权重 → seed 混合 → 娱乐采样",
    }


def normalize_with_overflow(raw: str, table: Dict[str, Dict[str, Any]], limit: int, label: str) -> Tuple[List[str], List[str], List[str]]:
    ids = split_ids(raw)
    normalized = normalize_by_label(ids, table, len(ids) or limit)
    used = list(dict.fromkeys(normalized))[:limit]
    overflow = list(dict.fromkeys(normalized))[limit:]
    notes: List[str] = []
    ambient: List[str] = []
    if overflow:
        overflow_labels = [table.get(x, {}).get("label", x) for x in overflow]
        notes.append(f"{label}最多建议选 {limit} 个；已采用前 {limit} 个，其余转为炉边余炭，不中断流程：{', '.join(overflow_labels)}")
        ambient.extend([f"{label}余炭:{x}" for x in overflow])
    return used, overflow, notes


def calculate_heat(st: RitualState) -> Dict[str, Any]:
    aura = default_aura()
    motive_heat = 0
    attention = 0
    warnings: List[str] = []
    for m in st.motives:
        meta = MOTIVES.get(m, {})
        motive_heat += int(meta.get("heat", 0))
        attention += int(meta.get("attention", 0))
        apply_bias(aura, meta.get("bias", {}))
        if meta.get("message"):
            warnings.append(meta["message"])
    for m in st.mental_states:
        apply_bias(aura, MENTAL_STATES.get(m, {}).get("bias", {}))
    for a in st.activities:
        meta = ACTIVITY_FIELDS.get(a, {})
        apply_bias(aura, meta.get("bias", {}))
        if meta.get("message"):
            warnings.append(meta["message"])
    fengshui_heat, fengshui_theory, fengshui_labels = apply_fengshui_fields(aura, st)
    phases = {k: aura[k] for k in ["wood", "fire", "earth", "metal", "water"]}
    main_phase = max(phases, key=phases.get)
    secondary_phase = sorted(phases.items(), key=lambda x: x[1], reverse=True)[1][0]
    base = 20
    mental_heat = min(len(st.mental_states) * 3, 8)
    activity_heat = min(len(st.activities) * 2, 8)
    name_heat = 5 if st.name.strip() else 0
    mirror_heat = 10 if st.previous_front and st.previous_back else (-5 if st.previous_source == "skip" else 0)
    ambient_heat = min(len(st.ambient_tokens or []), 3)
    element_bonus = round(max(phases.values()) * 20)
    confirm_bonus = 5 if st.confirmed_entertainment_only else 0
    raw = base + motive_heat + mental_heat + activity_heat + name_heat + mirror_heat + fengshui_heat + ambient_heat + element_bonus + confirm_bonus
    safety = combined_safety(st)
    if safety["risk_level"] == "warn":
        raw -= 25
    elif safety["risk_level"] == "watch":
        raw -= 8
    temp = int(clamp(raw, 0, 100))
    missing: List[str] = []
    if not st.previous_front or not st.previous_back:
        if st.previous_source == "web_lookup_requested":
            missing.append("等待 ANO Host 联网查询上期开奖号码后回填")
        elif st.previous_source != "skip":
            missing.append("缺上期号码：请手动录入，或让 ANO Host 联网查询，或明确跳过")
    if not st.motives:
        missing.append("缺缘起：请回答今日为何开炉")
    if not st.mental_states:
        missing.append("缺心象：请选择今日状态")
    if not st.activities:
        missing.append("缺场域：请选择当前场景")
    if not st.name.strip():
        missing.append("缺炉名：请给本轮实验起一个炉名")
    if st.weather == "weather_lookup_requested":
        missing.append("等待 ANO Host 查询当前天气并回填 weather")
    if temp >= REQUIRED_HEAT and not st.confirmed_entertainment_only:
        missing.append("炉温达标，但还需确认只做娱乐随机实验")
    return {
        "base": base,
        "motive_heat": motive_heat,
        "mental_heat": mental_heat,
        "activity_heat": activity_heat,
        "name_heat": name_heat,
        "mirror_heat": mirror_heat,
        "fengshui_heat": fengshui_heat,
        "ambient_heat": ambient_heat,
        "element_bonus": element_bonus,
        "confirm_bonus": confirm_bonus,
        "temperature": temp,
        "required_temperature": REQUIRED_HEAT,
        "can_open": temp >= REQUIRED_HEAT and st.confirmed_entertainment_only and safety["risk_level"] != "warn",
        "main_phase": PHASE_NAMES[main_phase],
        "secondary_phase": PHASE_NAMES[secondary_phase],
        "risk_level": safety["risk_level"],
        "fengshui_labels": fengshui_labels,
        "fengshui_theory": fengshui_theory,
        "safety_warnings": list(dict.fromkeys(warnings + safety["warnings"] + (st.selection_notes or []))),
        "missing_or_warning": missing,
    }


def oracle_reading(st: RitualState, heat: Dict[str, Any]) -> Dict[str, Any]:
    attention = sum(int(MOTIVES.get(m, {}).get("attention", 0)) for m in st.motives)
    if attention >= 35:
        ua = "极高"
    elif attention >= 20:
        ua = "较高"
    elif attention >= 8:
        ua = "微亮"
    else:
        ua = "未聚焦"
    motive_labels = [MOTIVES[m]["label"] for m in st.motives if m in MOTIVES]
    activity_labels = [ACTIVITY_FIELDS[a]["label"] for a in st.activities if a in ACTIVITY_FIELDS]
    judgement = f"主象 {heat['main_phase']}，辅象 {heat['secondary_phase']}。"
    if heat["temperature"] < REQUIRED_HEAT:
        judgement += "炉火未稳，不能开炉，需继续添柴问答。"
    elif not st.confirmed_entertainment_only:
        judgement += "炉火已足，但炉门未签娱乐确认，不可开炉。"
    else:
        judgement += "炉门已开，但这只是随机宇宙的娱乐回声。"
    return {
        "agent": "tiandao.oracle_interpreter",
        "style": "算命式取象，但不做预测",
        "main_phase": heat["main_phase"],
        "secondary_phase": heat["secondary_phase"],
        "motive_signs": motive_labels,
        "mental_signs": st.mental_states,
        "field_signs": activity_labels,
        "fengshui_reading": fengshui_explanation(st, heat),
        "universe_attention": ua,
        "judgement": judgement,
    }


def make_questions(st: RitualState, heat: Dict[str, Any]) -> Dict[str, Any]:
    batches: List[Dict[str, Any]] = []
    heat_gap = max(0, REQUIRED_HEAT - int(heat.get("temperature", 0)))

    if (not st.previous_front or not st.previous_back) and st.previous_source == "web_lookup_requested":
        batches.append({
            "stage": "等待上期号码查验",
            "question": "已选择让 ANO Host 联网查上期开奖号码。请先完成查验，再把结果回填入炉。",
            "answer_key": "front|back|previous_source",
            "host_tool_request": {
                "kind": "web_lookup",
                "purpose": "查询上一期大乐透/用户指定玩法的官方开奖号码，用作娱乐复盘镜像，不作为预测依据。",
                "suggested_query_zh": "大乐透 上期开奖结果 官方 开奖号码",
                "return_command_template": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --previous-source web_lookup_confirmed --front \"<前区5个>\" --back \"<后区2个>\"",
            },
            "options": [
                {"id": "manual_instead", "label": "我改为手动输入上期号码", "kind": "input"},
                {"id": "skip", "label": "跳过上期号码（会降温）", "kind": "choice"},
            ],
        })
    elif st.weather == "weather_lookup_requested":
        loc = st.location_text or "用户当前位置/当前城市"
        batches.append({
            "stage": "等待当前天气查验",
            "question": "已选择让 ANO Host 查询当前天气。请先完成天气查询，再把天气象回填入炉。",
            "answer_key": "weather",
            "host_tool_request": {
                "kind": "weather_lookup",
                "purpose": "查询用户指定地点/当前位置的当前天气，用作风水添柴的民俗象征输入，不作为预测依据。",
                "suggested_query_zh": f"{loc} 当前天气",
                "return_command_template": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --weather <sunny|cloudy|rain|wind|snow|thunder|unknown>",
            },
            "options": [
                {"id": "manual_weather", "label": "我改为手动选择天气", "kind": "choice"},
                {"id": "unknown", "label": "不查了，按天气不明处理", "kind": "choice"},
            ],
        })
    elif not st.previous_front or not st.previous_back:
        batches.append({
            "stage": "上期号码入炉",
            "question": "先处理上期开奖号码。你要手动录入，还是让 ANO Host 联网查官方上期号码？",
            "answer_key": "previous_source|front|back",
            "options": [
                {"id": "manual", "label": "我手动输入：前区5个 + 后区2个", "example_command": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --previous-source manual --front \"1 2 3 4 5\" --back \"1 2\""},
                {"id": "web_lookup_requested", "label": "让 ANO Host 联网查官方上期号码", "example_command": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --previous-source web_lookup_requested"},
                {"id": "skip", "label": "暂时跳过（镜像火 -5，不推荐）", "example_command": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --previous-source skip"},
            ],
        })
    elif not st.motives:
        batches.append({
            "stage": "缘起问火",
            "question": "今日为何开炉？最多选 3 个；多选不会报错，超出的会转为炉边余炭。",
            "answer_key": "motive",
            "options": [{"id": k, "label": v["label"], "heat": v.get("heat", 0), "safety": v.get("safety", "normal")} for k, v in MOTIVES.items()],
        })
    elif not st.mental_states:
        batches.append({
            "stage": "心象添柴",
            "question": "你现在的心象是什么？建议最多选 2 个；多选会自动处理，不会卡住。",
            "answer_key": "mental",
            "options": [{"id": k, "label": v["label"], "icon": v.get("icon", "")} for k, v in MENTAL_STATES.items()],
        })
    elif not st.activities:
        batches.append({
            "stage": "场域入炉",
            "question": "你现在处在什么场域？最多选 3 个；多选会自动处理。",
            "answer_key": "activity",
            "options": [{"id": k, "label": v["label"], "icon": v.get("icon", ""), "safety": v.get("safety", "normal")} for k, v in ACTIVITY_FIELDS.items()],
        })
    elif not st.direction or not st.weather or not st.geo_field:
        batches.append({
            "stage": "风水添柴",
            "question": "补一口天时地利：选择当前方位、天气、地理场。天气可手动选，也可让 ANO Host 查询当前天气。用于民俗象征 seed，不是预测依据。",
            "answer_key": "direction|weather|geo_field|location",
            "heat_gap": heat_gap,
            "options": {
                "directions": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in DIRECTIONS.items()],
                "weathers": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in WEATHERS.items()],
                "geo_fields": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in GEO_FIELDS.items()],
            },
            "example_command": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --direction south --weather sunny --geo-field home",
            "weather_lookup_example": f"python runtime/tiandao_furnace.py answer --session {st.session_id} --location \"Tokyo\" --weather weather_lookup_requested",
        })
    elif not st.name.strip():
        batches.append({
            "stage": "炉名落款",
            "question": "给这一炉起个名字。名字会进入 seed，但不代表任何概率优势。",
            "answer_key": "name",
            "options": [
                {"id": "free_text", "label": "自由输入炉名", "example": "深夜路过派"},
                {"id": "auto_name", "label": "让 Agent 起一个炉名", "example": "月下散步炉"},
            ],
        })
    elif heat["temperature"] >= REQUIRED_HEAT and not st.confirmed_entertainment_only:
        batches.append({
            "stage": "炉门确认",
            "question": "炉温达标。是否确认只作为娱乐随机实验开炉，不把结果当预测或投注建议？",
            "answer_key": "confirm",
            "options": [
                {"id": "yes_entertainment_only", "label": "确认：只做娱乐实验，不当预测"},
                {"id": "pause", "label": "暂停：不想开炉"},
            ],
        })
    else:
        batches.append({
            "stage": "补火追问",
            "question": f"炉温还差 {heat_gap}。不要抓头，直接从下面选一个补炉动作。",
            "answer_key": "direction|weather|geo_field|motive|mental|activity|name",
            "heat_gap": heat_gap,
            "options": [
                {"id": "direction", "label": "补方位：东/南/西/北/东南/西南/西北/东北"},
                {"id": "weather", "label": "补天气：晴/雨/风/云/雪/雷"},
                {"id": "geo_field", "label": "补地理：家中/办公室/近水/近山/街边/学校/车站"},
                {"id": "pure_research", "label": "补缘起：纯粹研究"},
                {"id": "清醒", "label": "补心象：清醒"},
                {"id": "repeat_number", "label": "补场域：看见重复数字"},
            ],
        })
    prompt = None
    if batches:
        b = batches[0]
        prompt = f"【{b['stage']}】{b['question']}"
    return {
        "agent": "tiandao.heat_questioner",
        "mode": "dynamic_question_batch",
        "note": "问题按当前炉温、缺失要素和风险信号动态生成；Agent 应直接把 next_user_prompt 读给用户，不要等待用户说继续。",
        "question_batches": batches,
        "next_user_prompt": prompt,
        "agent_instruction": "把 next_user_prompt 和选项展示给用户，然后等待用户回答；不要自行开炉，不要要求用户先说‘继续’。",
    }

def sample(st: RitualState, count: int = 5) -> Dict[str, Any]:
    seed_source = dumps(asdict(st)) + "|" + APP_VERSION
    seed = hashlib.sha256(seed_source.encode("utf-8")).hexdigest()
    rng = random.Random(int(seed[:16], 16))
    picks = []
    for _ in range(count):
        front = sorted(rng.sample(range(1, 36), 5))
        back = sorted(rng.sample(range(1, 13), 2))
        score = round(rng.random() * 100, 2)
        picks.append({"front": front, "back": back, "symbolic_score": score, "explanation": "风水/心象/缘起只作为 seed salt 与娱乐权重，不代表概率优势。"})
    return {"agent": "tiandao.symbol_sampler", "opened": True, "mode": "entertainment_symbolic_sampling_after_heat_gate", "seed": seed, "count": count, "picks": picks, "generation_model": "民俗象征 → 五行权重 → seed 混合 → 娱乐采样；不是预测模型。", "safety_notice": SAFETY_NOTICE}


def report_for_state(st: RitualState) -> Dict[str, Any]:
    heat = calculate_heat(st)
    opened = heat["can_open"]
    if opened:
        st.status = "opened"
        save_state(st)
    rep: Dict[str, Any] = {
        "mode": "ano_hosted_staged_ritual_furnace",
        "app_id": APP_ID,
        "version": APP_VERSION,
        "safety_notice": SAFETY_NOTICE,
        "session_id": st.session_id,
        "status": st.status,
        "input": asdict(st),
        "agent_trace": agent_trace("answer", st, heat),
        "oracle_reading": oracle_reading(st, heat),
        "furnace_status": heat,
        "next_questions": make_questions(st, heat) if not opened else {"agent": "tiandao.heat_questioner", "message": "炉门已开，本轮不再提问。", "next_user_prompt": None},
        "opening_result": None,
        "next_command_hint": None,
    }
    rep["next_user_prompt"] = rep.get("next_questions", {}).get("next_user_prompt") if isinstance(rep.get("next_questions"), dict) else None
    rep["agent_instruction"] = rep.get("next_questions", {}).get("agent_instruction") if isinstance(rep.get("next_questions"), dict) else None
    batches = rep.get("next_questions", {}).get("question_batches", []) if isinstance(rep.get("next_questions"), dict) else []
    if batches and batches[0].get("host_tool_request"):
        rep["host_tool_request"] = batches[0]["host_tool_request"]
        rep["next_command_hint"] = batches[0]["host_tool_request"].get("return_command_template")
    if opened:
        rep["opening_result"] = sample(st)
        rep["next_command_hint"] = f"python runtime/tiandao_furnace.py review --pick-front \"{ ' '.join(map(str, rep['opening_result']['picks'][0]['front'])) }\" --pick-back \"{ ' '.join(map(str, rep['opening_result']['picks'][0]['back'])) }\" --result-front \"...\" --result-back \"...\""
        (reports_dir() / f"{st.session_id}_opened.json").write_text(dumps(rep), encoding="utf-8")
    else:
        rep["next_command_hint"] = f"python runtime/tiandao_furnace.py answer --session {st.session_id} --motive \"...\" --mental \"...\" --activity \"...\" --name \"...\""
        (reports_dir() / f"{st.session_id}_pending.json").write_text(dumps(rep), encoding="utf-8")
    return rep


def cmd_open(_args: argparse.Namespace) -> None:
    print_json({
        "mode": "open_app_permission_preview",
        "app_id": APP_ID,
        "version": APP_VERSION,
        "message": "已打开 ANO Tiandao Furnace Skill App，但尚未启动运行时。",
        "context_permission_request": context_permission_request(),
        "agent_runtime_approval_card": approval_card(),
        "agent_trace": agent_trace("open"),
        "required_user_decision": "请用户确认是否批准本 App 本次运行。",
        "next_command_after_user_approval": "python runtime/tiandao_furnace.py start --yes",
        "stop": STOP_NOTICE,
    })


def cmd_start(args: argparse.Namespace) -> None:
    if not args.yes:
        print_json({
            "mode": "runtime_start_blocked",
            "reason": "缺少用户明确批准。",
            "required_action": "先把 open 输出的审批卡展示给用户；用户批准后再加 --yes。",
            "preview_command": "python runtime/tiandao_furnace.py open",
            "stop": STOP_NOTICE,
        })
        return
    try:
        front = parse_numbers(args.front or "", 5, 1, 35, "前区") if args.front else []
        back = parse_numbers(args.back or "", 2, 1, 12, "后区") if args.back else []
    except ValueError as e:
        print_json({"mode": "start_error", "error": str(e), "hint": "示例：--front \"1 2 3 4 5\" --back \"1 2\"；也可先不填，开局会询问上期号码来源。"})
        return
    now = datetime.now().isoformat(timespec="seconds")
    st = RitualState(
        session_id=new_session_id(),
        approved_runtime=True,
        previous_front=front,
        previous_back=back,
        name=args.name or "",
        motives=normalize_with_overflow(args.motive, MOTIVES, 3, "缘起")[0] if args.motive else [],
        mental_states=normalize_with_overflow(args.mental, MENTAL_STATES, 2, "心象")[0] if args.mental else [],
        activities=normalize_with_overflow(args.activity, ACTIVITY_FIELDS, 3, "场域")[0] if args.activity else [],
        chaos=float(args.chaos if args.chaos is not None else 0.5),
        confirmed_entertainment_only=False,
        run_date=str(date.today()),
        draw_no=date.today().strftime("%Y%m%d"),
        created_at=now,
        updated_at=now,
        previous_source="manual" if front and back else "",
        direction=args.direction or "",
        weather=args.weather or "",
        geo_field=args.geo_field or "",
        location_text=args.location or "",
        ambient_tokens=[],
        selection_notes=[],
    )
    save_state(st)
    rep = report_for_state(st)
    rep["mode"] = "runtime_started_waiting_for_user_answers"
    rep["important"] = "已创建 session，但不会直接开炉。请按 next_questions 分批询问用户。"
    print_json(rep)


def cmd_answer(args: argparse.Namespace) -> None:
    st = load_state(args.session)
    if st.status == "opened":
        print_json({"mode": "session_already_opened", "session_id": st.session_id, "message": "本 session 已开炉；请新建 session 或执行 review。"})
        return
    if args.previous_source:
        st.previous_source = args.previous_source.strip()
        if st.previous_source == "web_lookup_requested":
            st.status = "waiting_lookup"
        elif st.previous_source == "web_lookup_confirmed":
            st.status = "collecting"
    if args.front:
        st.previous_front = parse_numbers(args.front, 5, 1, 35, "前区")
        if not st.previous_source:
            st.previous_source = "manual"
    if args.back:
        st.previous_back = parse_numbers(args.back, 2, 1, 12, "后区")
        if not st.previous_source:
            st.previous_source = "manual"
    if args.name:
        st.name = args.name.strip()
    if args.motive:
        used, overflow, notes = normalize_with_overflow(args.motive, MOTIVES, 3, "缘起")
        st.motives = list(dict.fromkeys(st.motives + used))[:3]
        st.ambient_tokens = list(dict.fromkeys((st.ambient_tokens or []) + [f"缘起余炭:{x}" for x in overflow]))
        st.selection_notes = list(dict.fromkeys((st.selection_notes or []) + notes))
    if args.mental:
        used, overflow, notes = normalize_with_overflow(args.mental, MENTAL_STATES, 2, "心象")
        st.mental_states = list(dict.fromkeys(st.mental_states + used))[:2]
        st.ambient_tokens = list(dict.fromkeys((st.ambient_tokens or []) + [f"心象余炭:{x}" for x in overflow]))
        st.selection_notes = list(dict.fromkeys((st.selection_notes or []) + notes))
    if args.activity:
        used, overflow, notes = normalize_with_overflow(args.activity, ACTIVITY_FIELDS, 3, "场域")
        st.activities = list(dict.fromkeys(st.activities + used))[:3]
        st.ambient_tokens = list(dict.fromkeys((st.ambient_tokens or []) + [f"场域余炭:{x}" for x in overflow]))
        st.selection_notes = list(dict.fromkeys((st.selection_notes or []) + notes))
    if args.direction:
        st.direction = normalize_by_label([args.direction], DIRECTIONS, 1)[0] if normalize_by_label([args.direction], DIRECTIONS, 1) else args.direction
    if args.weather:
        st.weather = normalize_by_label([args.weather], WEATHERS, 1)[0] if normalize_by_label([args.weather], WEATHERS, 1) else args.weather
    if args.geo_field:
        st.geo_field = normalize_by_label([args.geo_field], GEO_FIELDS, 1)[0] if normalize_by_label([args.geo_field], GEO_FIELDS, 1) else args.geo_field
    if args.location:
        st.location_text = args.location.strip()
    if args.chaos is not None:
        st.chaos = float(args.chaos)
    if args.confirm in ("yes_entertainment_only", "yes", "true", "确认"):
        st.confirmed_entertainment_only = True
    elif args.confirm in ("pause", "no", "false", "暂停"):
        st.status = "paused"
    save_state(st)
    print_json(report_for_state(st))


def cmd_ritual(args: argparse.Namespace) -> None:
    # Compatibility guard. This prevents agents from bypassing ANO flow by stuffing all args at once.
    print_json({
        "mode": "direct_ritual_blocked",
        "reason": "v0.4.0 起继续禁止一条 ritual 命令直接开炉。必须先走 ANO Host 托管的审批、上期号码查验、分批问答与风水添柴流程。",
        "why": "用户测试发现 Agent 会把参数一次性塞满，绕过上下文权限申请、用户确认、添柴问答和炉温门槛。该入口已改为保护性阻断。",
        "correct_flow": [
            "python runtime/tiandao_furnace.py open",
            "把上下文权限申请表和 Agent 阵容展示给用户，然后停止。",
            "用户明确批准后：python runtime/tiandao_furnace.py start --yes",
            "按 next_questions 询问用户，再用 answer --session <id> 分批提交。",
            "炉温达标后仍需 confirm yes_entertainment_only，确认后才开炉。",
        ],
        "stop": STOP_NOTICE,
    })


def cmd_agents(_args: argparse.Namespace) -> None:
    print_json({"app_id": APP_ID, "version": APP_VERSION, "agents": AGENTS})


def cmd_approval(_args: argparse.Namespace) -> None:
    print_json({"context_permission_request": context_permission_request(), "agent_runtime_approval_card": approval_card(), "stop": STOP_NOTICE})


def cmd_options(_args: argparse.Namespace) -> None:
    print_json({
        "motives": [{"id": k, **{kk: vv for kk, vv in v.items() if kk in ["label", "heat", "attention", "safety", "message"]}} for k, v in MOTIVES.items()],
        "mental_states": [{"id": k, "label": v["label"], "icon": v.get("icon", "")} for k, v in MENTAL_STATES.items()],
        "activity_fields": [{"id": k, "label": v["label"], "icon": v.get("icon", ""), "safety": v.get("safety", "normal"), "message": v.get("message", "")} for k, v in ACTIVITY_FIELDS.items()],
        "directions": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in DIRECTIONS.items()],
        "weathers": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in WEATHERS.items()],
        "geo_fields": [{"id": k, "label": v["label"], "phase": v["phase"], "theory": v["theory"]} for k, v in GEO_FIELDS.items()],
    })


def cmd_safety(args: argparse.Namespace) -> None:
    print_json(safety_audit_text(args.text))


def cmd_review(args: argparse.Namespace) -> None:
    try:
        pick_front = parse_numbers(args.pick_front, 5, 1, 35, "样本前区")
        pick_back = parse_numbers(args.pick_back, 2, 1, 12, "样本后区")
        result_front = parse_numbers(args.result_front, 5, 1, 35, "结果前区")
        result_back = parse_numbers(args.result_back, 2, 1, 12, "结果后区")
    except ValueError as e:
        print_json({"mode": "review_error", "error": str(e)})
        return
    front_hits = sorted(set(pick_front) & set(result_front))
    back_hits = sorted(set(pick_back) & set(result_back))
    score = len(front_hits) * 10 + len(back_hits) * 20
    report = {
        "agent": "tiandao.collision_reviewer",
        "mode": "collision_review_only",
        "front_hits": front_hits,
        "back_hits": back_hits,
        "symbolic_collision_score": score,
        "interpretation": "这是事后碰撞复盘，不证明预测能力，也不代表未来优势。",
        "safety_notice": SAFETY_NOTICE,
    }
    print_json(report)


def cmd_health(_args: argparse.Namespace) -> None:
    print_json({"status": "PASS", "app_id": APP_ID, "version": APP_VERSION, "checks": ["runtime import ok", "open flow available", "direct ritual blocked", "state directory writable"]})


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(description="ANO Tiandao Furnace Skill App v0.4.0")
    sub = p.add_subparsers(dest="cmd", required=True)
    sub.add_parser("open", help="Open app: print CPR + Agent roster, then stop").set_defaults(func=cmd_open)
    start = sub.add_parser("start", help="Start approved staged session")
    start.add_argument("--yes", action="store_true", help="User-approved runtime start")
    start.add_argument("--front", default="")
    start.add_argument("--back", default="")
    start.add_argument("--name", default="")
    start.add_argument("--motive", default="")
    start.add_argument("--mental", default="")
    start.add_argument("--activity", default="")
    start.add_argument("--direction", default="")
    start.add_argument("--weather", default="")
    start.add_argument("--geo-field", dest="geo_field", default="")
    start.add_argument("--location", default="")
    start.add_argument("--chaos", type=float, default=None)
    start.set_defaults(func=cmd_start)
    ans = sub.add_parser("answer", help="Submit one staged answer batch")
    ans.add_argument("--session", required=True)
    ans.add_argument("--front", default="")
    ans.add_argument("--back", default="")
    ans.add_argument("--name", default="")
    ans.add_argument("--motive", default="")
    ans.add_argument("--mental", default="")
    ans.add_argument("--activity", default="")
    ans.add_argument("--previous-source", default="")
    ans.add_argument("--direction", default="")
    ans.add_argument("--weather", default="")
    ans.add_argument("--geo-field", dest="geo_field", default="")
    ans.add_argument("--location", default="")
    ans.add_argument("--chaos", type=float, default=None)
    ans.add_argument("--confirm", default="")
    ans.set_defaults(func=cmd_answer)
    rit = sub.add_parser("ritual", help="Compatibility guard: blocked in v0.3.1")
    # Accept legacy args without using them so old commands fail gracefully.
    for name in ["front", "back", "name", "motive", "mental", "activity", "confirm", "direction", "weather", "geo_field"]:
        rit.add_argument(f"--{name}", default="")
    rit.add_argument("--chaos", type=float, default=None)
    rit.set_defaults(func=cmd_ritual)
    sub.add_parser("agents").set_defaults(func=cmd_agents)
    sub.add_parser("approval").set_defaults(func=cmd_approval)
    sub.add_parser("options").set_defaults(func=cmd_options)
    safety = sub.add_parser("safety")
    safety.add_argument("text")
    safety.set_defaults(func=cmd_safety)
    review = sub.add_parser("review")
    review.add_argument("--pick-front", required=True)
    review.add_argument("--pick-back", required=True)
    review.add_argument("--result-front", required=True)
    review.add_argument("--result-back", required=True)
    review.set_defaults(func=cmd_review)
    sub.add_parser("health").set_defaults(func=cmd_health)
    return p


def main() -> None:
    parser = build_parser()
    args = parser.parse_args()
    args.func(args)


if __name__ == "__main__":
    main()
