#!/usr/bin/env python3
from __future__ import annotations
import json
import sys
from pathlib import Path
APP_ID = "ano.skill.tiandao"
PACKAGE = "ano-tiandao-furnace-skill-app"

def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: health_check.py /path/to/ANO_WORKSPACE", file=sys.stderr)
        return 2
    root = Path(sys.argv[1]).resolve()
    required = [
        root / "README.md",
        root / "USER_LOG.md",
        root / "ano",
        root / "user",
        root / "apps" / PACKAGE,
        root / "ano/runtime/apps" / APP_ID,
        root / "user/apps" / APP_ID,
        root / "out/tiandao",
        root / "ano/registry/apps" / f"{APP_ID}.json",
    ]
    missing = [str(p.relative_to(root)) for p in required if not p.exists()]
    if missing:
        print(json.dumps({"status":"FAIL","missing":missing}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps({"status":"PASS","app_id":APP_ID,"package":PACKAGE,"multi_agent":True}, ensure_ascii=False, indent=2))
    return 0
if __name__ == "__main__":
    raise SystemExit(main())
