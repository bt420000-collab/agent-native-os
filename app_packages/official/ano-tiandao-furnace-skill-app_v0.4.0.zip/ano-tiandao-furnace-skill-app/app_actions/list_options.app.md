# App Action: list_options

```bash
python runtime/tiandao_furnace.py options
```

Print original-style option pools: motives, mental states, and activity fields.
