# Action: install

安装 `ano-tiandao-furnace-skill-app` 到 ANO Clean Workspace。

Creates:
- `apps/ano-tiandao-furnace-skill-app/`
- `ano/runtime/apps/ano.skill.tiandao/`
- `user/apps/ano.skill.tiandao/`
- `out/tiandao/`
