# App Action: symbolic sample

Symbol sampling is not a standalone direct action in v0.3.0.

The symbol sampler agent only runs after:

- ANO runtime approval is shown and approved;
- a staged session exists;
- user answers have raised furnace heat to at least 75%;
- the user confirms entertainment-only usage.

Use `open -> start --yes -> answer -> confirm`.
