# App Action: preview_agent_roster

```bash
python runtime/tiandao_furnace.py agents
```

Shows every Tiandao Furnace agent and what it is doing.
