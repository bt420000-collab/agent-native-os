# Action: review_collision

录入结果后进行碰撞复盘，输出碰撞等级和安全提示。
