# Action: safety_audit

审计文本中是否存在预测、投注诱导或金钱决策风险。
