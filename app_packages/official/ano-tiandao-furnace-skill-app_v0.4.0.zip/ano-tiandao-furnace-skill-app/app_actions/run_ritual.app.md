# App Action: staged Tiandao ritual

Do not call `ritual` directly for output.

Required ANO-hosted flow:

1. `python runtime/tiandao_furnace.py open`
2. Stop and show the Context Permission Request + Agent Runtime Approval Card to the user.
3. After user approval: `python runtime/tiandao_furnace.py start --yes --front "1 2 3 4 5" --back "1 2"`
4. Ask the returned `next_questions` to the user.
5. Submit one answer batch at a time with `answer --session <id>`.
6. Confirm entertainment-only usage before opening.
